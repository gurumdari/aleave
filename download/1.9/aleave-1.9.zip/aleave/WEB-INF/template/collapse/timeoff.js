$content$.timeoff = {
	service: function() {
		var articleId = this.conf.articleId;

		if (articleId == null)  articleId = this.dataset.start_id;

		if (!this.dataset.is_admin) {
			setWaitingCount(this.dataset.waiting_count);
		}

		setArticleMenus(articleId);
	}
};