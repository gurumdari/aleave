$content$.work = {
	service: function() {
		var articleId = this.conf.articleId;
		var isAdmin   = this.dataset.is_admin;

		if (articleId == null)  articleId = "/work/month";

		if (!isAdmin) {
			setWaitingCount(this.dataset.waiting_count);
		}

		setArticleMenus(articleId);
	}
};