$content$.setting.admin = {
	appendUserRow: function(userTbody, userData) {
		var row = document.createElement("tr");
		userTbody.appendChild(row);

		var nameCell = row.insertCell(0);
		nameCell.appendChild(document.createTextNode(userData.user_name));

		var idCell = row.insertCell(1);
		idCell.appendChild(document.createTextNode(userData.user_id));

		var entryCell = row.insertCell(2);
		entryCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(userData.entry_date), dateFormatter.DateStyle.MEDIUM)));
		entryCell.setAttribute("id", userData.entry_date);

		var noteCell = row.insertCell(3);
		noteCell.appendChild(document.createTextNode(userData.user_note));

		row.addEventListener("click", function(event) {
			var selectedRow = userTbody.querySelector("tbody > tr.selected");
			if (selectedRow)  selectedRow.removeAttribute("class");

			this.setAttribute("class", "selected");
			document.querySelector("div.section > article > div.article > fieldset > button:nth-child(2)").disabled = false;
			document.querySelector("div.section > article > div.article > fieldset > button:last-child").disabled   = false;
		}, false);
	},

	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if (windowWidth > 736) {
			$controller$.grid.resize(null, windowHeight - 171);
		} else {
			$controller$.grid.removeHeight();
		}

		$controller$.grid.resizeScrollButtons();
	},

	service: function() {
		var that = this;
		var adminList = this.dataset.adminList;

		$jnode$.pushHistory(that.conf);

		var addButton      = document.querySelector("div.section > article > div.article > fieldset > button:first-child");
		var editButton     = addButton.nextElementSibling;
		var passwordButton = editButton.nextElementSibling;

		editButton.disabled     = true;
		passwordButton.disabled = true;

		$jnode$.requireController("grid", {caller:that.conf}).on(function() {
			$controller$.grid.service({sortable:true});

			var userTbody = document.querySelector("aside.grid > div > table > tbody");

			for (var i = 0; i < adminList.length; i++) {
				that.appendUserRow(userTbody, adminList[i]);
			}

			window.addEventListener("resize", that.resize, false);
			that.resize();

			// 관리자 추가
			addButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/setting/admin/add", {
					useLoading: true,
					icon:       true,
					title:      "관리자 추가",
					width:      420,
					height:     242,
					renderer:   "-j"
				});
			}, false);

			// 사용자 편집
			editButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/setting/admin/edit", {
					useLoading: true,
					icon:       true,
					title:      "관리자 편집",
					width:      420,
					height:     180,
					renderer:   "-j"
				});
			}, false);

			// 비밀번호 재설정
			passwordButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/setting/user/password_reset", {
					useLoading: true,
					icon:       true,
					title:      "비밀번호 재설정",
					width:      420,
					height:     150,
					renderer:   "-j"
				});
			}, false);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};