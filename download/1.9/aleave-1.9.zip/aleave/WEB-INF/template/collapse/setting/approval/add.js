$content$.setting.approval.add = {
	service: function() {
		var worker = this.dataset.worker;
		var approverInputs = document.approvalForm.querySelectorAll("form > table > tbody > tr > td > input.popup");
		var lineContainer  = document.querySelector("div.section > article > div.article > div.subtitle + div.content:nth-child(4)");

		document.querySelector("aside.popup > ul > li > div").removeAttribute("class");

		$jnode$.requireContent("popup", "/user/select", {
			open:       false,
			useLoading: true,
			widthP:     100,
			maxWidth:   360,
			height:     300
		});

		function approverClickEvent(approverInput) {
			approverInput.addEventListener("click", function(event) {
				$content$.user.select.dataset.input_name = this.getAttribute("name");

				var userDiv = document.querySelector("aside.popup article > div.popup > ul:last-child > li:first-child > div");
				var selectedUser = document.querySelector("aside.tree.org ul > li:last-child > span.checked");
				if (selectedUser)  selectedUser.removeAttribute("class");

				var userId = this.parentNode.getAttribute("id");
				if (userId) {
					var userIdTreeEntry = document.querySelector("aside.tree.org ul[id='" + userId + "'] > li:last-child > span");
					if (userIdTreeEntry)  userIdTreeEntry.setAttribute("class", "checked");
	
					userDiv.setAttribute("id", userId);
					userDiv.innerHTML = $jnode$.escapeXML(this.value);
				} else {
					userDiv.removeAttribute("id");
					userDiv.innerHTML = "";
				}

				$controller$.popup.open();
			}, false);
		}

		for (var i = 0; i < approverInputs.length; i++) {
			approverClickEvent(approverInputs[i]);
		}

		document.querySelector("aside.winup div.winup > form > ul.submit > li > button").addEventListener("click", function(event) {
			var alertMessage = null;
			var alertNode    = this.parentNode.previousElementSibling;
			var approverIds  = [];

			for (var i = 0; i < approverInputs.length; i++) {
				var approverId = approverInputs[i].parentNode.getAttribute("id");
				if (approverId)  approverIds.push(approverId);
			}

			var params = {
				command:      "addApprovalLine",
				line_name:    document.approvalForm.line_name.value.trim(),
				user_id:      worker,
				approver_ids: approverIds.join(",")
			};

			if (params.line_name == "") {
				alertMessage = "결재라인 이름을 입력해주세요.";
				document.approvalForm.line_name.focus();
			} else if (approverIds.length < 1) {
				alertMessage = "결재라인 구성은 하나 이상어야 합니다.";
			} else if (approverIds[approverIds.length - 1] == worker) {
				alertMessage = "본인은 결재라인 구성에서 제일 마지막단계에는 올 수 없습니다.";
			} else if (approverIds.indexOf(worker) > 0) {
				alertMessage = "본인은 결재라인 구성에서 제일 처음단계에만 올 수 있습니다.";
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/line.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						$content$.setting.approval.appendApprovalLine(lineContainer, response, worker, true);
						lineContainer.scrollTop = 0;
						window.scrollTo(0, 0);

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}

		}, false);

		document.approvalForm.line_name.focus();
	}
};