$content$.setting.retiree = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;
		var yearDiv      = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div.year");

		if (windowWidth > 736) {
			$controller$.grid.resize(null, windowHeight - 171);
			yearDiv.style.height = (windowHeight - 173) + "px";
		} else {
			$controller$.grid.removeHeight();
			yearDiv.style.height = (windowHeight - 56) + "px";
		}

		$controller$.grid.resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();

		var that = this;
		var quittingYearList = this.dataset.quittingYearList.sort().reverse();
		$jnode$.pushHistory(that.conf);

		var yearContainer       = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div.year");
		var yearCloseButton     = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div:last-child > ul > li:last-child > button:last-child");
		var reenteringButton    = document.querySelector("div.section > article > div.article > fieldset > button:first-child");
		var cancelButton        = reenteringButton.nextElementSibling;
		var editButton          = cancelButton.nextElementSibling;
		var historyYearCallback = null;

		reenteringButton.disabled = true;
		cancelButton.disabled     = true;
		editButton.disabled       = true;

		$jnode$.requireController("grid", {caller:that.conf}).on(function() {
			$controller$.grid.service({sortable:true});

			var userTbody = document.querySelector("aside.grid > div > table > tbody");

			window.addEventListener("resize", that.resize, false);
			that.resize();

			function appendUserRow(userData) {
				var retireeInfo = JSON.parse(userData.user_note);
				var history     = retireeInfo.history;
				var userId      = userData.user_id;

				if (history == null)  history = [];

				var row = document.createElement("tr");
				row.setAttribute("id", userId);
				row.setAttribute("history", JSON.stringify(history));
				row.setAttribute("title", (userData.user_address ? userData.user_address : ""));
				userTbody.appendChild(row);

				var nameCell = row.insertCell(0);
				nameCell.appendChild(document.createTextNode(userData.user_name));
				nameCell.setAttribute("class", "member");

				var idCell = row.insertCell(1);
				idCell.appendChild(document.createTextNode(userId.substring(userId.indexOf(":") + 1, userId.lastIndexOf("}"))));

				var birthdayCell = row.insertCell(2);
				birthdayCell.appendChild(document.createTextNode(userData.user_birthday ? dateFormatter.format($module$.date.Utils.parse(userData.user_birthday), dateFormatter.DateStyle.MEDIUM) : ""));
				birthdayCell.setAttribute("id", userData.user_birthday);
		
				var contactCell = row.insertCell(3);
				contactCell.appendChild(document.createTextNode(userData.user_contact ? userData.user_contact : ""));

				var orgCell = row.insertCell(4);
				orgCell.appendChild(document.createTextNode(retireeInfo.org_name));
				orgCell.setAttribute("id", userData.org_id);
				orgCell.setAttribute("value", userData.org_name);

				var positionCell = row.insertCell(5);
				positionCell.appendChild(document.createTextNode(retireeInfo.position_name));
				positionCell.setAttribute("id", userData.position_id);
				positionCell.setAttribute("tid", userData.position_type);

				var entryCell = row.insertCell(6);
				entryCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(userData.entry_date), dateFormatter.DateStyle.MEDIUM)));
				entryCell.setAttribute("id", userData.entry_date);

				var quittingCell = row.insertCell(7);
				quittingCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(userData.quitting_date), dateFormatter.DateStyle.MEDIUM)));
				quittingCell.setAttribute("id", userData.quitting_date);

				var reenteringInfo = "";
				if (retireeInfo.reentering_date) {
					reenteringInfo = retireeInfo.reentering_id + " / " + dateFormatter.format($module$.date.Utils.parse(retireeInfo.reentering_date), dateFormatter.DateStyle.MEDIUM);
				}

				var reenteringCell = row.insertCell(8);
				reenteringCell.appendChild(document.createTextNode(reenteringInfo));

				row.addEventListener("click", function(event) {
					var selectedRow = userTbody.querySelector("tbody > tr.selected");
					if (selectedRow)  selectedRow.removeAttribute("class");

					this.setAttribute("class", "selected");

					if (this.lastElementChild.textContent) {
						reenteringButton.disabled = true;
						cancelButton.disabled     = true;
					} else {
						reenteringButton.disabled = false;
						cancelButton.disabled     = false;
					}

					editButton.disabled = false;
				}, false);
			}

			function appendYear(year) {
				var label = document.createElement("label");

				var input = document.createElement("input");
				input.setAttribute("type", "radio");
				input.setAttribute("name", "year");
				input.setAttribute("value", year);

				var span = document.createElement("span");
				span.appendChild(document.createTextNode(year + "년 퇴사자"));

				label.appendChild(input);
				label.appendChild(span);

				input.addEventListener("click", function(event) {
					$controller$.loading.show();

					var quittingYear = this.value;
					document.querySelector("div.section > article > div.article > ul > li:first-child > div:first-child").innerHTML = quittingYear + "년 퇴사자";

					reenteringButton.disabled = true;
					cancelButton.disabled     = true;
					editButton.disabled       = true;

					$controller$.grid.clear();

					$jnode$.ajax.service({
						"url":      "/ajax/user.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params": {
							command:       "getRetireeList",
							quitting_year: quittingYear
						},
						"success": function(response) {
							for (var i = 0; i < response.length; i++) {
								appendUserRow(response[i]);
							}

							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});

					yearCloseButton.click();
				}, false);

				yearContainer.appendChild(label);
			}

			for (var i = 0; i < quittingYearList.length; i++) {
				appendYear(quittingYearList[i]);
			}

			if (quittingYearList.length == 0)  $controller$.loading.hide();
			else                               yearContainer.firstElementChild.firstElementChild.click();

			// 재입사
			reenteringButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/setting/retiree/reentering", {
					useLoading: true,
					icon:       true,
					title:      "재입사",
					width:      420,
					height:     510,
					renderer:   "-j"
				});
			}, false);

			// 퇴사 취소
			cancelButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/setting/retiree/cancel", {
					useLoading: true,
					icon:       true,
					title:      "퇴사 취소",
					width:      420,
					height:     434,
					renderer:   "-j"
				});
			}, false);

			// 퇴사자 편집
			editButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/setting/retiree/edit", {
					useLoading: true,
					icon:       true,
					title:      "퇴사자 편집",
					width:      420,
					height:     357,
					renderer:   "-j"
				});
			}, false);

			// 폰에서 퇴사연도 선택 팝업창을 띄우는 작업
			document.querySelector("div.section > article > div.article > ul > li:first-child > div:first-child").addEventListener("click", function(event) {
				if (isPhone) {
					document.body.style.overflow = "hidden";

					historyYearCallback = $jnode$.node.pushPseudoHistory(function() {
						yearCloseButton.click();
					});
				}

				this.nextElementSibling.setAttribute("class", "popup");
			}, false);

			yearCloseButton.addEventListener("click", function(event) {
				if (isPhone) {
					document.body.style.removeProperty("overflow");
					if (historyYearCallback)  historyYearCallback();
				}

				this.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
			}, false);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};