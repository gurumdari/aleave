$content$.setting.pdf = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;
		var pdfTypeDiv   = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div.pdf_type");

		if (windowWidth > 736) {
			pdfTypeDiv.style.height = (windowHeight - 205) + "px";
		} else {
			pdfTypeDiv.style.height = (windowHeight - 56) + "px";
		}
	},

	service: function() {
		var historyPdfTypeCallback = null;
		var pdfTypeCloseButton     = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div:last-child > ul > li:last-child > button");
		var isPhone                = ($jnode$.device.type == "phone");

		window.addEventListener("resize", this.resize, false);
		this.resize();

		var pdfTypeContainer = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div.pdf_type");
		var pdfMenus         = pdfTypeContainer.querySelectorAll("div.pdf_type > label > input");

		for (var i = 0; i < pdfMenus.length; i++) {
			pdfMenus[i].addEventListener("click", function(event) {
				var pdfType = this.value;
				document.querySelector("div.section > article > div.article > ul > li:first-child > div:first-child").innerHTML = this.nextElementSibling.innerHTML;
				$jnode$.requireContent("pdftemplate", "/setting/pdf/template", {
					pdf_type: pdfType
				});
			}, false);
		}

		pdfMenus[0].click();

		// 폰에서 PDF 템플릿 타입 선택 팝업창을 띄우는 작업
		document.querySelector("div.section > article > div.article > ul > li:first-child > div:first-child").addEventListener("click", function(event) {
			if (isPhone) {
				document.body.style.overflow = "hidden";

				historyPdfTypeCallback = $jnode$.node.pushPseudoHistory(function() {
					pdfTypeCloseButton.click();
				});
			}

			this.nextElementSibling.setAttribute("class", "popup");
		}, false);

		pdfTypeCloseButton.addEventListener("click", function(event) {
			if (isPhone) {
				document.body.style.removeProperty("overflow");
				if (historyPdfTypeCallback)  historyPdfTypeCallback();
			}

			this.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
		}, false);


		var statusButton  = document.querySelector("div.section > article > div.article > fieldset > ul.submit > li:last-child > button:first-child");
		var managerButton = statusButton.nextElementSibling;
		var previewButton = managerButton.nextElementSibling;

		// IE는 adobe pdf reader plugin 설치하면 사용 가능하므로 조건문 수정
		// var allowEmbedded = ((window.navigator.userAgent.indexOf("Trident") > 0) && (window.navigator.userAgent.indexOf("Windows NT 10.") > 0)) ? 0 : 1;
		// if (allowEmbedded == 1 && ($jnode$.device.type != "desktop"))  allowEmbedded = -1;
		var allowEmbedded = ($jnode$.device.type == "desktop") ? 1 : -1;

		statusButton.addEventListener("click", function(event) {
			var selectedInput = pdfTypeContainer.querySelector("div.pdf_type > label > input:checked");
			var pdfType       = selectedInput.value;

			if (pdfType == "career") {
				$controller$.prompt.alert("경력증명서의 상태는 재직증명서의 상태를 따라갑니다.", null, true);
			} else {
				$jnode$.requireContent("winup", "/setting/pdf/template/status", {
					icon:       true,
					title:      "상태 변경",
					width:      280,
					height:     118,
					renderer:   "-j",
					pdf_type:   pdfType,
					status:     $content$.setting.pdf.template.properties.status
				});
			}
		}, false);

		managerButton.addEventListener("click", function(event) {
			var selectedInput = pdfTypeContainer.querySelector("div.pdf_type > label > input:checked");
			var pdfType       = selectedInput.value;

			if (pdfType == "career") {
				$controller$.prompt.alert("경력증명서의 담당자는 재직증명서의 담당자를 따라갑니다.", null, true);
			} else {
				$jnode$.requireContent("winup", "/setting/pdf/template/manager", {
					icon:       true,
					title:      "처리 담당자 선택",
					width:      360,
					height:     118,
					renderer:   "-j",
					pdf_type:   selectedInput.value,
					manager_id: $content$.setting.pdf.template.properties.manager_id
				});
			}
		}, false);

		previewButton.addEventListener("click", function(event) {
			var selectedInput = pdfTypeContainer.querySelector("div.pdf_type > label > input:checked");

			$jnode$.requireContent("popup", "/work/pdf/preview", {
				widthP:         100,
				heightP:        100,
				title:          "A-leave 템플릿 (" + selectedInput.nextElementSibling.firstChild.nodeValue + ")",
				maxWidth:       640,
				allow_embedded: allowEmbedded,
				pdf_type:       selectedInput.value,
			});
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};