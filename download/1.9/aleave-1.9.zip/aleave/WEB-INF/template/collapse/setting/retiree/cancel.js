$content$.setting.retiree.cancel = {
	service: function() {
		var posTypeList      = this.dataset.positionTypeList;
		var posTypeMap       = {};
		var typeCount        = posTypeList.length;
		var userNameInput    = document.userForm.user_name;
		var userIdInput      = document.userForm.user_id;
		var birthdayInput    = document.userForm.user_birthday;
		var userContactInput = document.userForm.user_contact;
		var userAddressInput = document.userForm.user_address;
		var orgIdInput       = document.userForm.org_id;
		var orgNameInput     = document.userForm.org_name;
		var posTypeSelect    = document.userForm.pos_type;
		var positionSelect   = document.userForm.user_position;
		var okButton         = document.userForm.querySelector("form > ul.submit > li > button");

		var userTbody    = document.querySelector("aside.grid > div > table > tbody");
		var userRow      = userTbody.querySelector("tbody > tr.selected");
		var userNameCell = userRow.firstElementChild;
		var userIdCell   = userNameCell.nextElementSibling;
		var birthdayCell = userIdCell.nextElementSibling;
		var contactCell  = birthdayCell.nextElementSibling;
		var orgCell      = contactCell.nextElementSibling;
		var positionCell = orgCell.nextElementSibling;

		function drawCalendar(buttonTitle, isoValue) {
			var date         = null;
			var windowWidth  = window.innerWidth;
			var popupDomain  = $jnode$.controller.getDomain("popup");
			var popupContent = popupDomain.querySelector($jnode$.selector.controller.popup.content);
			popupContent.innerHTML = "<DIV class=\"calendar\"><DIV></DIV><UL class=\"submit\"><LI></LI><LI><BUTTON class=\"caution\">" + buttonTitle + "</BUTTON></LI></UL></DIV>";

			$controller$.popup.open({
				width:  (windowWidth > 736 ? 246 : 280),
				height: (windowWidth > 736 ? 236 : 325)
			});

			if (isoValue) {
				date = $module$.date.Utils.parse(isoValue);
			} else {
				date = new Date();
				isoValue = $module$.date.Utils.format(date);
			}

			var dateCalendar = popupDomain.querySelector("aside.popup article > div.calendar > div");
			var dateLi       = dateCalendar.nextElementSibling.firstElementChild;

			dateLi.innerHTML = $jnode$.escapeXML(dateFormatter.format(date, dateFormatter.DateStyle.LONG));
			dateLi.setAttribute("value", "iso:" + isoValue);

			displayCalendar(date, dateLi, dateCalendar, isoValue);

			dateLi.addEventListener("click", function() {
				var selectedIsoValue = this.getAttribute("value").substring(4);
				displayCalendar(selectedIsoValue, this, dateCalendar, selectedIsoValue);
			}, false);

			return dateLi;
		}

		function dateSelectEvent(dateInput) {
			var inputContainer = dateInput.parentNode;
			var isoValue       = inputContainer.getAttribute("value");

			if (isoValue == "") {
				isoValue = $module$.date.Utils.format($module$.date.Utils.toYear(-30));
			}

			var dateLi = drawCalendar("확인", isoValue);

			document.querySelector("aside.popup > ul > li > div").setAttribute("class", "calendar_area");

			dateLi.nextElementSibling.firstElementChild.addEventListener("click", function(event) {
				var selectedIsoValue = dateLi.getAttribute("value").substring(4);
				inputContainer.setAttribute("value", selectedIsoValue);
				inputContainer.firstElementChild.value = dateFormatter.format($module$.date.Utils.parse(selectedIsoValue), dateFormatter.DateStyle.LONG);

				$controller$.popup.close();
			}, false);
		}

		// retiree_id
		var retireeId = userRow.getAttribute("id");
		var history   = userRow.getAttribute("history");
		if (history == "[]")  history = null;

		// user_name
		userNameInput.value = userNameCell.textContent;

		// user_id
		userIdInput.value = userIdCell.textContent;

		// user_birthday
		var birthday = birthdayCell.getAttribute("id");
		if (birthday)  birthdayInput.value = dateFormatter.format($module$.date.Utils.parse(birthday), dateFormatter.DateStyle.LONG);
		birthdayInput.parentNode.setAttribute("value", birthday);

		birthdayInput.addEventListener("click", function(event) {
			dateSelectEvent(this);
		}, false);

		// user_contact
		userContactInput.value = contactCell.textContent;

		// user_address
		var userAddress = userRow.getAttribute("title");
		if (userAddress)  userAddressInput.value = userAddress;

		// org_id
		orgIdInput.value   = orgCell.getAttribute("id");
		orgNameInput.value = orgCell.getAttribute("value");

		// position
		function changePosList(posType) {
			var posList = posTypeMap[posType];

			positionSelect.innerHTML = "";
			for (var i = 0; i < posList.length; i++) {
				positionSelect.add(new Option(posList[i].position_name, posList[i].position_id));
			}
		}

		for (var i = 0; i < typeCount; i++) {
			posTypeMap[posTypeList[i].type_id.toString()] = posTypeList[i].list;
			posTypeSelect.add(new Option(posTypeList[i].type_name, posTypeList[i].type_id));
		}

		posTypeSelect.addEventListener("change", function(event) {
			changePosList(this.value);
		}, false);

		var typeId = positionCell.getAttribute("tid");
		posTypeSelect.value = typeId;
		changePosList(typeId);
		positionSelect.value = positionCell.getAttribute("id");

		orgNameInput.addEventListener("click", function(event) {
			document.querySelector("aside.popup > ul > li > div").removeAttribute("class");

			var windowWidth = window.innerWidth;
			var options = {
				useLoading: true,
				height:     229,
				renderer:   "-j"
			};
			
			if (windowWidth > 400)  options.width = 360;
			else                    options.widthP = 100;

			$jnode$.requireContent("popup", "/setting/org/select", options);
		}, false);

		okButton.addEventListener("click", function(event) {
			var alertMessage = null;
			var alertNode    = this.parentNode.previousElementSibling;

			var params = {
				command:       "cancelRetiree",
				user_name:     userNameInput.value.trim(),
				user_id:       userIdInput.value.trim(),
				user_birthday: birthdayInput.parentNode.getAttribute("value"),
				user_contact:  userContactInput.value.trim(),
				user_address:  userAddressInput.value.trim(),
				org_id:        orgIdInput.value,
				position_id:   positionSelect.value,
				user_note:     history,
				retiree_id:    retireeId,
			};

			if (params.user_name == "") {
				alertMessage = "\사용자 이름을 입력해주세요.";
				document.userForm.user_name.select();
			} else if (params.user_id == "") {
				alertMessage = "사용자 ID를 입력해 주세요.";
				document.userForm.user_id.select();
			} else if (params.userId == "-") {
				alertMessage = "사용자 ID는 \"-\"일 수 없습니다.";
				document.userForm.user_id.select();
			} else if (!/^[\w|\.|\-]+$/g.test(params.user_id)) {
				alertMessage = "사용자 ID의 문자열은 영문, 숫자, 밑줄(_), 하이픈(-), 점(.)만 가능합니다.";
				document.userForm.user_id.select();
			} else if (params.user_id.length > 30) {
				alertMessage = "사용자 ID는 최대 30자까지만 가능합니다.";
				document.userForm.user_id.select();
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						userTbody.removeChild(userRow);
						var reenteringButton = document.querySelector("div.section > article > div.article > fieldset > button:first-child");
						var cancelButton     = reenteringButton.nextElementSibling;
						var deleteButton     = cancelButton.nextElementSibling;

						reenteringButton.disabled = true;
						cancelButton.disabled     = true;
						deleteButton.disabled     = true;

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error, [
							{"code":"409", "message":"-" , "callback":function() { alertNode.innerHTML = "퇴사 처리된 기간중에 해당 ID가 이미 등록되었습니다."; document.userForm.user_id.select(); }}
						]);

						$controller$.loading.hide();
					}
				});
			}
		}, false);
	}
};