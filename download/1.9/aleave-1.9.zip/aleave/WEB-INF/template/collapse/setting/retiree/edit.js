$content$.setting.retiree.edit = {
	resize: function() {
		var windowWidth = window.innerWidth;

		if (windowWidth > 736) {
			$controller$.popup.resize(246, 236);
		} else {
			$controller$.popup.resize(280, 325);
		}
	},

	service: function() {
		var userNameInput     = document.userForm.user_name;
		var birthdayInput     = document.userForm.user_birthday;
		var userContactInput  = document.userForm.user_contact;
		var userAddressText   = document.userForm.user_address;
		var orgNameInput      = document.userForm.org_name;
		var positionNameInput = document.userForm.position_name;
		var okButton          = document.userForm.querySelector("form > ul.submit > li > button:first-child");
		var deleteButton      = okButton.nextElementSibling;

		var userTbody    = document.querySelector("aside.grid > div > table > tbody");
		var userRow      = userTbody.querySelector("tbody > tr.selected");
		var userNameCell = userRow.firstElementChild;
		var birthdayCell = userNameCell.nextElementSibling.nextElementSibling;
		var contactCell  = birthdayCell.nextElementSibling;
		var orgCell      = contactCell.nextElementSibling;
		var positionCell = orgCell.nextElementSibling;

		function drawCalendar(buttonTitle, isoValue) {
			var date         = null;
			var windowWidth  = window.innerWidth;
			var popupDomain  = $jnode$.controller.getDomain("popup");
			var popupContent = popupDomain.querySelector($jnode$.selector.controller.popup.content);
			popupContent.innerHTML = "<DIV class=\"calendar\"><DIV></DIV><UL class=\"submit\"><LI></LI><LI><BUTTON class=\"caution\">" + buttonTitle + "</BUTTON></LI></UL></DIV>";

			$controller$.popup.open({
				width:  (windowWidth > 736 ? 246 : 280),
				height: (windowWidth > 736 ? 236 : 325)
			});

			if (isoValue) {
				date = $module$.date.Utils.parse(isoValue);
			} else {
				date = new Date();
				isoValue = $module$.date.Utils.format(date);
			}

			var dateCalendar = popupDomain.querySelector("aside.popup article > div.calendar > div");
			var dateLi       = dateCalendar.nextElementSibling.firstElementChild;

			dateLi.innerHTML = $jnode$.escapeXML(dateFormatter.format(date, dateFormatter.DateStyle.LONG));
			dateLi.setAttribute("value", "iso:" + isoValue);

			displayCalendar(date, dateLi, dateCalendar, isoValue);

			dateLi.addEventListener("click", function() {
				var selectedIsoValue = this.getAttribute("value").substring(4);
				displayCalendar(selectedIsoValue, this, dateCalendar, selectedIsoValue);
			}, false);

			return dateLi;
		}

		function dateSelectEvent(dateInput) {
			var inputContainer = dateInput.parentNode;
			var isoValue       = inputContainer.getAttribute("value");

			if (isoValue == "") {
				isoValue = $module$.date.Utils.format($module$.date.Utils.toYear(-30));
			}

			var dateLi = drawCalendar("확인", isoValue);

			dateLi.nextElementSibling.firstElementChild.addEventListener("click", function(event) {
				var selectedIsoValue = dateLi.getAttribute("value").substring(4);
				inputContainer.setAttribute("value", selectedIsoValue);
				inputContainer.firstElementChild.value = dateFormatter.format($module$.date.Utils.parse(selectedIsoValue), dateFormatter.DateStyle.LONG);

				$controller$.popup.close();
			}, false);
		}

		// user_name
		userNameInput.value = userNameCell.textContent;

		// user_id
		var userId = userRow.getAttribute("id");

		// user_birthday
		var oldBirthday = birthdayCell.getAttribute("id");
		if (oldBirthday)  birthdayInput.value = dateFormatter.format($module$.date.Utils.parse(oldBirthday), dateFormatter.DateStyle.LONG);
		birthdayInput.parentNode.setAttribute("value", oldBirthday);

		// user_contact
		userContactInput.value = contactCell.textContent;

		// org_name
		orgNameInput.value = orgCell.textContent;

		// position_name
		positionNameInput.value = positionCell.textContent;

		// user_address
		userAddressText.value = userRow.getAttribute("title").replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");

		userAddressText.addEventListener("keydown", function(event) {
			var keyCode = event.keyCode || event.which;

			if(keyCode == 13) {
				event.preventDefault();
			}
		}, false);

		userAddressText.addEventListener("paste", function(event) {
			window.setTimeout(function() {
				userAddressText.value = userAddressText.value.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");
			});
		}, false);

		// EVENT
		window.addEventListener("resize", this.resize, false);

		birthdayInput.addEventListener("click", function(event) {
			dateSelectEvent(this);
		}, false);

		// 사용자 정보 변경
		okButton.addEventListener("click", function(event) {
			var alertMessage = null;
			var alertNode    = this.parentNode.previousElementSibling;

			var params = {
				command:       "updateUser",
				user_name:     userNameInput.value.trim(),
				user_id:       userId,
				user_birthday: birthdayInput.parentNode.getAttribute("value"),
				user_contact:  userContactInput.value.trim(),
				user_address:  userAddressText.value.trim()
			};

			var userNote = {
				org_name:      orgNameInput.value.trim(),
				position_name: positionNameInput.value.trim()
			};

			if (params.user_name == "") {
				alertMessage = "사용자 이름을 입력해주세요.";
				userNameInput.select();
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				var textHistory = userRow.getAttribute("history");

				if (textHistory != "[]") {
					userNote.history = JSON.parse(textHistory);
				}

				params.user_note = JSON.stringify(userNote);

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						userNameCell.firstChild.nodeValue = params.user_name;

						if (params.user_birthday) {
							birthdayCell.firstChild.nodeValue = dateFormatter.format($module$.date.Utils.parse(params.user_birthday), dateFormatter.DateStyle.MEDIUM);
							birthdayCell.setAttribute("id", params.user_birthday);
						}

						contactCell.firstChild.nodeValue  = params.user_contact;
						orgCell.firstChild.nodeValue      = userNote.org_name;
						positionCell.firstChild.nodeValue = userNote.position_name;

						userRow.setAttribute("title", params.user_address);

						$controller$.grid.clear("thead");

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		deleteButton.addEventListener("click", function(event) {
			$controller$.prompt.confirm("퇴사자 정보가 모두 삭제되고, 다시 복원할 수 없게 됩니다.", function(close) {
				$controller$.loading.show();

				var params = {
					command: "deleteUser",
					user_id: userId
				};

				var history      = JSON.parse(userRow.getAttribute("history"));
				var historyCount = history.length;

				if (historyCount > 0) {
					params.removed_history = history[historyCount - 1];
				}
console.info("removed_history: " + params.removed_history);

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						userTbody.removeChild(userRow);

						var reenteringButton = document.querySelector("div.section > article > div.article > fieldset > button:first-child");
						var cancelButton     = reenteringButton.nextElementSibling;
						var editButton       = cancelButton.nextElementSibling;

						reenteringButton.disabled = true;
						cancelButton.disabled     = true;
						editButton.disabled       = true;

						if (params.removed_history) {
							var removedHistoryRow = userTbody.querySelector("tbody > tr[id='" + params.removed_history + "']");
							if (removedHistoryRow)  removedHistoryRow.lastElementChild.firstChild.nodeValue = "";
						}

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
				close();
			}, null, 2);
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};