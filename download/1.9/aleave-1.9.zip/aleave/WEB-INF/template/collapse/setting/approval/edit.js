$content$.setting.approval.edit = {
	service: function() {
		var worker           = this.dataset.worker
		var lineContainer    = document.querySelector("div.section > article > div.article > div.subtitle + div.content:nth-child(4)");
		var checkedLineInput = document.querySelector("div.section > article > div.article > div.subtitle + div.content > fieldset > legend > label > input:checked");
		var lineFieldset     = checkedLineInput.parentNode.parentNode.parentNode;
		var lineId           = checkedLineInput.value;
		var lineSpan         = checkedLineInput.nextElementSibling;
		var approverTds      = lineFieldset.querySelectorAll("fieldset > ul > li > table > tbody > tr > td:nth-child(odd)");

		document.querySelector("aside.popup > ul > li > div").removeAttribute("class");

		$jnode$.requireContent("popup", "/user/select", {
			open:       false,
			useLoading: true,
			widthP:     100,
			maxWidth:   360,
			height:     300
		});

		function approverClickEvent(approverInput) {
			approverInput.addEventListener("click", function(event) {
				$content$.user.select.dataset.input_name = this.getAttribute("name");

				var userDiv = document.querySelector("aside.popup article > div.popup > ul:last-child > li:first-child > div");
				var selectedUser = document.querySelector("aside.tree.org ul > li:last-child > span.checked");
				if (selectedUser)  selectedUser.removeAttribute("class");

				var userId = this.parentNode.getAttribute("id");
				if (userId) {
					var userIdTreeEntry = document.querySelector("aside.tree.org ul[id='" + userId + "'] > li:last-child > span");
					if (userIdTreeEntry)  userIdTreeEntry.setAttribute("class", "checked");
	
					userDiv.setAttribute("id", userId);
					userDiv.innerHTML = $jnode$.escapeXML(this.value);
				} else {
					userDiv.removeAttribute("id");
					userDiv.innerHTML = "";
				}

				$controller$.popup.open();
			}, false);
		}

		var lineNameInput  = document.approvalForm.line_name;
		var approverInputs = document.approvalForm.querySelectorAll("form > table > tbody > tr > td > input.popup");

		lineNameInput.value = lineSpan.firstChild.nodeValue;

		for (var i = 0; i < approverInputs.length; i++) {
			var userId  = approverTds[i].getAttribute("id");

			if (userId) {
				approverInputs[i].parentNode.setAttribute("id", userId);

				if (userId == worker) {
					approverInputs[i].value = this.dataset.worker_name + " (" + this.dataset.worker_pos + ") @ " + this.dataset.worker_org;
				} else {
					var userDiv = approverTds[i].firstElementChild;
					var orgDiv  = approverTds[i].lastElementChild;

					approverInputs[i].value = userDiv.firstElementChild.firstChild.nodeValue + " (" + userDiv.lastElementChild.firstChild.nodeValue + ") @ " + orgDiv.firstChild.nodeValue;
				}
			}

			approverClickEvent(approverInputs[i]);
		}

		var okButton     = document.querySelector("aside.winup div.winup > form > ul.submit > li > button:first-child");
		var deleteButton = okButton.nextElementSibling;

		okButton.addEventListener("click", function(event) {
			var alertMessage = null;
			var alertNode    = this.parentNode.previousElementSibling;
			var approverIds  = [];

			for (var i = 0; i < approverInputs.length; i++) {
				var approverId = approverInputs[i].parentNode.getAttribute("id");
				if (approverId)  approverIds.push(approverId);
			}

			var params = {
				command:      "updateApprovalLine",
				line_id:      lineId,
				line_name:    document.approvalForm.line_name.value.trim(),
				user_id:      worker,
				approver_ids: approverIds.join(",")
			};

			if (params.line_name == "") {
				alertMessage = "결재라인 이름을 입력해주세요.";  // 
				document.approvalForm.line_name.focus();
			} else if (approverIds.length < 1) {
				alertMessage = "결재라인 구성은 하나 이상어야 합니다.";
			} else if (approverIds[approverIds.length - 1] == worker) {
				alertMessage = "본인은 결재라인 구성에서 제일 마지막단계에는 올 수 없습니다.";
			} else if (approverIds.indexOf(worker) > 0) {
				alertMessage = "본인은 결재라인 구성에서 제일 처음단계에만 올 수 있습니다.";
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/line.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						var firstFieldset = lineContainer.firstElementChild;
						if (firstFieldset != lineFieldset)  lineContainer.insertBefore(lineFieldset, firstFieldset);

						lineSpan.firstChild.nodeValue = params.line_name;

						for (var i = 0; i < response.length; i++) {
							var userId  = response[i].approver_id;
							approverTds[i].setAttribute("id", userId);

							var userDiv = approverTds[i].firstElementChild;
							var orgDiv  = approverTds[i].lastElementChild;

							if (userId == worker)  userDiv.innerHTML = "본인";
							else                   userDiv.innerHTML = "<SPAN>" + $jnode$.escapeXML(response[i].approver_name) + "</SPAN> <SPAN>" + $jnode$.escapeXML(response[i].position_name) + "</SPAN>";

							orgDiv.innerHTML = $jnode$.escapeXML(response[i].org_name);
						}

						for (var i = response.length; i < 3; i++) {
							approverTds[i].removeAttribute("id");

							approverTds[i].firstElementChild.innerHTML = "";
							approverTds[i].lastElementChild.innerHTML = "";
						}

						lineContainer.scrollTop = 0;
						window.scrollTo(0, 0);

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		deleteButton.addEventListener("click", function(event) {
			$controller$.prompt.confirm("정말로 결재라인을 삭제하겠습니까?", function(close) {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/line.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  {
						command: "deleteApprovalLine",
						line_id: lineId
					},
					"success": function(response) {
						lineContainer.removeChild(lineFieldset);

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});

				close();
			}, null, 2);
		}, false);
	}
};