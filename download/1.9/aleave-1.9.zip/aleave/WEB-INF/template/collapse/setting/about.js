$content$.setting.about = {
	service: function() {
		$jnode$.pushHistory(this.conf);

		var infoCell1 = document.querySelector("div.section > article > div.article > fieldset > div:nth-child(2) > ul > li:first-child > table.form.nogroup > tbody > tr:first-child > th");
		var infoCell2 = document.querySelector("div.section > article > div.article > fieldset > div:nth-child(2) > ul > li:last-child > table.form.nogroup > tbody > tr:first-child > th");

		if (infoCell1.clientWidth > infoCell2.clientWidth) {
			infoCell2.style.minWidth = (infoCell1.clientWidth - 4) + "px";
		} else {
			infoCell1.style.minWidth = (infoCell2.clientWidth - 4) + "px";
		}

		if (this.dataset.is_admin) {
			var versionName = this.dataset.version_info.name;
			if (versionName != "-") {
				// document.title = "A-leave " + versionName + " :: Annual leave management system";
				$jnode$.cachePreventVersion = versionName;
			}

			var upgraderContainer = document.querySelector("div.section > article > div.article > fieldset > div:last-child");
			upgraderContainer.style.display = "block";

			upgraderContainer.querySelector("div > a").addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/setting/upgrade", {
					icon:     true,
					title:    "A-leave 버전 업그레이드",
					width:    420,
					height:   114
				});
			}, false);
		}
	}
};