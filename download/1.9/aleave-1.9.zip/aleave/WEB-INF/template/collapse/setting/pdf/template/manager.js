$content$.setting.pdf.template.manager = {
	service: function() {
		var pdfType = this.dataset.pdf_type;

		$jnode$.requireContent("popup", "/user/select", {
			open:       false,
			useLoading: true,
			widthP:     100,
			maxWidth:   360,
			height:     300
		});

		document.managerForm.manager_id.addEventListener("click", function(event) {
			$content$.user.select.dataset.input_name = "manager_id";

			var userDiv = document.querySelector("aside.popup article > div.popup > ul:last-child > li:first-child > div");
			var selectedUser = document.querySelector("aside.tree.org ul > li:last-child > span.checked");
			if (selectedUser)  selectedUser.removeAttribute("class");

			var userId = this.parentNode.getAttribute("id");
			if (userId) {
				var userIdTreeEntry = document.querySelector("aside.tree.org ul[id='" + userId + "'] > li:last-child > span");
				if (userIdTreeEntry)  userIdTreeEntry.setAttribute("class", "checked");

				userDiv.setAttribute("id", userId);
				userDiv.innerHTML = $jnode$.escapeXML(this.value);
			} else {
				userDiv.removeAttribute("id");
				userDiv.innerHTML = "";
			}

			$controller$.popup.open();
		}, false);

		document.managerForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			$controller$.loading.show();

			var params = {
				command:     "updatePdfManager",
				manager_id: document.managerForm.manager_id.parentNode.getAttribute("id"),
				pdf_type:    pdfType
			};

			if (params.manager_id == null)  params.manager_id = "";

			$jnode$.ajax.service({
				"url":      "/ajax/pdf/template.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params":  params,
				"success": function(response) {
					$content$.setting.pdf.template.properties.manager_id = params.manager_id;
					$content$.setting.pdf.template.showNotification();

					$controller$.winup.close();
					$controller$.loading.hide();
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}, false);
	}
};