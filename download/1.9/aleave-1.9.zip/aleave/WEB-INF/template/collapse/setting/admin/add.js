$content$.setting.admin.add = {
	service: function() {
		var userTbody = document.querySelector("aside.grid > div > table > tbody");

		document.querySelector("aside.winup div.winup > form > ul.submit > li > button").addEventListener("click", function(event) {
			var alertMessage = null;
			var alertNode    = this.parentNode.previousElementSibling;

			var params = {
				command:       "addUser",
				user_name:     document.userForm.user_name.value.trim(),
				user_id:       document.userForm.user_id.value.trim(),
				user_password: document.userForm.user_password.value,
				user_note:     document.userForm.user_note.value.trim()
			};

			if (params.user_name == "") {
				alertMessage = "관리자 이름을 입력해주세요.";
				document.userForm.user_name.select();
			} else if (params.user_id == "") {
				alertMessage = "관리자 ID를 입력해 주세요.";
				document.userForm.user_id.select();
			} else if (params.user_id == "-") {
				alertMessage = "관리자 ID는 \"-\"일 수 없습니다.";
				document.userForm.user_id.select();
			} else if (!/^[\w|\.|\-]+$/g.test(params.user_id)) {
				alertMessage = "관리자 ID의 문자열은 영문, 숫자, 밑줄(_), 하이픈(-), 점(.)만 가능합니다.";
				document.userForm.user_id.select();
			} else if (params.user_id.length > 30) {
				alertMessage = "괸리자 ID는 최대 30자까지만 가능합니다.";
				document.userForm.user_id.select();
			} else if (params.user_password == "") {
				alertMessage = "비밀번호를 입력해 주세요.";
				document.userForm.user_password.select();
			} else if (document.userForm.user_password.value != document.userForm.confirm_password.value) {
				alertMessage = "비밀번호와 비밀번호 확인의 값이 다릅니다.";
				document.userForm.confirm_password.select();
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						$content$.setting.admin.appendUserRow(userTbody, params);
						$controller$.grid.clear("thead");
						$controller$.grid.moveBottom();
						userTbody.lastElementChild.click();

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error, [
							{"code":"409", "message":"-" , "callback":function() { alertNode.innerHTML = "이미 사용중인 ID입니다. 다른 값을 입력해주세요."; document.userForm.user_id.select(); }}
						]);

						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.userForm.user_name.focus();
	}
};