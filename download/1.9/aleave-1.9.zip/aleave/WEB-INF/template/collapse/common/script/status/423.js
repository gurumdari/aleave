var alertDiv = document.querySelector("article > div.article > form > div");

function callLogin() {
	var alertMessage = null;

	var params = {
		command:        "login",
		customer_email: document.loginForm.customer_email.value.trim(),
		customer_code:  document.loginForm.customer_code.value,
		device_type:    $jnode$.device.type
	};

	if (params.customer_email == "") {
		alertMessage = "메일주소를 입력해주세요.";
		document.loginForm.customer_email.select();
	} else if (params.customer_code == "") {
		alertMessage = "고객코드를 입력해주세요.";
		document.loginForm.customer_code.focus();
	}

	if (alertMessage) {
		alertDiv.innerHTML = alertMessage;
	} else {
		$controller$.loading.show();

		$jnode$.ajax.service({
			"url":      "/ajax/customer.json",
			"method":   "POST",
			"datatype": "json",
			"headers": {
				"Content-Type": "application/json",
				"Accept":       "application/json"
			},
			"params":  params,
			"success": function(response) {
				document.location.reload();
			},
			"error": function(error) {
				$jnode$.ajax.alertError(error, [
					{"code":"423", "message":"-", "callback":function() {
						alertDiv.innerHTML = error.error_message;
						document.loginForm.customer_email.select();
					}}
				]);

				$controller$.loading.hide();
			}
		});
	}
}

document.loginForm.customer_email.addEventListener("keydown", function(event) {
	var keyCode = event.keyCode || event.which;

	if(keyCode == 13) {
		event.preventDefault();

		if (document.loginForm.customer_email.value.trim() == "") {
			alertDiv.innerHTML = "메일주소를 입력해주세요.";
			document.loginForm.customer_email.select();
		} else {
			alertDiv.innerHTML = "";
			document.loginForm.customer_code.focus();
		}
	}
}, false);

document.loginForm.customer_code.addEventListener("keydown", function(event) {
	var keyCode = event.keyCode || event.which;

	if (keyCode == 13) {
		event.preventDefault();
		callLogin();
	}
}, false);

document.querySelector("article > div.article > form > table > tbody > tr > td:nth-child(3) > button").addEventListener("click", function(event) {
	callLogin();
}, false);

document.loginForm.customer_email.focus();