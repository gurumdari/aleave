$content$.outside.approval.check = {
	service: function() {
		var dataset       = this.dataset;
		var worker        = dataset.worker;
		var approvalInfo  = dataset.approvalInfo;
		var approverList  = dataset.approverList;
		var userId        = approvalInfo.user_id;
		var cancelProcess = approvalInfo.canceled_id > 0;

		var requestPeriodContainer  = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr > td.request_period");
		var stepContainer   = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr > td > div > ul");
		var detailContainer = stepContainer.nextElementSibling;
		var cancelValue     = cancelProcess ? " 취소 " : " ";

		function getType(startTime, endTime) {
			var typeName = null;

			if (startTime == "S") {
				if (endTime == "E") {
					typeName = "외근" + cancelValue + "(종일)";
				} else {
					typeName = "직출" + cancelValue + "(~ " + endTime + "시)";
				}
			} else if (endTime == "E") {
				typeName = "직퇴" + cancelValue + "(" + startTime + "시 ~)";
			} else {
				typeName = "외근" + cancelValue + "(" + startTime + "시 ~ " + endTime + "시)";
			}

			return typeName;
		}

		var requestPeriod = getType(approvalInfo.request_starttime, approvalInfo.request_endtime) + ": ";
		requestPeriod += dateFormatter.format($module$.date.Utils.parse(approvalInfo.request_startdate), dateFormatter.DateStyle.MEDIUM);

		if (approvalInfo.request_startdate != approvalInfo.request_enddate) {
			requestPeriod += " ~ " + dateFormatter.format($module$.date.Utils.parse(approvalInfo.request_enddate), dateFormatter.DateStyle.MEDIUM);
		}

		requestPeriodContainer.innerHTML = requestPeriod;

		var signStep    = "0";
		var waitingId   = null;
		var waitingStep = 1;

		for (var i = 0; i < approverList.length; i++) {
			var approverId = approverList[i].approver_id;

			var approverLi = document.createElement("li");
			stepContainer.appendChild(approverLi);

			var approverLabel = document.createElement("label");
			approverLi.appendChild(approverLabel);

			var approverInput = document.createElement("input");
			approverInput.setAttribute("type", "radio");
			approverInput.setAttribute("name", "step_id");
			approverInput.value = approverId;
			approverLabel.appendChild(approverInput);

			if (approverList[i].sign_status == "waiting") {
				if (waitingId == null) {
					waitingId = approverId;
					approverInput.setAttribute("class", "unchecked");
					waitingStep = i + 1;
				} else {
					approverInput.setAttribute("class", "waiting");
				}
			}

			approverLabel.appendChild(document.createElement("span"));
			approverLabel.appendChild(document.createElement("div"));

			var detailTable = document.createElement("table");
			detailTable.setAttribute("id", approverId);
			detailTable.setAttribute("class", "form nogroup");
			detailContainer.appendChild(detailTable);

			var datailTbody = document.createElement("tbody");
			detailTable.appendChild(datailTbody);

			// 결재자
			var detailRow0 = datailTbody.insertRow(0);

			var detailTh0 = document.createElement("th");
			detailTh0.innerHTML = "결재자";
			detailRow0.appendChild(detailTh0);

			var detailTd0 = document.createElement("td");
			detailTd0.appendChild(document.createTextNode(approverList[i].approver_name + " (" + approverList[i].position_name + ") @ " + approverList[i].org_name));
			detailRow0.appendChild(detailTd0);

			if (approverList[i].agent_id)  detailTd0.setAttribute("class", "agent");

			if (approverId == waitingId) {
				signStep = (i + 1).toString();

				// 전달사항
				var detailRow1 = datailTbody.insertRow(1);

				var detailTh1 = document.createElement("th");
				detailTh1.innerHTML = "전달사항";
				detailRow1.appendChild(detailTh1);

				var detailTd1 = document.createElement("td");
				detailTd1.setAttribute("class", "textarea");
				detailRow1.appendChild(detailTd1);

				var detailText = document.createElement("textarea");
				detailText.setAttribute("name", "approver_comment");
				detailTd1.appendChild(detailText);
			} else if (approverList[i].sign_date) {
				// 결재일
				var detailRow1 = datailTbody.insertRow(1);

				var detailTh1 = document.createElement("th");
				detailTh1.innerHTML = "결재일";
				detailRow1.appendChild(detailTh1);

				var detailTd1 = document.createElement("td");
				detailTd1.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(approverList[i].sign_date), "DEFAULT")));
				detailRow1.appendChild(detailTd1);

				if (userId != approverId) {
					// 전달사항
					var detailRow2 = datailTbody.insertRow(2);

					var detailTh2 = document.createElement("th");
					detailTh2.innerHTML = "전달사항";
					detailRow2.appendChild(detailTh2);

					var detailTd2 = document.createElement("td");
					detailTd2.appendChild(document.createTextNode(approverList[i].approver_comment));
					detailRow2.appendChild(detailTd2);
				}
			}

			approverInput.addEventListener("click", function(event) {
				var selectedTable = detailContainer.querySelector("div > table.selected");
				if (selectedTable)  $jnode$.node.removeClass(selectedTable, "selected");

				var approverId = this.value;
				$jnode$.node.addClass(detailContainer.querySelector("div > table[id='" + approverId + "']"), "selected");
			}, false);
		}

		stepContainer.querySelector("ul > li > label > input[value='" + waitingId + "']").click();

		if (waitingId != worker) {
			document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr > th > span.agent").innerHTML = "(" + waitingStep + "단계 대리 결재)";
		}

		var startLink = document.approvalForm.sign_status[0].parentNode.parentNode.nextElementSibling.firstElementChild.firstElementChild;
		var endLink   = startLink.nextElementSibling.nextElementSibling;

		function dateSelectEvent(dateLink) {
			var windowWidth  = window.innerWidth;
			var popupDomain  = $jnode$.controller.getDomain("popup");
			var popupContent = popupDomain.querySelector($jnode$.selector.controller.popup.content);
			popupContent.innerHTML = "<DIV class=\"calendar\"><DIV></DIV><UL class=\"submit\"><LI></LI><LI><BUTTON class=\"caution\">확인</BUTTON></LI></UL></DIV>";

			popupDomain.querySelector("aside.popup > ul > li > div").setAttribute("class", "calendar_area");

			$controller$.popup.open({
				width:  (windowWidth > 736 ? 246 : 280),
				height: (windowWidth > 736 ? 236 : 325)
			});

			var date     = null;
			var isoValue = dateLink.getAttribute("value");

			if (isoValue) {
				date = $module$.date.Utils.parse(isoValue);
			} else {
				var startValue = startLink.getAttribute("value");
				var endValue   = endLink.getAttribute("value");
				
				if      (startValue)  isoValue = startValue;
				else if (endValue  )  isoValue = endValue;

				if (isoValue) {
					date = $module$.date.Utils.parse(isoValue);
				} else {
					date = new Date();
					isoValue = $module$.date.Utils.format(date);
				}
			}

			var dateCalendar = popupDomain.querySelector("aside.popup article > div.calendar > div");
			var dateLi       = dateCalendar.nextElementSibling.firstElementChild;

			dateLi.innerHTML = $jnode$.escapeXML(dateFormatter.format(date, dateFormatter.DateStyle.LONG));
			dateLi.setAttribute("value", "iso:" + isoValue);

			displayCalendar(date, dateLi, dateCalendar, isoValue);

			dateLi.addEventListener("click", function() {
				var selectedIsoValue = this.getAttribute("value").substring(4);
				displayCalendar(selectedIsoValue, this, dateCalendar, selectedIsoValue);
			}, false);

			dateLi.nextElementSibling.firstElementChild.addEventListener("click", function(event) {
				var selectedIsoValue = dateLi.getAttribute("value").substring(4);
				dateLink.setAttribute("value", selectedIsoValue);
				dateLink.innerHTML = dateFormatter.format($module$.date.Utils.parse(selectedIsoValue), dateFormatter.DateStyle.MEDIUM);

				$controller$.popup.close();
			}, false);
		}

		startLink.addEventListener("click", function(event) {
			dateSelectEvent(this);
		}, false);

		endLink.addEventListener("click", function(event) {
			dateSelectEvent(this);
		}, false);

		if (approvalInfo.outside_starttime == "S")  approvalInfo.outside_starttime = "-";

		document.approvalForm.outside_starttime.value = approvalInfo.outside_starttime;
		document.approvalForm.outside_endtime.value   = approvalInfo.outside_endtime;

		document.approvalForm.sign_status[0].addEventListener("click", function(event) {
			var applyPeriodDiv = this.parentNode.parentNode.nextElementSibling.firstElementChild;
			var applyTimeDiv   = applyPeriodDiv.nextElementSibling;

			applyPeriodDiv.removeAttribute("style");
			applyTimeDiv.removeAttribute("style");
		}, false);

		document.approvalForm.sign_status[1].addEventListener("click", function(event) {
			var applyPeriodDiv = this.parentNode.parentNode.nextElementSibling.firstElementChild;
			var applyTimeDiv   = applyPeriodDiv.nextElementSibling;

			applyPeriodDiv.style.display = "none";
			applyTimeDiv.style.display = "none";
		}, false);

		var approverComment = document.approvalForm.approver_comment;

		approverComment.addEventListener("keydown", function(event) {
			var keyCode = event.keyCode || event.which;

			if(keyCode == 13) {
				event.preventDefault();
			}
		}, false);

		approverComment.addEventListener("paste", function(event) {
			window.setTimeout(function() {
				approverComment.value = approverComment.value.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");
			});
		}, false);

		document.querySelector("aside.winup article > div.winup > form > ul.submit > li > button").addEventListener("click", function(event) {
			var alertMessage = "";

			var params = {
				command:          "updateApprover",
				outside_id:       dataset.outside_id,
				approver_id:      waitingId,
				approver_comment: approverComment.value.trim(),
				sign_status:      document.approvalForm.sign_status.value,
				sign_step:        signStep,
				canceled_id:      "0"
			};

			if (waitingId != worker) {
				params.agent_id = worker;
			}

			if (document.approvalForm.sign_status[0].checked) {
				params.sign_status       = "approved";
				params.outside_starttime = document.approvalForm.outside_starttime.value;
				params.outside_endtime   = document.approvalForm.outside_endtime.value;

				var outsideStartdate = startLink.getAttribute("value");
				var outsideEnddate   = endLink.getAttribute("value");

				if (outsideStartdate > outsideEnddate) {
					alertMessage = "끝나는 날짜가 시작 날짜보다 빠를 수 없습니다.";
				} else if (params.outside_starttime >= params.outside_endtime) {
					alertMessage = "외근 시작 시간은 종료 시간보다 빨라야 합니다.";
				} else {
					if (params.outside_starttime == "-")  params.outside_starttime = "S";

					params.outside_year = parseInt(outsideStartdate.split("-")[0], 10).toString();

					params.outside_startdate = outsideStartdate;
					params.outside_enddate   = outsideEnddate;
				}
			} else {
				params.sign_status = "rejected";
				params.sign_step   = "-" + signStep;
				params.canceled_id = approvalInfo.canceled_id.toString();
			}

			if (alertMessage) {
				this.parentNode.previousElementSibling.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				var lastApprover = (signStep == approvalInfo.approval_step.toString());

				if (lastApprover) {
					params.canceled_id = approvalInfo.canceled_id.toString();
				}

				$jnode$.ajax.service({
					"url":      "/ajax/outside.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						var selectedRow = document.querySelector("aside.grid > div > table > tbody > tr.selected");
						var stepCell    = selectedRow.firstElementChild;
						var typeCell    = stepCell.nextElementSibling;
						var periodCell  = typeCell.nextElementSibling.nextElementSibling;

						if (waitingId == worker) {
							selectedRow.setAttribute("class", params.sign_status + " selected");
							stepCell.innerHTML = signStep + " (" + signStep + "/" + approvalInfo.approval_step + ")";
							document.querySelector("div.section > article > div.article > fieldset > button > div").innerHTML = "상세정보";
						} else {
							if (params.sign_status == "rejected") {
								selectedRow.setAttribute("class", "rejected selected");
								document.querySelector("div.section > article > div.article > fieldset > button > div").innerHTML = "상세정보";
							} else if (lastApprover) {
								selectedRow.setAttribute("class", "approved selected");
								document.querySelector("div.section > article > div.article > fieldset > button > div").innerHTML = "상세정보";
							}

							stepCell.innerHTML = signStep + "/" + approvalInfo.approval_step;
						}

						if (params.sign_status == "rejected") {
							typeCell.setAttribute("class", "rejected");
							if (cancelProcess)  stepCell.nextElementSibling.setAttribute("class", "rejected cancel");
							selectedRow.lastElementChild.innerHTML = "반려";
						} else {
							// TODO: 승인 날짜 반영
							var approvalPeriod = dateFormatter.format($module$.date.Utils.parse(params.outside_startdate), dateFormatter.DateStyle.MEDIUM);

							if (params.outside_startdate != params.outside_enddate) {
								approvalPeriod += " ~ " + dateFormatter.format($module$.date.Utils.parse(params.outside_enddate), dateFormatter.DateStyle.MEDIUM);
							}

							typeCell.lastElementChild.firstChild.nodeValue = getType(params.outside_starttime, params.outside_endtime);
							periodCell.firstChild.nodeValue = approvalPeriod;

							if (lastApprover) {
								stepCell.nextElementSibling.setAttribute("class", "approved");
								if (cancelProcess)  stepCell.nextElementSibling.setAttribute("class", "approved cancel");
								selectedRow.lastElementChild.innerHTML = "승인";
							}
						}

						if ($content$.outside.dataset.is_admin == false) {
							var outsideMenu  = document.querySelector("body > nav > ul > li > label > input[value='/outside'] + span");
							var checkedCount = document.querySelectorAll("aside.grid > div > table > tbody > tr.unchecked").length;

							if (checkedCount == 0)  outsideMenu.removeAttribute("class");
							else                    outsideMenu.setAttribute("class", checkedCount);
						}

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);
	}
};