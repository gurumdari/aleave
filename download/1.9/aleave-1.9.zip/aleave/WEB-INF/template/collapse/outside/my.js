$content$.outside.my = {
	appendOutsideRow: function(outsideTbody, outsideData, isFirst) {
		var row = document.createElement("tr");
		row.setAttribute("id", outsideData.outside_id);

		if (isFirst) {
			outsideTbody.insertBefore(row, outsideTbody.firstElementChild);
		} else {
			outsideTbody.appendChild(row);
		}

		var outsideType = null;
		var cancelValue = (outsideData.canceled_id > 0) ? " 취소 " : " ";

		if (outsideData.outside_starttime == "S") {
			if (outsideData.outside_endtime == "E") {
				outsideType = "외근" + cancelValue + "(종일)";
			} else {
				outsideType = "직출" + cancelValue + "(~ " + outsideData.outside_endtime + "시)";
			}
		} else if (outsideData.outside_endtime == "E") {
			outsideType = "직퇴" + cancelValue + "(" + outsideData.outside_starttime + "시 ~)";
		} else {
			outsideType = "외근" + cancelValue + "(" + outsideData.outside_starttime + "시 ~ " + outsideData.outside_endtime + "시)";
		}

		var typeCell = row.insertCell(0);
		typeCell.appendChild(document.createTextNode(outsideType));

		var destinationCell = row.insertCell(1);
		destinationCell.appendChild(document.createTextNode(outsideData.destination));

		var periodValue = dateFormatter.format($module$.date.Utils.parse(outsideData.outside_startdate), dateFormatter.DateStyle.MEDIUM);

		if (outsideData.outside_startdate != outsideData.outside_enddate) {
			periodValue += " ~ " + dateFormatter.format($module$.date.Utils.parse(outsideData.outside_enddate), dateFormatter.DateStyle.MEDIUM);
		}

		var periodCell = row.insertCell(2);
		periodCell.appendChild(document.createTextNode(periodValue));

		var createCell = row.insertCell(3);
		createCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(outsideData.create_date), dateFormatter.DateStyle.MEDIUM)));

		var statusValue = "";
		if (outsideData.sign_step < 0) {
			statusValue = "반려 (" + (outsideData.sign_step * -1) + "/" + outsideData.approval_step + ")";
			typeCell.setAttribute("class", "rejected");
		} else if (outsideData.approval_step > outsideData.sign_step) {
			statusValue = "대기 (" + outsideData.sign_step + "/" + outsideData.approval_step + ")";
			typeCell.setAttribute("class", "waiting");
		} else {
			statusValue = "승인";
			typeCell.setAttribute("class", "approved");
		}

		if (outsideData.canceled_id > 0) {
			$jnode$.node.addClass(typeCell, "cancel");

			destinationCell.setAttribute("class", "cancel");
			periodCell.setAttribute("class", "cancel");
		}

		var statusCell = row.insertCell(4);
		statusCell.appendChild(document.createTextNode(statusValue));

		row.addEventListener("click", function(event) {
			var selectedRow = outsideTbody.querySelector("tbody > tr.selected");
			if (selectedRow)  selectedRow.removeAttribute("class");

			this.setAttribute("class", "selected");
			document.querySelector("div.section > article > div.article > fieldset > button:nth-child(2)").disabled = false;
		}, false);

		return row;
	},

	getOutsideList: function(year, outsideId) {
		$controller$.loading.show();
		var dataset = this.dataset;

		$jnode$.ajax.service({
			"url":      "/ajax/outside.json",
			"method":   "POST",
			"datatype": "json",
			"headers": {
				"Content-Type": "application/json",
				"Accept":       "application/json"
			},
			"params":  {
				command: "getOutsideList",
				user_id: dataset.worker,
				year:    year
			},
			"success": function(response) {
				$controller$.grid.clear("tbody");

				document.querySelector("div.section > article > div.article > fieldset > button:nth-child(2)").disabled = true;
				var outsideTbody  = document.querySelector("aside.grid > div > table > tbody");

				for (var i = 0; i < response.outsideList.length; i++) {
					$content$.outside.my.appendOutsideRow(outsideTbody, response.outsideList[i]);
				}

				if (outsideId) {
					var selectedRow = outsideTbody.querySelector("tbody > tr[id='" + outsideId + "']");
					if (selectedRow)  selectedRow.click();
				}

				$controller$.loading.hide();
			},
			"error": function(error) {
				$jnode$.ajax.alertError(error);
				$controller$.loading.hide();
			}
		});
	},

	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if (windowWidth > 736) {
			$controller$.grid.resize(null, windowHeight - 178);
		} else {
			$controller$.grid.removeHeight();
		}

		$controller$.grid.resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();

		var that       = this;
		var dataset    = this.dataset;
		var leaveBasic = dataset.leave_basic;

		$jnode$.pushHistory(this.conf);

		var curYear  = this.dataset.cur_year;
		var yearList = this.dataset.year_list;
		if (yearList.indexOf(curYear) < 0) {
			yearList.push(curYear);
			yearList = yearList.sort().reverse();
		}

		var yearSubfix = "";
		if (leaveBasic == "entry_month") {
			yearSubfix = " " + this.dataset.entry_month + "월 ~";
		}

		var yearSelect    = document.querySelector("body > section > div.section > article > div.article > ul > li:first-child > select");
		var requestButton = document.querySelector("div.section > article > div.article > fieldset > button:first-child");
		var editButton    = requestButton.nextElementSibling;

		editButton.disabled = true;

		for (var i = 0; i < yearList.length; i++) {
			yearSelect.add(new Option(yearList[i] + "년" + yearSubfix, yearList[i]));
		}

		$jnode$.requireController("grid", {caller:that.conf}).on(function() {
			$controller$.grid.service();

			var outsideTbody = document.querySelector("aside.grid > div > table > tbody");

			window.addEventListener("resize", that.resize, false);
			that.resize();

			$content$.outside.my.getOutsideList(yearSelect.value);

			yearSelect.addEventListener("change", function(event) {
				$content$.outside.my.getOutsideList(this.value);
			}, false);

			requestButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/outside/my/request", {
					useLoading: true,
					icon:       true,
					title:      "외근 신청",
					width:      480,
					height:     431
				});
			}, false);

			editButton.addEventListener("click", function(event) {
				var selectedRow = outsideTbody.querySelector("tbody > tr.selected");

				$jnode$.requireContent("winup", "/outside/approval/view", {
					useLoading: true,
					icon:       true,
					title:      "외근 결재처리 진행상황",
					width:      480,
					height:     417,
					outside_id: selectedRow.getAttribute("id")
				});
			}, false);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};