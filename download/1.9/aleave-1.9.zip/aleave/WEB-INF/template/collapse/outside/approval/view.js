$content$.outside.approval.view = {
	service: function() {
		var dataset      = this.dataset;
		var worker       = dataset.worker;
		var approvalInfo = dataset.approvalInfo;
		var approverList = dataset.approverList;

		var requestPeriodContainer  = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr > td.request_period");
		var approvalPeriodContainer = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr > td.approval_period");
		var stepContainer    = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr > td > div > ul");
		var detailContainer  = stepContainer.nextElementSibling;
		var lastStepApprover = worker;

		var cancelValue = (approvalInfo.canceled_id > 0) ? " 취소 " : " ";
		var requestPeriod  = null;
		var approvalPeriod = null;

		if (approvalInfo.request_starttime == "S") {
			if (approvalInfo.request_endtime == "E") {
				requestPeriod = "외근" + cancelValue + "(종일): ";
			} else {
				requestPeriod = "직출" + cancelValue + "(~ " + approvalInfo.request_endtime + "시): ";
			}
		} else if (approvalInfo.request_endtime == "E") {
			requestPeriod = "직퇴" + cancelValue + "(" + approvalInfo.request_starttime + "시 ~): ";
		} else {
			requestPeriod = "외근" + cancelValue + "(" + approvalInfo.request_starttime + "시 ~ " + approvalInfo.request_endtime + "시): ";
		}

		requestPeriod += dateFormatter.format($module$.date.Utils.parse(approvalInfo.request_startdate) , dateFormatter.DateStyle.MEDIUM);

		if (approvalInfo.request_startdate != approvalInfo.request_enddate) {
			requestPeriod += " ~ " + dateFormatter.format($module$.date.Utils.parse(approvalInfo.request_enddate) , dateFormatter.DateStyle.MEDIUM);
		}

		if (approvalInfo.outside_starttime == "S") {
			if (approvalInfo.outside_endtime == "E") {
				approvalPeriod = "외근" + cancelValue + "(종일): ";
			} else {
				approvalPeriod = "직출" + cancelValue + "(~ " + approvalInfo.outside_endtime + "시): ";
			}
		} else if (approvalInfo.outside_endtime == "E") {
			approvalPeriod = "직퇴" + cancelValue + "(" + approvalInfo.outside_starttime + "시 ~): ";
		} else {
			approvalPeriod = "외근" + cancelValue + "(" + approvalInfo.outside_starttime + "시 ~ " + approvalInfo.outside_endtime + "시): ";
		}

		approvalPeriod += dateFormatter.format($module$.date.Utils.parse(approvalInfo.outside_startdate), dateFormatter.DateStyle.MEDIUM);

		if (approvalInfo.outside_startdate != approvalInfo.outside_enddate) {
			approvalPeriod += " ~ " + dateFormatter.format($module$.date.Utils.parse(approvalInfo.outside_enddate), dateFormatter.DateStyle.MEDIUM);
		}

		requestPeriodContainer.innerHTML = requestPeriod;

		if (approvalPeriodContainer)  approvalPeriodContainer.innerHTML = approvalPeriod;

		for (var i = 0; i < approverList.length; i++) {
			var approverId = approverList[i].approver_id;

			var approverLi = document.createElement("li");
			stepContainer.appendChild(approverLi);

			var approverLabel = document.createElement("label");
			approverLi.appendChild(approverLabel);

			var approverInput = document.createElement("input");
			approverInput.setAttribute("type", "radio");
			approverInput.setAttribute("name", "step_id");
			approverInput.value = approverId;
			approverLabel.appendChild(approverInput);

			if (approverList[i].sign_status == "waiting") {
				approverInput.setAttribute("class", "waiting");
			}

			approverLabel.appendChild(document.createElement("span"));
			approverLabel.appendChild(document.createElement("div"));

			var detailTable = document.createElement("table");
			detailTable.setAttribute("id", approverId);
			detailTable.setAttribute("class", "form nogroup");
			detailContainer.appendChild(detailTable);

			var datailTbody = document.createElement("tbody");
			detailTable.appendChild(datailTbody);

			// 결재자
			var detailRow0 = datailTbody.insertRow(0);

			var detailTh0 = document.createElement("th");
			detailTh0.innerHTML = "결재자";
			detailRow0.appendChild(detailTh0);

			var detailTd0 = document.createElement("td");
			detailTd0.appendChild(document.createTextNode(approverList[i].approver_name + " (" + approverList[i].position_name + ") @ " + approverList[i].org_name));
			detailRow0.appendChild(detailTd0);

			if (approverList[i].agent_id)  detailTd0.setAttribute("class", "agent");

			if (approverList[i].sign_date) {
				lastStepApprover = approverId;

				// 결재일
				var detailRow1 = datailTbody.insertRow(1);

				var detailTh1 = document.createElement("th");
				detailTh1.innerHTML = "결재일";
				detailRow1.appendChild(detailTh1);

				var detailTd1 = document.createElement("td");
				detailTd1.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(approverList[i].sign_date), "DEFAULT")));
				detailRow1.appendChild(detailTd1);

				if (approvalInfo.user_id != approverId) {
					// 전달사항
					var detailRow2 = datailTbody.insertRow(2);

					var detailTh2 = document.createElement("th");
					detailTh2.innerHTML = "전달사항";
					detailRow2.appendChild(detailTh2);

					var detailTd2 = document.createElement("td");
					detailTd2.appendChild(document.createTextNode(approverList[i].approver_comment));
					detailRow2.appendChild(detailTd2);
				}
			}

			approverInput.addEventListener("click", function(event) {
				var selectedTable = detailContainer.querySelector("div > table.selected");
				if (selectedTable)  $jnode$.node.removeClass(selectedTable, "selected");

				var approverId = this.value;
				$jnode$.node.addClass(detailContainer.querySelector("div > table[id='" + approverId + "']"), "selected");
			}, false);
		}

		stepContainer.querySelector("ul > li > label > input[value='" + lastStepApprover + "']").click();

		var cancelButton = document.approvalForm.querySelector("form > ul.submit > li > button");
		if (cancelButton) {
			$controller$.winup.resize(null, 455);

			cancelButton.addEventListener("click", function(event) {
				$jnode$.requireContent("popup", "/outside/my/cancel", {
					outside_id: approvalInfo.outside_id,
					width:  280,
					height: 206
				});
			}, false);
		}
	}
};