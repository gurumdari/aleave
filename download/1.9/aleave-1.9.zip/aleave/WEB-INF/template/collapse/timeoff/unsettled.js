$content$.timeoff.unsettled = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if (windowWidth > 736) {
			$controller$.grid.resize(null, windowHeight - 146);
		} else {
			$controller$.grid.removeHeight();
		}

		$controller$.grid.resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();

		var that          = this;
		var dataset       = this.dataset;
		var worker        = dataset.worker;
		var unsettledList = dataset.unsettledList;

		$jnode$.pushHistory(this.conf);

		var approvalButton = document.querySelector("div.section > article > div.article > fieldset > button");
		approvalButton.disabled = true;

		$jnode$.requireController("grid", {caller:that.conf}).on(function() {
			$controller$.grid.service();

			var unsettledTbody = document.querySelector("aside.grid > div > table > tbody");

			window.addEventListener("resize", that.resize, false);
			that.resize();

			function appendUnsettledRow(unsettledData) {
				var row = document.createElement("tr");
				row.setAttribute("id", unsettledData.timeoff_id);
				row.setAttribute("class", "waiting");
				unsettledTbody.appendChild(row);

				var stepCell = row.insertCell(0);
				stepCell.appendChild(document.createTextNode(Math.abs(unsettledData.sign_step) + "/" + unsettledData.approval_step));

				var typeCell = row.insertCell(1);
				typeCell.appendChild(document.createTextNode(unsettledData.user_name + " - " + unsettledData.type_name));

				if (unsettledData.timeoff_end == null)  unsettledData.timeoff_end = "";

				var periodValue   = "";
				var timeoffStarts = unsettledData.timeoff_start.split(" ");
				var timeoffEnds   = unsettledData.timeoff_end.split(" ");

				if (timeoffEnds.length == 1) {
					// 결근은 timeoffData.timeoff_end가 빈 문자로 넘어옴
					periodValue = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM) + " " + timeoffStarts[1];
				} else if (timeoffStarts[0] == timeoffEnds[0]) {
					periodValue = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM);
					if (timeoffStarts[1] == timeoffEnds[1])  periodValue += " " + (timeoffStarts[1] == "AM" ? "오전" : "오후");
				} else {
					var periodValue1 = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM);
					var periodValue2 = dateFormatter.format($module$.date.Utils.parse(timeoffEnds[0]), dateFormatter.DateStyle.MEDIUM);
					
					if (timeoffStarts[1] == "PM")  periodValue1 += " 오후";
					if (timeoffEnds[1]   == "AM")  periodValue2 += " 오전";

					periodValue = periodValue1 + " ~ " + periodValue2;
				}

				var periodCell = row.insertCell(2);
				periodCell.appendChild(document.createTextNode(periodValue));

				var requestDays = unsettledData.request_days;

				if (unsettledData.canceled_id > 0) {
					requestDays = requestDays * -1;
				}

				var requestDaysValue = unsettledData.applied_days;
				if ((unsettledData.sign_step > 0) && (unsettledData.approval_step > unsettledData.sign_step)) {
					requestDaysValue = requestDays;
				} else if (requestDays != unsettledData.applied_days) {
					requestDaysValue = requestDays + "→" + unsettledData.applied_days;
				}

				var requestDaysCell = row.insertCell(3);
				requestDaysCell.appendChild(document.createTextNode(requestDaysValue));

				var usedDaysCell = row.insertCell(4);
				usedDaysCell.appendChild(document.createTextNode(unsettledData.used_days + "/" + unsettledData.available_days));

				var createCell = row.insertCell(5);
				createCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(unsettledData.create_date), dateFormatter.DateStyle.MEDIUM)));

				var statusValue = "";
				if (unsettledData.sign_step < 0) {
					statusValue = "반려";
					typeCell.setAttribute("class", "rejected");
				} else if (unsettledData.approval_step > unsettledData.sign_step) {
					statusValue = "대기";
					typeCell.setAttribute("class", "waiting");
				} else {
					statusValue = "승인";
					typeCell.setAttribute("class", "approved");
				}

				if (unsettledData.canceled_id > 0) {
					$jnode$.node.addClass(typeCell, "cancel");
					typeCell.appendChild(document.createTextNode(" 취소"));

					periodCell.setAttribute("class", "cancel");
				}

				var statusCell = row.insertCell(6);
				statusCell.appendChild(document.createTextNode(statusValue));

				row.addEventListener("click", function(event) {
					var selectedRow = unsettledTbody.querySelector("tbody > tr.selected");
					if (selectedRow)  $jnode$.node.removeClass(selectedRow, "selected");

					$jnode$.node.addClass(this, "selected");

					approvalButton.disabled = false;

					if ($jnode$.node.hasClass(this, "waiting")) {
						approvalButton.firstElementChild.innerHTML = "결재처리";
					} else {
						approvalButton.firstElementChild.innerHTML = "상세정보";
					}
				}, false);
			}

			for (var i = 0; i < unsettledList.length; i++) {
				appendUnsettledRow(unsettledList[i]);
			}

			$controller$.loading.hide();

			approvalButton.addEventListener("click", function(event) {
				var selectedRow = unsettledTbody.querySelector("tbody > tr.selected");
				var nodeId    = "/timeoff/approval/view";
				var winupName = "휴가 및 결근 상세정보";
				var height    = 386;

				if ($jnode$.node.hasClass(selectedRow, "waiting")) {
					nodeId    = "/timeoff/approval/check";
					winupName = "휴가 및 결근 결재처리";
					height    = 424;
				}

				$jnode$.requireContent("winup", nodeId, {
					useLoading: true,
					icon:       true,
					title:      winupName,
					width:      480,
					height:     height,
					timeoff_id: selectedRow.getAttribute("id")
				});
			}, false);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};