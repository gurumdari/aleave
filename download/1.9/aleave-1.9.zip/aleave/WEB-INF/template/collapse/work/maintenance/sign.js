$content$.work.maintenance.sign = {
	service: function() {
		var nodeConf = this.conf;

		$jnode$.requireScript("/common/script/responsive-sketchpad.js", this.conf).on(function() {
			var canvasContainer = document.querySelector("aside.popup article > div.popup > div.sketchpad");

			var pad = new Sketchpad(canvasContainer, {
				line: {
					color: "#000000",
					size: 3
				},
				width: 264,
				height: 240,
				watermark: "유보보수활동 내역서용"
			});

			var okButton = document.signForm.querySelector("form > ul.submit > li > button:first-child");
			var clearButton = okButton.nextElementSibling;

			okButton.addEventListener("click", function(event) {
				if (pad.empty()) {
					this.parentNode.previousElementSibling.innerHTML = "서명해주세요.";
				} else {
					$controller$.loading.show();

					var params = {
						maintenance_id:      nodeConf.maintenance_id,
						sign_step:           nodeConf.sign_step,
						maintenance_comment: "",
						data_url:            canvasContainer.firstElementChild.toDataURL("image/png")
					};

					if (params.sign_step == "1") {
						params.approver_ids  = nodeConf.approver_ids;
						params.approval_step = nodeConf.approval_step;
					} else {
						params.maintenance_comment = document.pdfForm.nextElementSibling.querySelector("div > div > div > div.textarea > textarea").value.trim();
					}

					$jnode$.ajax.service({
						"url":      "/ajax/sign.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":  params,
						"success": function(response) {
							$controller$.popup.close();

							if (params.sign_step == "0") {
								document.location.reload();
							} else {
								var selectedRow   = document.querySelector("aside.grid > div > table > tbody > tr.selected");
								var statusCell    = selectedRow.querySelector("tr > td:last-child");
								var approveButton = document.querySelector("div.section > article > div.article > fieldset > button:last-child");

								statusCell.firstChild.nodeValue = (nodeConf.approval_step == params.sign_step ? "승인" : "결재중");
								statusCell.setAttribute("value", "결재상태")
								approveButton.firstElementChild.firstChild.nodeValue = "결재상태";

								$jnode$.node.removeClass(selectedRow, "unchecked");

								$controller$["popup#sign"].close();
								approveButton.click();
							}
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			}, false);

			clearButton.addEventListener("click", function(event) {
				pad.clear();
			}, false);
		});
	}
};