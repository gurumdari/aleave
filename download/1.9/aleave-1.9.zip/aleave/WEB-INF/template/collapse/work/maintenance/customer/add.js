$content$.work.maintenance.customer.add = {
	service: function() {
		document.customerForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var alertMessage = null;
			var alertNode    = this.parentNode.previousElementSibling;

			var params = {
				command:          "addCustomer",
				customer_company: document.customerForm.customer_company.value.trim(),
				customer_name:    document.customerForm.customer_name.value.trim(),
				customer_org:     document.customerForm.customer_org.value.trim(),
				customer_contact: document.customerForm.customer_contact.value.trim(),
				customer_email:   document.customerForm.customer_email.value.trim(),
				share:            document.customerForm.share.value
			};

			if (params.customer_company == "") {
				alertMessage = "고객사명을 입력해주세요.";
				document.customerForm.customer_company.select();
			} else if (params.customer_name == "") {
				alertMessage = "담당자를 입력해 주세요.";
				document.customerForm.customer_name.select();
			} else if (params.customer_org == "") {
				alertMessage = "소속을 입력해 주세요.";
				document.customerForm.customer_org.select();
			} else if (params.customer_contact == "") {
				alertMessage = "연락처를 입력해 주세요.";
				document.customerForm.customer_contact.select();
			} else if (params.customer_email == "") {
				alertMessage = "E-mail을 입력해 주세요.";
				document.customerForm.customer_email.select();
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/work.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						var customerTbody = document.querySelector("aside.grid#customer > div > table > tbody");

						params.customer_id = response.customer_id;
						params.user_id     = response.user_id;

						$content$.work.maintenance.customer.appendCustomerRow(customerTbody, params);
						$controller$.grid.clear("thead");
						$controller$.grid.moveBottom();
						customerTbody.lastElementChild.click();

						$controller$["winup#customer"].close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.customerForm.customer_company.focus();
	}
};