$content$.work.certificate.my = {
	appendCertificateRow: function(certificateTbody, certificateData, isFirst) {
		var row = document.createElement("tr");
		row.setAttribute("id", certificateData.certificate_id);

		if (isFirst) {
			certificateTbody.insertBefore(row, certificateTbody.firstElementChild);
		} else {
			certificateTbody.appendChild(row);
		}

		var requestCell = row.insertCell(0);
		requestCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(certificateData.request_date), dateFormatter.DateStyle.MEDIUM)));

		var issuedCell = row.insertCell(1);
		if (certificateData.issued_date) {
			issuedCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(certificateData.issued_date), dateFormatter.DateStyle.MEDIUM)));
		}

		var usageCell = row.insertCell(2);
		usageCell.appendChild(document.createTextNode(certificateData.usage_value));

		var commentCell = row.insertCell(3);
		commentCell.appendChild(document.createTextNode(certificateData.request_comment));

		row.addEventListener("click", function(event) {
			var selectedRow = certificateTbody.querySelector("tbody > tr.selected");
			if (selectedRow)  selectedRow.removeAttribute("class");

			this.setAttribute("class", "selected");
		}, false);

		return row;
	},

	getCertificateList: function(year, certificateId) {
		$controller$.loading.show();
		var worker = this.dataset.worker;

		$jnode$.ajax.service({
			"url":      "/ajax/work.json",
			"method":   "POST",
			"datatype": "json",
			"headers": {
				"Content-Type": "application/json",
				"Accept":       "application/json"
			},
			"params":  {
				command: "getCertificateList",
				user_id: worker,
				year:    year
			},
			"success": function(response) {
				$controller$.grid.clear("tbody");

				var certificateTbody  = document.querySelector("aside.grid > div > table > tbody");

				for (var i = 0; i < response.certificateList.length; i++) {
					$content$.work.certificate.my.appendCertificateRow(certificateTbody, response.certificateList[i]);
				}

				if (certificateId) {
					var selectedRow = certificateTbody.querySelector("tbody > tr[id='" + certificateId + "']");
					if (selectedRow)  selectedRow.click();
				}

				$controller$.loading.hide();
			},
			"error": function(error) {
				$jnode$.ajax.alertError(error);
				$controller$.loading.hide();
			}
		});
	},

	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if ($content$.work.certificate.my.dataset.status == 0) {
			if (windowWidth > 736) {
				windowHeight -= 114;
			} else if (windowWidth > 640) {
				windowHeight -= 219;
			} else {
				windowHeight -= 239;
			}

			document.querySelector("body > section > div.section > article > div.article > ul.not_set").style.height = windowHeight + "px";
		} else {
			if (windowWidth > 736) {
				$controller$.grid.resize(null, windowHeight - 178);
			} else {
				$controller$.grid.removeHeight();
			}

			$controller$.grid.resizeScrollButtons();
		}
	},

	service: function() {
		$jnode$.pushHistory(this.conf);

		if (this.dataset.status == 0) {
			this.resize();
			window.addEventListener("resize", this.resize, false);
		} else {
			$controller$.loading.show();

			var that = this;

			var curYear  = this.dataset.cur_year;
			var yearList = this.dataset.year_list;
			if (yearList.indexOf(curYear) < 0) {
				yearList.push(curYear);
				yearList = yearList.sort().reverse();
			}

			var yearSelect    = document.querySelector("body > section > div.section > article > div.article > ul > li:first-child > select");
			var requestButton = document.querySelector("div.section > article > div.article > fieldset > button:first-child");

			for (var i = 0; i < yearList.length; i++) {
				yearSelect.add(new Option(yearList[i] + "년", yearList[i]));
			}

			$jnode$.requireController("grid", {caller:that.conf}).on(function() {
				$controller$.grid.service();

				window.addEventListener("resize", that.resize, false);
				that.resize();

				$content$.work.certificate.my.getCertificateList(yearSelect.value);

				yearSelect.addEventListener("change", function(event) {
					$content$.work.certificate.my.getCertificateList(this.value);
				}, false);

				requestButton.addEventListener("click", function(event) {
					if (that.dataset.has_info) {
						$jnode$.requireContent("winup", "/work/certificate/my/request", {
							icon:       true,
							title:      "재직증명서 발급요청",
							width:      480,
							height:     232,
							renderer:   "-j",
							manager_id: that.dataset.manager_info.user_id
						});
					} else {
						$controller$.prompt.confirm("생년월일과 주소는 재직증명서에서 필요로 하는 정보입니다. \"개인 정보\" 화면으로 이동하겠습니까?", function(close) {
							linkArticle("/setting/account");
							close();
						}, null, 1);
					}
				}, false);
			});
		}
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};