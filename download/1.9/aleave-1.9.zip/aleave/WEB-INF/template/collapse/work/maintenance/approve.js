$content$.work.maintenance.approve = {
	resize: function() {
		var iframeHeight = window.innerHeight - 50;

		if (iframeHeight < 223)  iframeHeight = 223;
	
		document.querySelector("aside.popup article > div.popup > ul > li:first-child > iframe").style.height = iframeHeight + "px";
	},

	service: function() {
		var that     = this;
		var signStep = (this.dataset.sign_step + 1).toString();

		window.addEventListener("resize", this.resize, false);
		this.resize();

		document.pdfForm.action = $jnode$.contextPath + "/work/pdf/maintenance/A-leave (유지보수활동 내역서).pdf";  // #toolbar=0
		var okButton     = document.querySelector("aside.popup article > div.popup > ul > li:last-child > div > div > div > ul.submit > li:last-child > button:first-child");
		var cancelButton = okButton.nextElementSibling;

		if (this.conf.allow_embedded == 1) {
			document.pdfForm.target = "pdfFrame";
			document.pdfForm.submit();
		} else {
			okButton.parentNode.previousElementSibling.firstElementChild.addEventListener("click", function() {
				document.pdfForm.submit();
			}, false);
		}

		var commentText = document.pdfForm.nextElementSibling.querySelector("div > div > div > div.textarea > textarea");

		commentText.addEventListener("keydown", function(event) {
			var keyCode = event.keyCode || event.which;

			if(keyCode == 13) {
				event.preventDefault();
			}
		}, false);

		commentText.addEventListener("paste", function(event) {
			window.setTimeout(function() {
				commentText.value = commentText.value.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");
			});
		}, false);

		$jnode$.requireController("popup#sign", {caller:that.conf}).on(function() {
			okButton.addEventListener("click", function(event) {
				$jnode$.requireContent("popup#sign", "/work/maintenance/sign", {
					width:          276,
					height:         330,
					maintenance_id: document.pdfForm.maintenance_id.value,
					sign_step:      signStep,
					approval_step:  that.dataset.approval_step.toString()
				});
			}, false);
		});

		cancelButton.addEventListener("click", function(event) {
			var params = {
				maintenance_id:      document.pdfForm.maintenance_id.value,
				sign_step:           "-" + signStep,
				maintenance_comment: commentText.value.trim()
			};

			if (params.maintenance_comment == "") {
				$controller$.prompt.alert("반려 사유를 특이 및 전달 사항에 입력해주세요.", function(close) {
					commentText.select();
					close();
				}, true);
			} else {
				$controller$.prompt.confirm("정말로 반려하겠습니까?", function(close) {
					$controller$.loading.show();

					$jnode$.ajax.service({
						"url":      "/ajax/sign.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":  params,
						"success": function(response) {
							var selectedRow   = document.querySelector("aside.grid > div > table > tbody > tr.selected");
							var statusCell    = selectedRow.querySelector("tr > td:last-child");
							var approveButton = document.querySelector("div.section > article > div.article > fieldset > button:last-child");

							statusCell.firstChild.nodeValue = "반려";
							statusCell.setAttribute("value", "결재상태")
							approveButton.firstElementChild.firstChild.nodeValue = "결재상태";

							$jnode$.node.removeClass(selectedRow, "unchecked");
							approveButton.click();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});

					close();
				}, null, 2);
			}
		}, false);

		document.querySelector("aside.popup article > div.popup > ul > li:last-child > div > button").addEventListener("click", function(event) {
			var fieldsetContainer = this.parentNode;
			if (fieldsetContainer.getAttribute("class") == "hide") {
				fieldsetContainer.setAttribute("class", "show");
			} else {
				fieldsetContainer.setAttribute("class", "hide");
			}
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};