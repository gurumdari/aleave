$content$.work.maintenance.approval_line = {
	resize: function() {
		var iframeHeight = window.innerHeight - 50;

		if (iframeHeight < 223)  iframeHeight = 223;
	
		document.querySelector("aside.popup article > div.popup > ul > li:first-child > iframe").style.height = iframeHeight + "px";
	},

	setApprovalLine: function(approverList, lineId) {
		var approverCount = this.dataset.approverCount;
		var worker = $content$.work.maintenance.approval_line.dataset.worker;
		var lineContainer = document.querySelector("aside.popup article > div.popup > ul > li:last-child > div > div > div > div:nth-child(2) > ul");
		lineContainer.innerHTML = "";

		if (lineId == null) {
			lineId = approverList[0].line_id;
			if (lineId)  lineContainer.setAttribute("id", lineId);
			else         lineContainer.setAttribute("id", "0");

			for (var i = 0; i < approverList.length; i++) {
				var approverId   = approverList[i].approver_id;
				var approverName = (worker == approverId) ? "본인" : approverList[i].approver_name + " (" + approverList[i].position_name + ")";

				var li = document.createElement("li");
				li.setAttribute("id", approverList[i].approver_id);
				li.appendChild(document.createTextNode((i + 1) + "단계: " + approverName + " @ " + approverList[i].org_name));

				if (i + 1 > approverCount)  li.setAttribute("class", "disabled");

				lineContainer.appendChild(li);
			}
		} else {
			lineContainer.setAttribute("id", lineId);
			lineContainer.innerHTML = approverList;
		}
	},

	service: function() {
		var that          = this;
		var worker        = this.dataset.worker;
		var approverCount = this.dataset.approverCount;

		window.addEventListener("resize", this.resize, false);
		this.resize();

		document.pdfForm.action = $jnode$.contextPath + "/work/pdf/maintenance/A-leave (유지보수활동 내역서).pdf";  // #toolbar=0
		var okButton = document.querySelector("aside.popup article > div.popup > ul > li:last-child > div > div > div > ul.submit > li:last-child > button:first-child");

		if (this.conf.allow_embedded == 1) {
			document.pdfForm.target = "pdfFrame";
			document.pdfForm.submit();
		} else {
			okButton.parentNode.previousElementSibling.firstElementChild.addEventListener("click", function() {
				document.pdfForm.submit();
			}, false);
		}

		this.setApprovalLine(this.dataset.approvalLineList[0]);

		var lineSelectButton = document.querySelector("aside.popup article > div.popup > ul > li:last-child > div > div > div > div:first-child > button");
		lineSelectButton.addEventListener("click", function(event) {
			var options = {
				height:  330,
				line_id: document.querySelector("aside.popup article > div.popup > ul > li:last-child > div > div > div > div:nth-child(2) > ul").getAttribute("id")
			};

			if (window.innerWidth > 400)  options.width = 360;
			else                          options.widthP = 100;

			$jnode$.requireContent("popup#sign", "/work/maintenance/line", options);
		}, false);

		$jnode$.requireController("popup#sign", {caller:that.conf}).on(function() {
			okButton.addEventListener("click", function(event) {
				// 결재자 수 체크
				var approverLis = document.querySelectorAll("aside.popup article > div.popup > ul > li:last-child > div > div > div > div:nth-child(2) > ul > li:not(.disabled)");
				var approverIds = [];

				for (var i = 0; i < approverLis.length; i++) {
					approverIds.push(approverLis[i].getAttribute("id"));
				}

				var alertMessage = null;

				if (approverIds[0] != worker) {
					alertMessage = "결재라인 구성은 본인부터 시작해야 합니다.";
				} else if (approverIds.length < approverCount) {
					alertMessage = "결재라인 구성은 " + approverCount + " 이상이어야 합니다.";
				}

				if (alertMessage) {
					$controller$.prompt.alert(alertMessage, function(close) {
						lineSelectButton.focus();
						close();
					}, true);
				} else {
					$jnode$.requireContent("popup#sign", "/work/maintenance/sign", {
						width:          276,
						height:         330,
						maintenance_id: document.pdfForm.maintenance_id.value,
						sign_step:      1,
						approver_ids:   JSON.stringify(approverIds),
						approval_step:  approverCount
					});
				}
			}, false);
		});

		document.querySelector("aside.popup article > div.popup > ul > li:last-child > div > button").addEventListener("click", function(event) {
			var fieldsetContainer = this.parentNode;
			if (fieldsetContainer.getAttribute("class") == "hide") {
				fieldsetContainer.setAttribute("class", "show");
			} else {
				fieldsetContainer.setAttribute("class", "hide");
			}
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};