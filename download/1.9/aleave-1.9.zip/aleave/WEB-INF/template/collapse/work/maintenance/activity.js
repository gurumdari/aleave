$content$.work.maintenance.activity = {
	service: function() {
		var that = this;
		var maintenanceId = this.dataset.maintenance_id;
		var activityList  = this.dataset.activityList;

		document.activityForm.querySelector("td.customer_company"  ).appendChild(document.createTextNode(this.dataset.customer_company));
		document.activityForm.querySelector("span.customer_name"   ).appendChild(document.createTextNode(this.dataset.customer_name   ));
		document.activityForm.querySelector("span.customer_org"    ).appendChild(document.createTextNode(this.dataset.customer_org    ));
		document.activityForm.querySelector("span.customer_contact").appendChild(document.createTextNode(this.dataset.customer_contact));
		document.activityForm.querySelector("span.customer_email"  ).appendChild(document.createTextNode(this.dataset.customer_email  ));

		if (this.dataset.customer_id)  document.activityForm.querySelector("td.customer_company").setAttribute("id", this.dataset.customer_id);

		$jnode$.requireControllers(["contentframe", "winup#contentframe"], {caller:that.conf}, function() {
			$controller$.contentframe.service({
				block: true,
				linemode: "single",
				height: 200,
				cells: [
					{ id: "activity_date", name: "일자", width: 85, type: "date" },
					{ id: "activity_content", name: "내용", width: 240 },
					{ id: "activity_remark", name: "비고", width: 100 },
				],
				datas: activityList
			});

			var selectButton = document.activityForm.querySelector("form > table.form > tbody > tr > th > button");
			selectButton.addEventListener("click", function(event) {
				$jnode$.requireContent("popup", "/work/maintenance/customer", {
					widthP:  100,
					heightP: 100
				});
			}, false);

			document.activityForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
				var alertMessage     = "";
				var customerId       = document.activityForm.querySelector("td.customer_company").getAttribute("id");
				var activityListTemp = $controller$.contentframe.getDatas();
				var activityList     = activityListTemp.filter(function(entry) { return !(entry.activity_date == "" || entry.activity_content == ""); });

				if (customerId == null) {
					alertMessage = "고객사를 선택해주세요.";
					selectButton.focus();
				} else if (activityList.length == 0) {
					alertMessage = "활동 내용을 작성해주세요. 일자와 내용이 모두 작성된 항목만 등록됩니다.";
				}

				if (alertMessage) {
					this.parentNode.previousElementSibling.innerHTML = alertMessage;
				} else {
					var yearSelect  = document.querySelector("body > section > div.section > article > div.article > ul > li:first-child > select");
					var workingYear = yearSelect.value;
					var createYear  = workingYear;

					var params = {
						command:          "setActivity",
						maintenance_id:   maintenanceId,
						customer_id:      customerId,
						customer_company: document.activityForm.querySelector("td.customer_company"  ).firstChild.nodeValue,
						customer_name:    document.activityForm.querySelector("span.customer_name"   ).firstChild.nodeValue,
						customer_org:     document.activityForm.querySelector("span.customer_org"    ).firstChild.nodeValue,
						customer_contact: document.activityForm.querySelector("span.customer_contact").firstChild.nodeValue,
						customer_email:   document.activityForm.querySelector("span.customer_email"  ).firstChild.nodeValue,
						activityList:     JSON.stringify(activityList)
					};

					function openMail(id) {
						$jnode$.requireContent("popup", "/work/maintenance/mail", {
							widthP:         100,
							heightP:        100,
							maintenance_id: id
						});
					}

					function setActivity(parameters) {
						$controller$.loading.show();

						$jnode$.ajax.service({
							"url":      "/ajax/work.json",
							"method":   "POST",
							"datatype": "json",
							"headers": {
								"Content-Type": "application/json",
								"Accept":       "application/json"
							},
							"params":  parameters,
							"success": function(response) {
								var maintenanceTbody = document.querySelector("aside.grid > div > table > tbody");

								if (maintenanceId == null) {
									maintenanceId = response.maintenance_id;
									createYear    = response.create_year;

									var yearList = Array.apply(null, yearSelect.options).map(function(el) { return el.value; });

									// 연도별 발급요청 목록 연도에 해당 연도가 없으면 연도를 새로 만들어준다.
									if (yearList.indexOf(createYear) < 0) {
										yearList.push(createYear);
										yearList = yearList.sort().reverse();

										yearSelect.innerHTML = "";

										for (var i = 0; i < yearList.length; i++) {
											yearSelect.add(new Option(yearList[i] + "년", yearList[i]));
										}
									}

									// 작업중인 연도랑 같으면 생성된 요청만 리스트에 추가하고, 그렇지 않으면 생성한 연도의 리스트로 이동한다.
									if (workingYear == createYear) {
										params.maintenance_id = maintenanceId;
										params.create_date    = response.create_date;
										params.user_name      = response.user_name;
										params.approval_step  = -1;

										$content$.work.maintenance.appendMaintenanceRow(maintenanceTbody, params, true).click();
									} else {
										yearSelect.value = createYear;
										$content$.work.maintenance.getMaintenanceList(createYear, maintenanceId);
									}
								} else {
									maintenanceTbody.querySelector("tbody > tr.selected > td:first-child").firstChild.nodeValue = params.customer_company;
								}

								$controller$.winup.close();
								openMail(maintenanceId);
							},
							"error": function(error) {
								$jnode$.ajax.alertError(error);
								$controller$.loading.hide();
							}
						});
					}

					if (activityList.length == activityListTemp.length) {
						setActivity(params);
					} else {
						$controller$.prompt.confirm("활동 내용은 일자와 내용이 모두 작성된 항목만 등록됩니다. 등록하시겠습니까?", function(close) {
							setActivity(params);
							close();
						}, null, 1);
					}
				}
			}, false);
		});

		document.querySelector("aside.winup article > div.winup > ul > li:nth-child(2)").addEventListener("click", function(event) {
			if (this.getAttribute("class") == "expand") {
				$controller$.winup.resize(522);
				this.removeAttribute("class");
			} else {
				$controller$.winup.resize(822);
				this.setAttribute("class", "expand");

				var winupNode = document.querySelector("aside.winup > div:last-child");
				var x = parseInt(winupNode.style.left, 10);
				var y = parseInt(winupNode.style.top, 10);

				var screenWidth = document.documentElement.clientWidth;

				if (x + 822 > screenWidth) {
					if (screenWidth > 842) {
						x = screenWidth - 832;
					} else if (screenWidth > 822) {
						x = parseInt((screenWidth - 822) / 2, 10);
					} else {
						x = 0;
					}

					$controller$.winup.moveTo(x, y);
				}
			}
		}, false);
	}
};