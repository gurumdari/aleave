$content$.work.month = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if (windowWidth > 736) {
			$controller$.grid.resize(null, windowHeight - 416);
		} else {
			$controller$.grid.removeHeight();
		}

		$controller$.grid.resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();
		$jnode$.pushHistory(this.conf);

		var that = this;
		var date = new Date();
		var dateCalendar = document.querySelector("div.section > article > div.article > div.calendar > div");
		var dateDiv      = dateCalendar.parentNode.nextElementSibling;

		$jnode$.requireController("grid", {caller:that.conf}).on(function() {
			$controller$.grid.service({
				sortable: true
			});

			window.addEventListener("resize", that.resize, false);
			that.resize();

			var workTbody = document.querySelector("div.section > article > div.article > aside.grid > div > table > tbody");

			function pad(val, len) {
				val = String(val);
				len = len || 2;
				while (val.length < len) {
					val = "0" + val;
				}
				return val;
			}

			function appendWorkRow(workData, workType) {
				var row = document.createElement("tr");
				row.setAttribute("id", (workType == "timeoff" ? workData.timeoff_id : workData.outside_id));
				workTbody.appendChild(row);

				var userId      = workData.user_id;
				var isRetiree   = (userId.indexOf("${") == 0);
				var retireeInfo = {};

				if (isRetiree)  retireeInfo = JSON.parse(workData.user_note);

				var nameCell = row.insertCell(0);
				nameCell.appendChild(document.createTextNode(workData.user_name));
				nameCell.setAttribute("class", (workData.level_name ? workData.level_name : "member") + (isRetiree ? " retiree" : ""));

				var positionCell = row.insertCell(1);
				positionCell.appendChild(document.createTextNode(isRetiree ? retireeInfo.position_name : workData.position_name));
				positionCell.setAttribute("sid", pad(workData.type_sort) + pad(workData.position_sort));

				var orgCell = row.insertCell(2);
				orgCell.appendChild(document.createTextNode(isRetiree ? retireeInfo.org_name : workData.org_name));

				if (workType == "timeoff") {
					var typeCell = row.insertCell(3);
					typeCell.appendChild(document.createTextNode(workData.type_name));

					if (workData.timeoff_end == null)  workData.timeoff_end = "";

					var periodValue   = "";
					var timeoffStarts = workData.timeoff_start.split(" ");
					var timeoffEnds   = workData.timeoff_end.split(" ");

					if (timeoffEnds.length == 1) {
						// 결근은 workData.timeoff_end가 빈 문자로 넘어옴
						periodValue = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM) + " " + timeoffStarts[1];
					} else if (timeoffStarts[0] == timeoffEnds[0]) {
						periodValue = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM);
						if (timeoffStarts[1] == timeoffEnds[1])  periodValue += " " + (timeoffStarts[1] == "AM" ? "오전" : "오후");
					} else {
						var periodValue1 = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM);
						var periodValue2 = dateFormatter.format($module$.date.Utils.parse(timeoffEnds[0]), dateFormatter.DateStyle.MEDIUM);
						
						if (timeoffStarts[1] == "PM")  periodValue1 += " 오후";
						if (timeoffEnds[1]   == "AM")  periodValue2 += " 오전";

						periodValue = periodValue1 + " ~ " + periodValue2;
					}

					var periodCell = row.insertCell(4);
					periodCell.appendChild(document.createTextNode(periodValue));
				} else {
					var outsideType = null;

					if (workData.outside_starttime == "S") {
						if (workData.outside_endtime == "E") {
							outsideType = "외근 (종일)";
						} else {
							outsideType = "직출 (~ " + workData.outside_endtime + "시)";
						}
					} else if (workData.outside_endtime == "E") {
						outsideType = "직퇴 (" + workData.outside_starttime + "시 ~)";
					} else {
						outsideType = "외근 (" + workData.outside_starttime + "시 ~ " + workData.outside_endtime + "시)";
					}

					outsideType += " - " + workData.destination;

					var typeCell = row.insertCell(3);
					typeCell.appendChild(document.createTextNode(outsideType));

					var periodValue = dateFormatter.format($module$.date.Utils.parse(workData.outside_startdate), dateFormatter.DateStyle.MEDIUM);
					var periodId    = workData.outside_startdate;

					if (workData.outside_startdate != workData.outside_enddate) {
						periodValue += " ~ " + dateFormatter.format($module$.date.Utils.parse(workData.outside_enddate), dateFormatter.DateStyle.MEDIUM);
						periodId    += " ~ " + workData.outside_enddate;
					}

					var periodCell = row.insertCell(4);
					periodCell.setAttribute("id", periodId);
					periodCell.appendChild(document.createTextNode(periodValue));
				}

				row.addEventListener("click", function(event) {
					var selectedRow = workTbody.querySelector("tbody > tr.selected");
					if (selectedRow)  selectedRow.removeAttribute("class");

					this.setAttribute("class", "selected");
				}, false);
			}

			function displayWorkCalendar(date, dateNode, container) {
				$controller$.loading.show();

				function setDate(node, date, dateNode, monthIndex) {
					node.addEventListener("click", function(event) {
						$controller$.loading.show();

						var selectedCell = document.querySelector("div.calendar.schedule > div > table > tbody > tr > td.selected");
						if (selectedCell)  $jnode$.node.removeClass(selectedCell, "selected");

						$jnode$.node.addClass(this, "selected");

						$jnode$.ajax.service({
							"url":      "/ajax/work.json",
							"method":   "POST",
							"datatype": "json",
							"headers": {
								"Content-Type": "application/json",
								"Accept":       "application/json"
							},
							"params":  {
								command: "getDayOutsideList",
								day:     date
							},
							"success": function(response) {
								dateNode.innerHTML = $jnode$.escapeXML(dateFormatter.format($module$.date.Utils.parse(date), dateFormatter.DateStyle.LONG));
								$controller$.grid.clear();

								var timeoffList = response.timeoff;
								var outsideList = response.outside;

								for (var i = 0; i < timeoffList.length; i++) {
									appendWorkRow(timeoffList[i], "timeoff");
								}

								for (var i = 0; i < outsideList.length; i++) {
									appendWorkRow(outsideList[i], "outside");
								}

								$controller$.loading.hide();
							},
							"error": function(error) {
								$jnode$.ajax.alertError(error);
								$controller$.loading.hide();
							}
						});
					}, false);
				}

				var calendarDate = null;
				var isoDate      = null;

				if (Object.prototype.toString.call(date) == "[object Date]") {
					isoDate      = $module$.date.Utils.format(date);
					calendarDate = date;
				} else {
					isoDate      = date;
					calendarDate = $module$.date.Utils.parse(date);
				}

				var yearMonthText = isoDate.substring(0, isoDate.lastIndexOf("-") + 1);
				var year          = calendarDate.getFullYear();
				var monthIndex    = calendarDate.getMonth();
				var arr2Day       = $module$.date.Utils.getCalendarMatrix(year, monthIndex);

				dateNode.innerHTML = dateFormatter.format(date, "yyyy년 MMM");
				$controller$.grid.clear();

				var params = {
					command:     "getMonthOutsideMap",
					month_first: yearMonthText + "01",
					month_last:  yearMonthText + $module$.date.Utils.getLastMonthDate(year, monthIndex)
				};

				$jnode$.ajax.service({
					"url":      "/ajax/work.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						container.innerHTML = "";

						var monthTimeoffMap = response.timeoff;
						var monthOutsideMap = response.outside;

						var yearUl = document.createElement("ul");
						container.appendChild(yearUl);

						var prevYearLink = document.createElement("span");
						prevYearLink.innerHTML = year - 1;

						var prevYearLi = document.createElement("li");
						prevYearLi.setAttribute("class", "prev");
						prevYearLi.appendChild(prevYearLink);
						yearUl.appendChild(prevYearLi);

						var currYearLi = document.createElement("li");
						currYearLi.setAttribute("class", "current");
						currYearLi.innerHTML = year;
						yearUl.appendChild(currYearLi);

						var nextYearLink = document.createElement("span");
						nextYearLink.innerHTML = year + 1;

						var nextYearLi = document.createElement("li");
						nextYearLi.setAttribute("class", "next");
						nextYearLi.appendChild(nextYearLink);
						yearUl.appendChild(nextYearLi);

						var monthUl = document.createElement("ul");
						container.appendChild(monthUl);

						var monthNames = dateFormatter.Symbols.MonthNames;

						var prevMonthLink = document.createElement("span");
						prevMonthLink.innerHTML = (monthIndex == 0 ? monthNames[11] : monthNames[monthIndex - 1]);

						var prevMonthLi = document.createElement("li");
						prevMonthLi.setAttribute("class", "prev");
						prevMonthLi.appendChild(prevMonthLink);
						monthUl.appendChild(prevMonthLi);

						var currMonthLi = document.createElement("li");
						currMonthLi.setAttribute("class", "current");
						currMonthLi.innerHTML = monthNames[monthIndex];
						monthUl.appendChild(currMonthLi);

						var nextMonthLink = document.createElement("span");
						nextMonthLink.innerHTML = (monthIndex == 11 ? monthNames[0] : monthNames[monthIndex + 1]);

						var nextMonthLi = document.createElement("li");
						nextMonthLi.setAttribute("class", "next");
						nextMonthLi.appendChild(nextMonthLink);
						monthUl.appendChild(nextMonthLi);

						prevYearLink.addEventListener("click", function() {
							displayWorkCalendar(new Date(year - 1, monthIndex, 1), dateNode, container);  // .format("yyyy-MM-dd")
						}, false);

						nextYearLink.addEventListener("click", function() {
							displayWorkCalendar(new Date(year + 1, monthIndex, 1), dateNode, container);  // .format("yyyy-MM-dd")
						}, false);

						prevMonthLink.addEventListener("click", function() {
							displayWorkCalendar(new Date(year, monthIndex - 1, 1), dateNode, container);  // .format("yyyy-MM-dd")
						}, false);

						nextMonthLink.addEventListener("click", function() {
							displayWorkCalendar(new Date(year, monthIndex + 1, 1), dateNode, container);  // .format("yyyy-MM-dd")
						}, false);

						var table = document.createElement("table");
						table.setAttribute("class", "date");
						container.appendChild(table);

						var weekIndex    = 0;
						var cellRevision = 0;
						var row = table.insertRow(0);

						for (var i = 0; i < 7; i++) {
							var cell = row.insertCell(i + cellRevision);
							cell.setAttribute("class", "w" + i);
							cell.innerHTML = dateFormatter.Symbols.WeekdayNames[i];
						}

						for (var i = 0; i < arr2Day.length; i++) {
							var row = table.insertRow(i + 1);

							for (var j = 0; j < 7; j++) {
								var cell          = row.insertCell(j + cellRevision);
								var monthDay      = arr2Day[i][j];
								var monthDayValue = monthDay;
								var className     = "w" + j;

								if (monthDay < 0) {
									monthDayValue = (monthDay * -1);
									className     = "w9";
								} else {
									className += " date";

									setDate(cell, year + "-" + pad(monthIndex + 1) + "-" + pad(monthDay), dateNode);
								}

								cell.setAttribute("class", className);

								var dayDiv = document.createElement("div");
								dayDiv.appendChild(document.createTextNode(monthDayValue));
								cell.appendChild(dayDiv);

								var outsideDiv = document.createElement("div");
								cell.appendChild(outsideDiv);

								var workCount = "";
								var timeoffCount = monthTimeoffMap[monthDay.toString()];
								if (timeoffCount) {
									workCount = "<SPAN class=\"timeoff\" title=\"휴가\">" + timeoffCount + "</SPAN>";
								}

								var outsideCount = monthOutsideMap[monthDay.toString()];
								if (outsideCount) {
									if (workCount)  workCount += "+";
									workCount += "<SPAN class=\"outside\" title=\"외근\">" + outsideCount + "</SPAN>";
								}

								if (workCount) {
									outsideDiv.innerHTML = workCount;
								}
							}
						}

						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}

			displayWorkCalendar(date, dateDiv, dateCalendar);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};