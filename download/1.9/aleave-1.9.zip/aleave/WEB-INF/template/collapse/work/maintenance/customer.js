$content$.work.maintenance.customer = {
	appendCustomerRow: function(customerTbody, customerData) {
		var row = document.createElement("tr");
		row.setAttribute("id", customerData.customer_id);
		customerTbody.appendChild(row);

		var companyCell = row.insertCell(0);
		companyCell.appendChild(document.createTextNode(customerData.customer_company));
		companyCell.setAttribute("class", (customerData.user_id ? "personal" : "shared"));

		var nameSpan = document.createElement("span");
		nameSpan.appendChild(document.createTextNode(customerData.customer_name));

		var orgSpan = document.createElement("span");
		orgSpan.appendChild(document.createTextNode(customerData.customer_org));

		var userCell = row.insertCell(1);
		userCell.appendChild(nameSpan);
		userCell.appendChild(document.createTextNode(" @ "));
		userCell.appendChild(orgSpan);

		var contactCell = row.insertCell(2);
		contactCell.appendChild(document.createTextNode(customerData.customer_contact));

		var emailCell = row.insertCell(3);
		emailCell.appendChild(document.createTextNode(customerData.customer_email));

		row.addEventListener("click", function(event) {
			var selectedRow = customerTbody.querySelector("tbody > tr.selected");
			if (selectedRow)  selectedRow.removeAttribute("class");

			this.setAttribute("class", "selected");

			var editButton = document.querySelector("aside.popup article > div.popup > ul.submit > li:first-child > button:last-child");
			var okButton   = editButton.parentNode.nextElementSibling.firstElementChild;

			editButton.disabled = false;
			okButton  .disabled = false;
		}, false);

		return row;
	},

	resize: function() {
		$controller$["grid#customer"].resize(null, window.innerHeight - 82);
		$controller$["grid#customer"].resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();
		var that = this;
		var customerList = this.dataset.customerList;

		$jnode$.requireControllers(["grid#customer", "winup#customer"], {caller:that.conf}, function() {
			$controller$["grid#customer"].service({
				sortable: true
			});

			window.addEventListener("resize", that.resize, false);
			that.resize();

			var customerTbody = document.querySelector("aside.grid#customer > div > table > tbody");

			for (var i = 0; i < customerList.length; i++) {
				$content$.work.maintenance.customer.appendCustomerRow(customerTbody, customerList[i]);
			}

			$controller$.loading.hide();


			var addButton  = document.querySelector("aside.popup article > div.popup > ul.submit > li:first-child > button:first-child");
			var editButton = addButton.nextElementSibling;
			var okButton   = editButton.parentNode.nextElementSibling.firstElementChild;

			addButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup#customer", "/work/maintenance/customer/add", {
					icon:     true,
					title:    "고객사 정보 추가",
					width:    350,
					height:   273,
					renderer: "-j"
				});
			}, false);

			editButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup#customer", "/work/maintenance/customer/edit", {
					icon:     true,
					title:    "고객사 정보 수정",
					width:    350,
					height:   273,
					renderer: "-j"
				});
			}, false);

			okButton.addEventListener("click", function(event) {
				var selectedRow   = customerTbody.querySelector("tbody > tr.selected");
				var companyCell   = selectedRow.firstElementChild;
				var userCell      = companyCell.nextElementSibling;
				var contactCell   = userCell.nextElementSibling;
				var emailCell     = contactCell.nextElementSibling;
				var nameSpan      = userCell.firstElementChild;
				var orgSpan       = userCell.lastElementChild;

				document.activityForm.querySelector("td.customer_company"  ).firstChild.nodeValue = companyCell.firstChild.nodeValue;
				document.activityForm.querySelector("span.customer_name"   ).firstChild.nodeValue = nameSpan.firstChild.nodeValue;
				document.activityForm.querySelector("span.customer_org"    ).firstChild.nodeValue = orgSpan.firstChild.nodeValue;
				document.activityForm.querySelector("span.customer_contact").firstChild.nodeValue = contactCell.firstChild.nodeValue;
				document.activityForm.querySelector("span.customer_email"  ).firstChild.nodeValue = emailCell.firstChild.nodeValue;

				document.activityForm.querySelector("td.customer_company").setAttribute("id", selectedRow.getAttribute("id"));

				$controller$.popup.close();
			}, false);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};