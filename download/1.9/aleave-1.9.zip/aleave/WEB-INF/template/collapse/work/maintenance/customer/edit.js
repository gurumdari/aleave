$content$.work.maintenance.customer.edit = {
	service: function() {
		var customerTbody = document.querySelector("aside.grid#customer > div > table > tbody");
		var selectedRow   = customerTbody.querySelector("tbody > tr.selected");
		var customerId    = selectedRow.getAttribute("id");
		var companyCell   = selectedRow.firstElementChild;
		var userCell      = companyCell.nextElementSibling;
		var contactCell   = userCell.nextElementSibling;
		var emailCell     = contactCell.nextElementSibling;
		var nameSpan      = userCell.firstElementChild;
		var orgSpan       = userCell.lastElementChild;

		document.customerForm.customer_company.value = companyCell.firstChild.nodeValue;
		document.customerForm.customer_name.value    = nameSpan.firstChild.nodeValue;
		document.customerForm.customer_org.value     = orgSpan.firstChild.nodeValue;
		document.customerForm.customer_contact.value = contactCell.firstChild.nodeValue;
		document.customerForm.customer_email.value   = emailCell.firstChild.nodeValue;
		document.customerForm.share.value            = companyCell.getAttribute("class") == "shared" ? "Y" : "N";

		var updateButton = document.customerForm.querySelector("form > ul.submit > li > button:first-child");
		var deleteButton = updateButton.nextElementSibling;

		updateButton.addEventListener("click", function(event) {
			var alertMessage = null;
			var alertNode    = this.parentNode.previousElementSibling;

			var params = {
				command:          "updateCustomer",
				customer_id:      customerId,
				customer_company: document.customerForm.customer_company.value.trim(),
				customer_name:    document.customerForm.customer_name.value.trim(),
				customer_org:     document.customerForm.customer_org.value.trim(),
				customer_contact: document.customerForm.customer_contact.value.trim(),
				customer_email:   document.customerForm.customer_email.value.trim(),
				share:            document.customerForm.share.value
			};

			if (params.customer_company == "") {
				alertMessage = "고객사명을 입력해주세요.";
				document.customerForm.customer_company.select();
			} else if (params.customer_name == "") {
				alertMessage = "담당자를 입력해 주세요.";
				document.customerForm.customer_name.select();
			} else if (params.customer_org == "") {
				alertMessage = "소속을 입력해 주세요.";
				document.customerForm.customer_org.select();
			} else if (params.customer_contact == "") {
				alertMessage = "연락처를 입력해 주세요.";
				document.customerForm.customer_contact.select();
			} else if (params.customer_email == "") {
				alertMessage = "E-mail을 입력해 주세요.";
				document.customerForm.customer_email.select();
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/work.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						$controller$.grid.clear("thead");

						companyCell.firstChild.nodeValue = params.customer_company;
						nameSpan.firstChild.nodeValue    = params.customer_name;
						orgSpan.firstChild.nodeValue     = params.customer_org;
						contactCell.firstChild.nodeValue = params.customer_contact;
						emailCell.firstChild.nodeValue   = params.customer_email;
						companyCell.setAttribute("class", (params.share == "Y" ? "shared" : "personal"));

						$controller$["winup#customer"].close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		deleteButton.addEventListener("click", function(event) {
			$controller$.prompt.confirm("정말로 선택한 고객사 정보를 삭제하겠습니까?", function(close) {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/work.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  {
						command:     "deleteCustomer",
						customer_id: customerId
					},
					"success": function(response) {
						customerTbody.removeChild(selectedRow);

						var editButton = document.querySelector("aside.popup article > div.popup > ul.submit > li:first-child > button:last-child");
						var okButton   = editButton.parentNode.nextElementSibling.firstElementChild;
			
						editButton.disabled = true;
						okButton  .disabled = true;

						$controller$["winup#customer"].close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});

				close();
			}, null, 2);
		}, false);
	}
};