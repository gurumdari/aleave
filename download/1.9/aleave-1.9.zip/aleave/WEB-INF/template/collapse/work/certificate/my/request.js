$content$.work.certificate.my.request = {
	service: function() {
		var managerId = this.dataset.manager_id;

		document.certificateForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var params = {
				command:         "addCertificate",
				usage_value:     document.certificateForm.usage_value.value.trim(),
				request_comment: document.certificateForm.request_comment.value.trim(),
				manager_id:      managerId
			};

			if (params.usage_value == "") {
				document.certificateForm.usage_value.select();
				this.parentNode.previousElementSibling.innerHTML = "용도를 입력해주세요.";
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/work.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						var certificateYear = response.certificate_year;
						var yearSelect      = document.querySelector("body > section > div.section > article > div.article > ul > li:first-child > select");
						var workingYear     = yearSelect.value;
						var yearList        = Array.apply(null, yearSelect.options).map(function(el) { return el.value; });

						// 연도별 발급요청 목록 연도에 해당 연도가 없으면 연도를 새로 만들어준다.
						if (yearList.indexOf(certificateYear) < 0) {
							yearList.push(certificateYear);
							yearList = yearList.sort().reverse();

							yearSelect.innerHTML = "";

							for (var i = 0; i < yearList.length; i++) {
								yearSelect.add(new Option(yearList[i] + "년", yearList[i]));
							}
						}

						// 작업중인 연도랑 같으면 생성된 요청만 리스트에 추가하고, 그렇지 않으면 생성한 연도의 리스트로 이동한다.
						if (workingYear == certificateYear) {
							params.certificate_id = response.certificate_id;
							params.request_date   = response.request_date;

							var certificateTbody = document.querySelector("aside.grid > div > table > tbody");
							$content$.work.certificate.my.appendCertificateRow(certificateTbody, params, true).click();
						} else {
							yearSelect.value = certificateYear;
							$content$.work.certificate.my.getCertificateList(certificateYear, response.certificate_id);
						}

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.certificateForm.usage_value.focus();
	}
};