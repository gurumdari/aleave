var isMobile = $jnode$.device.type != "desktop";
var isPhone  = $jnode$.device.type == "phone";

document.querySelector("body > header > ul > li:last-child > ul > li > button.account").addEventListener("click", function(event) {
	linkArticle("/setting/account");
}, false);

document.querySelector("body > header > ul > li:last-child > ul > li > form > button.setting").addEventListener("click", function(event) {
	handleHash("#section:/setting");
}, false);

document.querySelector("body > header > ul > li:last-child > ul > li > form > button.logout").addEventListener("click", function(event) {
	$controller$.loading.show();
	document.logoutForm.submit();
}, false);

function linkArticle(articleId) {
	var sectionId = "/" + articleId.split("/")[1];
	var sectionMenu = document.querySelector("body > nav > ul > li > label > input[name='section_menu'][value='" + sectionId + "']");
	if (sectionMenu)  sectionMenu.checked = true;

	var articleMenu = document.querySelector("body > section > div.section > nav > div:last-child > fieldset > div > ul > li > label > input[name='article_menu'][value='" + articleId +"']");
	if (articleMenu == null)  articleMenu = document.querySelector("body > section > div.section > fieldset > div:last-child > ul > li > label > input[name='article_menu'][value='" + articleId +"']");

	if (articleMenu) {
		if (!articleMenu.checked) {
			articleMenu.click();
			window.scrollTo(0, 0);
		}
	} else {
		$jnode$.requireContent("section", sectionId, {useLoading:true, articleId:articleId});
	}
}

function linkStartId() {
	if (startId.split("/").length == 2) {
		document.querySelector("body > nav > ul > li > label > input[name='section_menu'][value='" + startId + "']").click();
	} else {
		$controller$.prompt.alert("등록된 사용자가 없습니다. 사용자를 추가해 주세요.", function(close) {
			linkArticle(startId);
			close();
		});
	}
}

function setSectionMenus(hash) {
	var sectionMenus = document.querySelectorAll("body > nav > ul > li > label > input[name='section_menu']");

	for (var i = 0; i < sectionMenus.length; i++) {
		sectionMenus[i].addEventListener("click", function(event) {
			if ((startId.split("/").length > 2) && !(this.value == "/setting" || startId.indexOf(this.value) == 0)) {
				linkStartId();
			} else {
				$jnode$.requireContent("section", this.value, {useLoading:true});
				window.scrollTo(0, 0);
			}
		}, false);
	}

	if (startId.split("/").length == 2) {
		if (hash)  handleHash(hash);
		else       document.querySelector("body > nav > ul > li > label > input[name='section_menu'][value='" + startId + "']").click();
	} else {
		linkArticle(startId);
	}
}

function setWaitingCount(waitingCount) {
	if (waitingCount) {
		var timeoffMenu  = document.querySelector("body > nav > ul > li > label > input[value='/timeoff'] + span");
		var outsideMenu  = document.querySelector("body > nav > ul > li > label > input[value='/outside'] + span");
		var workMenu     = document.querySelector("body > nav > ul > li > label > input[value='/work'] + span");

		if (waitingCount.timeoff)  timeoffMenu.setAttribute("class", waitingCount.timeoff);
		else                       timeoffMenu.removeAttribute("class");

		if (waitingCount.outside)  outsideMenu.setAttribute("class", waitingCount.outside);
		else                       outsideMenu.removeAttribute("class");

		if (waitingCount.certificate)  workMenu.setAttribute("class", waitingCount.certificate);
		else                           workMenu.removeAttribute("class");
	}
}

function setArticleMenus(articleId) {
	var articleTitle = document.querySelector("body > section > div.section > fieldset > div:first-child");
	var articleMenus = document.querySelectorAll("body > section > div.section > fieldset > div:last-child > ul > li > label > input[name='article_menu']");
	var menuCount    = articleMenus.length;

	if (articleTitle) {
		articleTitle.addEventListener("click", function(event) {
			var fieldset = this.parentNode;
			var fieldsetClass = fieldset.getAttribute("class");

			if (fieldsetClass == null)  fieldsetClass = "shrink_" + menuCount;

			if (fieldsetClass.indexOf("expand_") == 0) {
				fieldset.setAttribute("class", "shrink_" + menuCount);
			} else {
				fieldset.setAttribute("class", "expand_" + menuCount);
			}
		}, false);
	}

	var articleMenu  = null;

	if (menuCount > 0) {
		var titlePrefix = "";
		if (articleId.indexOf("/setting/") == 0)  titlePrefix = "환경 설정 &gt; ";

		for (var i = 0; i < articleMenus.length; i++) {
			articleMenus[i].addEventListener("click", function(event) {
				$jnode$.requireContent("article", this.value, {useLoading:true});

				articleTitle.innerHTML = titlePrefix + this.nextElementSibling.innerHTML;

				var fieldsetClass = articleTitle.parentNode.getAttribute("class");

				if (fieldsetClass && fieldsetClass.indexOf("expand_") == 0) {
					articleTitle.parentNode.setAttribute("class", "shrink_" + menuCount);
				}
			}, false);

			if (articleId == articleMenus[i].value)  articleMenu = articleMenus[i];
		}

		if (articleMenu == null)  articleMenu = articleMenus[0];

		var sectionId = "/" + articleMenu.value.split("/")[1];
		document.querySelector("body > nav > ul > li > label > input[name='section_menu'][value='" + sectionId + "']").checked = true;

		articleMenu.click();
	}

	window.scrollTo(0, 0);
}

setSectionMenus(document.location.hash);

function displayCalendar(date, dateLi, container, currDateTextValue) {
	function pad(val, len) {
		val = String(val);
		len = len || 2;
		while (val.length < len) {
			val = "0" + val;
		}
		return val;
	}

	function setDate(node, date, dateLi, monthIndex) {
		node.addEventListener("click", function(event) {
			dateLi.innerHTML = $jnode$.escapeXML(dateFormatter.format($module$.date.Utils.parse(date), dateFormatter.DateStyle.LONG));
			dateLi.setAttribute("value", "iso:" + date);

			displayCalendar(date, dateLi, container, date);
		}, false);
	}

	var calendarDate = null;

	if (Object.prototype.toString.call(date) == "[object Date]") {
		calendarDate = date;
	} else {
		calendarDate = $module$.date.Utils.parse(date);
	}

	var year       = calendarDate.getFullYear();
	var monthIndex = calendarDate.getMonth();
	var arr2Day    = $module$.date.Utils.getCalendarMatrix(year, monthIndex);

	container.innerHTML = "";

	var yearUl = document.createElement("ul");
	container.appendChild(yearUl);

	var prevYearLink = document.createElement("span");
	prevYearLink.innerHTML = year - 1;

	var prevYearLi = document.createElement("li");
	prevYearLi.setAttribute("class", "prev");
	prevYearLi.appendChild(prevYearLink);
	yearUl.appendChild(prevYearLi);

	var currYearLi = document.createElement("li");
	currYearLi.setAttribute("class", "current");
	currYearLi.innerHTML = year;
	yearUl.appendChild(currYearLi);

	var nextYearLink = document.createElement("span");
	nextYearLink.innerHTML = year + 1;

	var nextYearLi = document.createElement("li");
	nextYearLi.setAttribute("class", "next");
	nextYearLi.appendChild(nextYearLink);
	yearUl.appendChild(nextYearLi);

	var monthUl = document.createElement("ul");
	container.appendChild(monthUl);

	var monthNames = dateFormatter.Symbols.MonthNames;

	var prevMonthLink = document.createElement("span");
	prevMonthLink.innerHTML = (monthIndex == 0 ? monthNames[11] : monthNames[monthIndex - 1]);

	var prevMonthLi = document.createElement("li");
	prevMonthLi.setAttribute("class", "prev");
	prevMonthLi.appendChild(prevMonthLink);
	monthUl.appendChild(prevMonthLi);

	var currMonthLi = document.createElement("li");
	currMonthLi.setAttribute("class", "current");
	currMonthLi.innerHTML = monthNames[monthIndex];
	monthUl.appendChild(currMonthLi);

	var nextMonthLink = document.createElement("span");
	nextMonthLink.innerHTML = (monthIndex == 11 ? monthNames[0] : monthNames[monthIndex + 1]);

	var nextMonthLi = document.createElement("li");
	nextMonthLi.setAttribute("class", "next");
	nextMonthLi.appendChild(nextMonthLink);
	monthUl.appendChild(nextMonthLi);

	prevYearLink.addEventListener("click", function() {
		displayCalendar(new Date(year - 1, monthIndex, 1), dateLi, container, currDateTextValue);  // .format("yyyy-MM-dd")
	}, false);

	nextYearLink.addEventListener("click", function() {
		displayCalendar(new Date(year + 1, monthIndex, 1), dateLi, container, currDateTextValue);  // .format("yyyy-MM-dd")
	}, false);

	prevMonthLink.addEventListener("click", function() {
		displayCalendar(new Date(year, monthIndex - 1, 1), dateLi, container, currDateTextValue);  // .format("yyyy-MM-dd")
	}, false);

	nextMonthLink.addEventListener("click", function() {
		displayCalendar(new Date(year, monthIndex + 1, 1), dateLi, container, currDateTextValue);  // .format("yyyy-MM-dd")
	}, false);

	var table = document.createElement("table");
	table.setAttribute("class", "date");
	container.appendChild(table);

	var weekIndex    = 0;
	var cellRevision = 0;
	var row = table.insertRow(0);

	var separatedCurrDates = currDateTextValue.split("-");
	var currYear           = parseInt(separatedCurrDates[0], 10);
	var currMonth          = parseInt(separatedCurrDates[1], 10);
	var currDay            = parseInt(separatedCurrDates[2], 10);
	var currWeek           = 0;

	for (var i = 0; i < 7; i++) {
		var cell = row.insertCell(i + cellRevision);
		cell.setAttribute("class", "w" + i);
		cell.innerHTML = dateFormatter.Symbols.WeekdayNames[i];
	}

	for (var i = 0; i < arr2Day.length; i++) {
		var row = table.insertRow(i + 1);

		for (var j = 0; j < 7; j++) {
			var cell         = row.insertCell(j + cellRevision);
			var monthDay     = arr2Day[i][j];
			var monthDayHtml = monthDay;
			var className    = "w" + j;

			if (monthDay < 0) {
				monthDayHtml = (monthDay * -1);
				className    = "w9";
			} else {
				className += " date";

				setDate(cell, year + "-" + pad(monthIndex + 1) + "-" + pad(monthDay), dateLi);

				if (currDay == monthDay) {
					className += " current";

					if (currYear == year && currMonth == monthIndex + 1) {
						className += " selected";
					}
				}
			}

			cell.setAttribute("class", className);
			cell.innerHTML = monthDayHtml;
		}
	}
}