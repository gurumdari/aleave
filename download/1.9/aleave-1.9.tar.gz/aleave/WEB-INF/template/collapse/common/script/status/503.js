var refreshButton = document.querySelector("body > section > ul.error_container > li > ul.error > li:last-child > div.button > button");
if (refreshButton) {
	refreshButton.addEventListener("click", function(event) {
		$controller$.loading.show();
		document.location.reload();
	}, false);

	window.setTimeout(function() {
		refreshButton.click();
	}, 12000);  // 12초 후에 재로딩
}