$content$.work.maintenance.line = {
	resize: function() {
		var windowWidth = window.innerWidth;

		if (windowWidth > 400) {
			$controller$["popup#sign"].resize(360, 330);
		} else {
			$controller$["popup#sign"].widthP(100);
		}
	},

	service: function() {
		var approverCount = this.dataset.approverCount;
		var worker        = this.dataset.worker;

		window.addEventListener("resize", this.resize, false);
		this.resize();

		document.querySelector("aside.popup#sign article > div.popup > ul.submit > li > button").addEventListener("click", function(event) {
			var selectedLine = document.querySelector("aside.popup#sign article > div.popup > form > fieldset > legend > label > input:checked");
			var selectedLineContainer = selectedLine.parentNode.parentNode.nextElementSibling;

			$content$.work.maintenance.approval_line.setApprovalLine(selectedLineContainer.innerHTML, selectedLine.value);
			$controller$["popup#sign"].close();
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
}