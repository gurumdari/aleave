$content$.work.pdf.certificate = {
	resize: function() {
		var windowWidth    = window.innerWidth;
		var popupContainer = document.querySelector("aside.popup > ul > li > div");

		popupContainer.style.maxWidth = "640px";
		popupContainer.style.removeProperty("max-height");

		if (windowWidth > 736) {
			// 297 /  210 = 1.414285714
			var popupWidth  = popupContainer.clientWidth;
			var popupHeight = popupContainer.clientHeight;

			if ((popupHeight - 116) / (popupWidth - 40) >= 1.4) {
				popupContainer.style.maxHeight = ((popupWidth - 40) * 1.4 + 116) + "px";
			} else {
				var newWidth = (popupHeight - 116) / 1.4 + 40;
				if (newWidth < 300)  newWidth = 300;
				popupContainer.style.maxWidth = newWidth + "px";
			}
		}

		popupContainer.querySelector("div > article > div.popup > iframe").style.height = (popupContainer.clientHeight - 82) + "px";
	},

	service: function() {
		var certificateId   = this.dataset.certificate_id;
		var certificateType = this.dataset.certificate_type;

		this.resize();
		window.addEventListener("resize", this.resize, false);

		document.pdfForm.action = $jnode$.contextPath + "/work/pdf/certificate/" + this.conf.title + ".pdf";  // #toolbar=0
		var editButton = document.pdfForm.querySelector("form > ul.submit > li > button.popup");

		if (this.conf.allow_embedded == 1) {
			document.pdfForm.target = "pdfFrame";
			document.pdfForm.submit();

			document.pdfForm.use_stamp.addEventListener("change", function() {
				document.pdfForm.submit();
			}, false);
		} else {
			editButton.nextElementSibling.addEventListener("click", function() {
				document.pdfForm.submit();
			}, false);
		}

		editButton.addEventListener("click", function(event) {
			$controller$.popup.close();

			$jnode$.requireContent("winup", "/work/certificate/manage/edit", {
				useLoading:     true,
				icon:           true,
				title:          certificateType == "career" ? "경력증명서 발급" : "재직증명서 발급",
				width:          480,
				height:         250,
				certificate_id: certificateId
			});
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};