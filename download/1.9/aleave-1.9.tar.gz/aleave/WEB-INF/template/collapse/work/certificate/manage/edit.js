$content$.work.certificate.manage.edit = {
	service: function() {
		var dataset         = this.dataset;
		var certificateId   = dataset.certificate_id;
		var certificateType = dataset.certificate_type;
		var issued          = dataset.issued;

		// issued를 통해 발행된 적이 있으면, 용도와 발행일 등의 정보가 기존 정보와 같은지 확인후 "확인" 버튼 클릭시 DB 수정없이 바로 pdf 파일 보여줄지 여부를 결정한다.
		// 발행일은 발행된 적이 없을 때 오늘 날짜로 넘어 오므로, issued를 통하지 않으면 발행이 안 될 수 있다.

		function drawCalendar(buttonTitle, isoValue) {
			var date         = null;
			var windowWidth  = window.innerWidth;
			var popupDomain  = $jnode$.controller.getDomain("popup");
			var popupContent = popupDomain.querySelector($jnode$.selector.controller.popup.content);
			popupContent.innerHTML = "<DIV class=\"calendar\"><DIV></DIV><UL class=\"submit\"><LI></LI><LI><BUTTON class=\"caution\">" + buttonTitle + "</BUTTON></LI></UL></DIV>";

			$controller$.popup.open({
				width:  (windowWidth > 736 ? 246 : 280),
				height: (windowWidth > 736 ? 236 : 325)
			});

			if (isoValue) {
				date = $module$.date.Utils.parse(isoValue);
			} else {
				date = new Date();
				isoValue = $module$.date.Utils.format(date);
			}

			var dateCalendar = popupDomain.querySelector("aside.popup article > div.calendar > div");
			var dateLi       = dateCalendar.nextElementSibling.firstElementChild;

			dateLi.innerHTML = $jnode$.escapeXML(dateFormatter.format(date, dateFormatter.DateStyle.LONG));
			dateLi.setAttribute("value", "iso:" + isoValue);

			displayCalendar(date, dateLi, dateCalendar, isoValue);

			dateLi.addEventListener("click", function() {
				var selectedIsoValue = this.getAttribute("value").substring(4);
				displayCalendar(selectedIsoValue, this, dateCalendar, selectedIsoValue);
			}, false);

			return dateLi;
		}

		function dateSelectEvent(dateInput) {
			var inputContainer = dateInput.parentNode;
			var isoValue       = inputContainer.getAttribute("value");
			var dateLi         = drawCalendar("확인", isoValue);

			dateLi.nextElementSibling.firstElementChild.addEventListener("click", function(event) {
				var selectedIsoValue = dateLi.getAttribute("value").substring(4);
				inputContainer.setAttribute("value", selectedIsoValue);
				inputContainer.firstElementChild.value = dateFormatter.format($module$.date.Utils.parse(selectedIsoValue), dateFormatter.DateStyle.LONG);

				$controller$.popup.close();
			}, false);
		}

		document.editForm.issued_date.addEventListener("click", function(event) {
			dateSelectEvent(this);
		}, false);

		function openPdf() {
			$controller$.winup.close();

			var title = "A-leave (재직증명서)";
			if (certificateType == "career")  title = "A-leave (경력증명서)";

			// IE는 adobe pdf reader plugin 설치하면 사용 가능하므로 조건문 수정
			// var allowEmbedded = ((window.navigator.userAgent.indexOf("Trident") > 0) && (window.navigator.userAgent.indexOf("Windows NT 10.") > 0)) ? 0 : 1;
			// if (allowEmbedded == 1 && ($jnode$.device.type != "desktop"))  allowEmbedded = -1;
			var allowEmbedded = ($jnode$.device.type == "desktop") ? 1 : -1;

			$jnode$.requireContent("popup", "/work/pdf/certificate", {
				widthP:           100,
				heightP:          100,
				title:            title,
				maxWidth:         640,
				allow_embedded:   allowEmbedded,
				certificate_id:   certificateId,
				certificate_type: certificateType
			});
		}

		document.editForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var updated = true;

			var params = {
				command:        "updateCertificate",
				certificate_id: certificateId,
				usage_value:    document.editForm.usage_value.value.trim(),
				issued_date:    document.editForm.issued_date.parentNode.getAttribute("value")
			};

			if (issued) {
				if (params.usage_value == dataset.usage_value && params.issued_date == dataset.issued_date) {
					updated = false;
				}
			}

			if (updated) {
				if (params.usage_value == "") {
					document.editForm.usage_value.select();
					this.parentNode.previousElementSibling.innerHTML = "용도를 입력해주세요.";
				} else {
					$controller$.loading.show();

					$jnode$.ajax.service({
						"url":      "/ajax/work.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":  params,
						"success": function(response) {
							var certificateTbody = document.querySelector("aside.grid > div > table > tbody");

							var selectedRow = certificateTbody.querySelector("tbody > tr.selected");
							if (selectedRow) {
								var issuedCell = selectedRow.querySelector("tr > td:nth-child(3)");
								issuedCell.firstChild.nodeValue = dateFormatter.format($module$.date.Utils.parse(params.issued_date), dateFormatter.DateStyle.MEDIUM);
								issuedCell.nextElementSibling.firstChild.nodeValue = params.usage_value;

								selectedRow.setAttribute("class", "selected");
							}

							var workMenu     = document.querySelector("body > nav > ul > li > label > input[value='/work'] + span");
							var checkedCount = document.querySelectorAll("aside.grid > div > table > tbody > tr.unchecked").length;

							if (checkedCount == 0)  workMenu.removeAttribute("class");
							else                    workMenu.setAttribute("class", checkedCount);  // TODO: ~~~~~~~

							openPdf();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			} else {
				openPdf();
			}
		}, false);
	}
};