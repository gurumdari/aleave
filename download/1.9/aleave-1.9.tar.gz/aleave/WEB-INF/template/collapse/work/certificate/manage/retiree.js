$content$.work.certificate.manage.retiree = {
	resize: function() {
		$controller$["grid#retiree"].resize(null, 246);
		$controller$["grid#retiree"].resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();
		var that = this;

		$jnode$.requireController("grid#retiree", {caller:that.conf}).on(function() {
			$controller$["grid#retiree"].service({
				sortable: true,
				height:   246
			});

			window.addEventListener("resize", that.resize, false);
			that.resize();

			var retireeTbody = document.querySelector("aside.popup article > div.popup > aside.grid#retiree > div > table > tbody");
			var searchButton = document.searchForm.querySelector("form > ul > li > button");
			var okButton     = document.querySelector("aside.popup article > div.popup > ul.submit > li > button");

			okButton.disabled = true;

			function appendRetireeRow(retireeData) {
				var retireeInfo = JSON.parse(retireeData.user_note);
				var userId      = retireeData.user_id;

				var row = document.createElement("tr");
				row.setAttribute("id", userId);
				row.setAttribute("value", retireeData.user_note);
				if (retireeData.user_address)  row.setAttribute("title", retireeData.user_address);
				retireeTbody.appendChild(row);

				var nameCell = row.insertCell(0);
				nameCell.appendChild(document.createTextNode(retireeData.user_name));
				nameCell.setAttribute("class", "member");

				var birthdayCell = row.insertCell(1);
				birthdayCell.appendChild(document.createTextNode(retireeData.user_birthday ? dateFormatter.format($module$.date.Utils.parse(retireeData.user_birthday), dateFormatter.DateStyle.MEDIUM) : ""));
				birthdayCell.setAttribute("id", retireeData.user_birthday);
		
				var contactCell = row.insertCell(2);
				contactCell.appendChild(document.createTextNode(retireeData.user_contact ? retireeData.user_contact : ""));

				var orgCell = row.insertCell(3);
				orgCell.appendChild(document.createTextNode(retireeInfo.org_name));

				var positionCell = row.insertCell(4);
				positionCell.appendChild(document.createTextNode(retireeInfo.position_name));

				var entryCell = row.insertCell(5);
				entryCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(retireeData.entry_date), dateFormatter.DateStyle.MEDIUM)));
				entryCell.setAttribute("id", retireeData.entry_date);

				var quittingCell = row.insertCell(6);
				quittingCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(retireeData.quitting_date), dateFormatter.DateStyle.MEDIUM)));
				quittingCell.setAttribute("id", retireeData.quitting_date);

				row.addEventListener("click", function(event) {
					var selectedRow = retireeTbody.querySelector("tbody > tr.selected");
					if (selectedRow)  selectedRow.removeAttribute("class");

					this.setAttribute("class", "selected");
					okButton.disabled = false;
				}, false);
			}

			for (var i = 0; i < that.dataset.retireeList.length; i++) {
				appendRetireeRow(that.dataset.retireeList[i]);
			}

			$controller$.loading.hide();

			searchButton.addEventListener("click", function(event) {
				var params = {
					command: "sercheRetireeList",
					keyword: document.searchForm.keyword.value.trim()
				};

				if (params.keyword == "") {
					document.searchForm.keyword.setAttribute("placeholder", "검색할 퇴사자 이름을 입력해주세요.");
					document.searchForm.keyword.value = "";
					document.searchForm.keyword.focus();
				} else {
					$controller$.loading.show();

					$jnode$.ajax.service({
						"url":      "/ajax/user.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":  params,
						"success": function(response) {
							$controller$["grid#retiree"].clear();
							okButton.disabled = true;

							for (var i = 0; i < response.length; i++) {
								appendRetireeRow(response[i]);
							}
				
							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			}, false);

			document.searchForm.keyword.addEventListener("keydown", function(event) {
				var keyCode = event.keyCode || event.which;

				if (keyCode == 13) {
					event.preventDefault();
					searchButton.click();
				}
			}, false);

			okButton.addEventListener("click", function(event) {
				var selectedRow  = retireeTbody.querySelector("tbody > tr.selected");
				var nameCell     = selectedRow.firstElementChild;
				var orgCell      = nameCell.nextElementSibling.nextElementSibling.nextElementSibling;
				var positionCell = orgCell.nextElementSibling;

				var userNote = {
					org_name:      orgCell.firstChild.nodeValue,
					position_name: positionCell.firstChild.nodeValue
				};

				var userInfo = {
					user_id:   selectedRow.getAttribute("id"),
					user_name: nameCell.firstChild.nodeValue,
					user_note: JSON.stringify(userNote)
				};

				document.addForm.requester.value = userInfo.user_name + " (" + userNote.position_name + ") @ " + userNote.org_name;
				document.addForm.requester.parentNode.setAttribute("value", JSON.stringify(userInfo));
				$controller$.popup.close();
			}, false);
		});

		if (document.searchForm.keyword.value == "")  document.searchForm.keyword.focus();
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};