$content$.work.certificate.manage = {
	appendCertificateRow: function(certificateTbody, certificateData, isFirst) {
		var row = document.createElement("tr");
		row.setAttribute("id", certificateData.certificate_id);

		if (isFirst) {
			certificateTbody.insertBefore(row, certificateTbody.firstElementChild);
		} else {
			certificateTbody.appendChild(row);
		}

		var userInfo = certificateData.userInfo;

		var certificateType = certificateData.certificate_type;
		var nameCell = row.insertCell(0);
		nameCell.setAttribute("class", certificateType);

		if (certificateType == "employment") {
			nameCell.appendChild(document.createTextNode(userInfo.user_name + " (" + userInfo.position_name + ") @ " + userInfo.org_name));
		} else {
			var retireeInfo = JSON.parse(userInfo.user_note);
			nameCell.appendChild(document.createTextNode(userInfo.user_name + " (" + retireeInfo.position_name + ") @ " + retireeInfo.org_name));
		}

		var requestCell = row.insertCell(1);
		requestCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(certificateData.request_date), dateFormatter.DateStyle.MEDIUM)));

		var issuedCell = row.insertCell(2);
		if (certificateData.issued_date) {
			issuedCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(certificateData.issued_date), dateFormatter.DateStyle.MEDIUM)));
		} else {
			issuedCell.appendChild(document.createTextNode(""));
			row.setAttribute("class", "unchecked");
		}

		var usageCell = row.insertCell(3);
		usageCell.appendChild(document.createTextNode(certificateData.usage_value));

		var commentCell = row.insertCell(4);
		commentCell.appendChild(document.createTextNode(certificateData.request_comment));

		row.addEventListener("click", function(event) {
			var selectedRow = certificateTbody.querySelector("tbody > tr.selected");
			if (selectedRow)  $jnode$.node.removeClass(selectedRow, "selected");

			$jnode$.node.addClass(this, "selected");

			document.querySelector("div.section > article > div.article > fieldset > button:first-child").disabled = false;
		}, false);

		return row;
	},

	getCertificateList: function(year, certificateId) {
		$controller$.loading.show();

		$jnode$.ajax.service({
			"url":      "/ajax/work.json",
			"method":   "POST",
			"datatype": "json",
			"headers": {
				"Content-Type": "application/json",
				"Accept":       "application/json"
			},
			"params":  {
				command: "getCertificateList",
				year:    year
			},
			"success": function(response) {
				$controller$.grid.clear("tbody");
				document.querySelector("div.section > article > div.article > fieldset > button:first-child").disabled = true;

				var certificateTbody = document.querySelector("body > section > div.section > article > div.article > aside.grid > div > table > tbody");

				for (var i = 0; i < response.certificateList.length; i++) {
					$content$.work.certificate.manage.appendCertificateRow(certificateTbody, response.certificateList[i]);
				}

				if (certificateId) {
					var selectedRow = certificateTbody.querySelector("tbody > tr[id='" + certificateId + "']");
					if (selectedRow)  selectedRow.click();
				}

				$controller$.loading.hide();
			},
			"error": function(error) {
				$jnode$.ajax.alertError(error);
				$controller$.loading.hide();
			}
		});
	},

	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if ($content$.work.certificate.manage.dataset.status == 0) {
			if (windowWidth > 736) {
				windowHeight -= 114;
			} else if (windowWidth > 640) {
				windowHeight -= 219;
			} else {
				windowHeight -= 239;
			}

			document.querySelector("body > section > div.section > article > div.article > ul.not_set").style.height = windowHeight + "px";
		} else {
			if (windowWidth > 736) {
				$controller$.grid.resize(null, windowHeight - 178);
			} else {
				$controller$.grid.removeHeight();
			}

			$controller$.grid.resizeScrollButtons();
		}
	},

	service: function() {
		$jnode$.pushHistory(this.conf);

		if (this.dataset.status == 0) {
			this.resize();
			window.addEventListener("resize", this.resize, false);
		} else {
			$controller$.loading.show();

			var that         = this;
			var waitingCount = this.dataset.waiting_count;

			if (waitingCount)  setWaitingCount(waitingCount);

			var curYear  = this.dataset.cur_year;
			var yearList = this.dataset.year_list;
			if (yearList.indexOf(curYear) < 0) {
				yearList.push(curYear);
				yearList = yearList.sort().reverse();
			}

			var yearSelect   = document.querySelector("body > section > div.section > article > div.article > ul > li:first-child > select");
			var issueButton  = document.querySelector("div.section > article > div.article > fieldset > button:first-child");
			var directButton = issueButton.nextElementSibling;

			// IE는 adobe pdf reader plugin 설치하면 사용 가능하므로 조건문 수정
			// var allowEmbedded = ((window.navigator.userAgent.indexOf("Trident") > 0) && (window.navigator.userAgent.indexOf("Windows NT 10.") > 0)) ? 0 : 1;
			// if (allowEmbedded == 1 && ($jnode$.device.type != "desktop"))  allowEmbedded = -1;
			var allowEmbedded = ($jnode$.device.type == "desktop") ? 1 : -1;

			issueButton.disabled = true;

			for (var i = 0; i < yearList.length; i++) {
				yearSelect.add(new Option(yearList[i] + "년", yearList[i]));
			}

			$jnode$.requireController("grid", {caller:that.conf}).on(function() {
				$controller$.grid.service();

				window.addEventListener("resize", that.resize, false);
				that.resize();

				$content$.work.certificate.manage.getCertificateList(yearSelect.value);

				yearSelect.addEventListener("change", function(event) {
					$content$.work.certificate.manage.getCertificateList(this.value);
				}, false);

				issueButton.addEventListener("click", function(event) {
					var selectedRow   = document.querySelector("body > section > div.section > article > div.article > aside.grid > div > table > tbody > tr.selected");
					var certificateId = selectedRow.getAttribute("id");

					if ($jnode$.node.hasClass(selectedRow, "unchecked")) {
						$jnode$.requireContent("winup", "/work/certificate/manage/edit", {
							useLoading:     true,
							icon:           true,
							title:          "재직증명서 발급",
							width:          480,
							height:         250,
							certificate_id: certificateId
						});
					} else {
						var certificateType = selectedRow.firstElementChild.getAttribute("class");

						$jnode$.requireContent("popup", "/work/pdf/certificate", {
							widthP:           100,
							heightP:          100,
							title:            certificateType == "career" ? "A-leave (경력증명서)" : "A-leave (재직증명서)",
							maxWidth:         640,
							allow_embedded:   allowEmbedded,
							certificate_id:   certificateId,
							certificate_type: certificateType
						});
					}
				}, false);

				directButton.addEventListener("click", function(event) {
					var hiddenType = "employment";
					if (that.dataset.has_info)  hiddenType = "career";

					$jnode$.requireContent("winup", "/work/certificate/manage/add", {
						useLoading:  true,
						icon:        true,
						title:       this.getAttribute("title"),
						width:       480,
						height:      that.dataset.is_admin ? 180 : 211,
						has_info:    that.dataset.has_info,
						is_admin:    that.dataset.is_admin,
						hidden_type: hiddenType
					});
				}, false);
			});
		}
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};