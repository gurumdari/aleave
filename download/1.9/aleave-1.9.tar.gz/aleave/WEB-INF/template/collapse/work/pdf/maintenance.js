$content$.work.pdf.maintenance = {
	resize: function() {
		var windowWidth    = window.innerWidth;
		var popupContainer = document.querySelector("aside.popup > ul > li > div");
		if (this.conf.edit_mode)  popupContainer = document.querySelector("aside.popup#preview > ul > li > div");

		var heightCorrection = 84;
		var iframeSpacing    = 51;

		if (this.conf.edit_mode || this.allow_embedded < 1) {
			heightCorrection = 116;
			iframeSpacing    = 82;
		}

		popupContainer.style.maxWidth = "640px";
		popupContainer.style.removeProperty("max-height");

		if (windowWidth > 736) {
			// 297 /  210 = 1.414285714
			var popupWidth  = popupContainer.clientWidth;
			var popupHeight = popupContainer.clientHeight;

			if ((popupHeight - heightCorrection) / (popupWidth - 40) >= 1.4) {
				popupContainer.style.maxHeight = ((popupWidth - 40) * 1.4 + heightCorrection) + "px";
			} else {
				var newWidth = (popupHeight - heightCorrection) / 1.4 + 40;
				if (newWidth < 300)  newWidth = 300;
				popupContainer.style.maxWidth = newWidth + "px";
			}
		}

		popupContainer.querySelector("div > article > div.popup > iframe").style.height = (popupContainer.clientHeight - iframeSpacing) + "px";
	},

	service: function() {
		var maintenanceId   = this.dataset.maintenance_id;

		this.resize();
		window.addEventListener("resize", this.resize, false);

		document.pdfForm.action = $jnode$.contextPath + "/work/pdf/maintenance/" + this.conf.title + ".pdf";  // #toolbar=0

		if (this.conf.allow_embedded == 1) {
			document.pdfForm.target = "pdfFrame";
			document.pdfForm.submit();
		} else {
			document.pdfForm.querySelector("form > ul.submit > li > button:last-child").nextElementSibling.addEventListener("click", function() {
				document.pdfForm.submit();
			}, false);
		}

		var editButton = document.pdfForm.querySelector("form > ul.submit > li > button.popup");

		if (editButton) {
			editButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/work/maintenance/activity", {
					icon:           true,
					title:          "유지보수활동 내역서 편집",
					width:          512,
					height:         447,
					maintenance_id: maintenanceId
				});

				$controller$.popup.close();
				$controller$["popup#preview"].close();
			}, false);
		}
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};