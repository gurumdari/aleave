$content$.work.maintenance.mail = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var editorHeight = window.innerHeight;
		var notificationDiv = document.mailForm.querySelector("form > hr + div");
		if (windowWidth > 480) {
			editorHeight -= 185;
		} else {
			editorHeight -= 278;
		}

		if (notificationDiv) {
			editorHeight -= (notificationDiv.offsetHeight + 5);
		}

		$controller$.editor.resize(null, editorHeight);
	},

	service: function() {
		var that = this;
		var maintenanceId    = this.dataset.maintenance_id;
		var userName         = this.dataset.user_name;
		var customerName     = this.dataset.customer_name;
		var mailNotification = this.dataset.mail_notification;

		$jnode$.requireControllers(["editor", "popup#preview"], {caller:that.conf}, function() {
			$controller$.editor.service({
				tabs:   "--",
				scheme: "light",
			});

			window.addEventListener("resize", that.resize, false);
			that.resize();

			if (mailNotification == "true") {
				document.mailForm.customer_email.addEventListener("change", function(event) {
					var emailNode = document.mailForm.querySelector("aside.editor > div:last-child > ul > li:last-child > div[contenteditable] table > tbody > tr > td > div > code.email");
					if (emailNode)  emailNode.innerHTML = $jnode$.escapeXML(this.value);
				}, false);
			}

			var editButton    = document.mailForm.querySelector("form > ul.submit > li:first-child > button:first-child");
			var previewButton = editButton.nextElementSibling;
			var sendButton    = previewButton.parentNode.nextElementSibling.firstElementChild;

			editButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/work/maintenance/activity", {
					icon:           true,
					title:          "유지보수활동 내역서 편집",
					width:          522,
					height:         447,
					maintenance_id: maintenanceId
				});

				$controller$.popup.close();
			}, false);

			// IE는 adobe pdf reader plugin 설치하면 사용 가능하므로 조건문 수정
			// var allowEmbedded = ((window.navigator.userAgent.indexOf("Trident") > 0) && (window.navigator.userAgent.indexOf("Windows NT 10.") > 0)) ? 0 : 1;
			// if (allowEmbedded == 1 && ($jnode$.device.type != "desktop"))  allowEmbedded = -1;
			var allowEmbedded = ($jnode$.device.type == "desktop") ? 1 : -1;

			previewButton.addEventListener("click", function(event) {
				$jnode$.requireContent("popup#preview", "/work/pdf/maintenance", {
					widthP:         100,
					heightP:        100,
					title:          "A-leave (유지보수활동 내역서)",
					maxWidth:       640,
					allow_embedded: allowEmbedded,
					maintenance_id: maintenanceId,
					edit_mode:      true
				});
			}, false);

			sendButton.addEventListener("click", function(event) {
				var params = {
					maintenance_id: maintenanceId,
					user_name:      userName,
					user_email:     document.mailForm.user_email.value.trim(),
					customer_name:  customerName,
					customer_email: document.mailForm.customer_email.value.trim(),
					email_subject:  document.mailForm.email_subject.value.trim(),
					email_content:  $controller$.editor.getHTMLContent()
				};

				var alertMessage = "";
				var focusedField = null;

				if (params.user_email == "") {
					alertMessage = "보내는 사람 E-mail 주소를 입력해주세요.";
					focusedField = document.mailForm.user_email;
				} else if (params.customer_email == "") {
					alertMessage = "받는 사람 E-mail 주소를 입력해주세요.";
					focusedField = document.mailForm.customer_email;
				} else if (params.email_subject == "") {
					alertMessage = "제목을 입력해주세요.";
					focusedField = document.mailForm.email_subject;
				} else if (["", "<div><br></div>"].indexOf(params.email_content.trim()) > -1) {
					alertMessage = "내용을 입력해주세요.";
					focusedField = $controller$.editor;
				}

				if (alertMessage) {
					$controller$.prompt.alert(alertMessage, function(close) {
						focusedField.select();
						close();
					}, true);
				} else {
					$controller$.loading.show();

					$jnode$.ajax.service({
						"url":      "/ajax/maintenance/mail.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":  params,
						"success": function(response) {
							var selectedRow = document.querySelector("aside.grid > div > table > tbody > tr.selected");
							var statusCell  = selectedRow.querySelector("tr > td:last-child");

							statusCell.firstChild.nodeValue = "확인중";
							statusCell.setAttribute("value", "결재상태")
							document.querySelector("div.section > article > div.article > fieldset > button:last-child > div").firstChild.nodeValue = "결재상태";

							$jnode$.node.removeClass(selectedRow, "unchecked");

							$controller$.popup.close();
							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			}, false);

			$controller$.editor.focus();
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};