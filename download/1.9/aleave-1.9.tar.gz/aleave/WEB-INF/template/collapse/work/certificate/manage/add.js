$content$.work.certificate.manage.add = {
	service: function() {
		var dataset       = this.dataset;
		var requesterId   = dataset.requester_info.user_id;
		var issuedDate    = dataset.issued_date;

		function drawCalendar(buttonTitle, isoValue) {
			var date         = null;
			var windowWidth  = window.innerWidth;
			var popupDomain  = $jnode$.controller.getDomain("popup");
			var popupContent = popupDomain.querySelector($jnode$.selector.controller.popup.content);
			popupContent.innerHTML = "<DIV class=\"calendar\"><DIV></DIV><UL class=\"submit\"><LI></LI><LI><BUTTON class=\"caution\">" + buttonTitle + "</BUTTON></LI></UL></DIV>";

			$controller$.popup.open({
				width:  (windowWidth > 736 ? 246 : 280),
				height: (windowWidth > 736 ? 236 : 325)
			});

			if (isoValue) {
				date = $module$.date.Utils.parse(isoValue);
			} else {
				date = new Date();
				isoValue = $module$.date.Utils.format(date);
			}

			var dateCalendar = popupDomain.querySelector("aside.popup article > div.calendar > div");
			var dateLi       = dateCalendar.nextElementSibling.firstElementChild;

			dateLi.innerHTML = $jnode$.escapeXML(dateFormatter.format(date, dateFormatter.DateStyle.LONG));
			dateLi.setAttribute("value", "iso:" + isoValue);

			displayCalendar(date, dateLi, dateCalendar, isoValue);

			dateLi.addEventListener("click", function() {
				var selectedIsoValue = this.getAttribute("value").substring(4);
				displayCalendar(selectedIsoValue, this, dateCalendar, selectedIsoValue);
			}, false);

			return dateLi;
		}

		function dateSelectEvent(dateInput) {
			var inputContainer = dateInput.parentNode;
			var isoValue       = inputContainer.getAttribute("value");
			var dateLi         = drawCalendar("확인", isoValue);

			dateLi.nextElementSibling.firstElementChild.addEventListener("click", function(event) {
				var selectedIsoValue = dateLi.getAttribute("value").substring(4);
				inputContainer.setAttribute("value", selectedIsoValue);
				inputContainer.firstElementChild.value = dateFormatter.format($module$.date.Utils.parse(selectedIsoValue), dateFormatter.DateStyle.LONG);

				$controller$.popup.close();
			}, false);
		}

		if (document.addForm.certificate_type) {
			var employmentRow = document.addForm.querySelector("form > table > tbody > tr.employment");
			var careerRow     = employmentRow.nextElementSibling;

			document.addForm.certificate_type.addEventListener("change", function(event) {
				if (this.value == "employment") {
					if (dataset.has_info) {
						employmentRow.setAttribute("class", "employment");
						careerRow.setAttribute("class", "career hidden");
					} else {
						this.value = "career";
						$controller$.prompt.confirm("생년월일과 주소는 재직증명서에서 필요로 하는 정보입니다. \"개인 정보\" 화면으로 이동하겠습니까?", function(close) {
							linkArticle("/setting/account");
							$controller$.winup.close();
							close();
						}, null, 1);
					}
				} else {
					employmentRow.setAttribute("class", "employment hidden");
					careerRow.setAttribute("class", "career");
				}
			}, false);
		}

		if (document.addForm.requester) {
			document.addForm.requester.addEventListener("click", function(event) {
				var keyword = "";
				var strUserInfo = this.parentNode.getAttribute("value");
				if (strUserInfo)  keyword = JSON.parse(strUserInfo).user_name;

				$jnode$.requireContent("popup", "/work/certificate/manage/retiree", {
					widthP:    100,
					heightP:   100,
					maxWidth:  638,
					maxHeight: 360,
					keyword:   keyword
				});
			}, false);
		}

		document.addForm.issued_date.addEventListener("click", function(event) {
			dateSelectEvent(this);
		}, false);

		function openPdf(certificateId, certificateType) {
			$controller$.winup.close();

			var title = "A-leave (재직증명서)";
			if (certificateType == "career")  title = "A-leave (경력증명서)";

			// IE는 adobe pdf reader plugin 설치하면 사용 가능하므로 조건문 수정
			// var allowEmbedded = ((window.navigator.userAgent.indexOf("Trident") > 0) && (window.navigator.userAgent.indexOf("Windows NT 10.") > 0)) ? 0 : 1;
			// if (allowEmbedded == 1 && ($jnode$.device.type != "desktop"))  allowEmbedded = -1;
			var allowEmbedded = ($jnode$.device.type == "desktop") ? 1 : -1;

			$jnode$.requireContent("popup", "/work/pdf/certificate", {
				widthP:           100,
				heightP:          100,
				title:            title,
				maxWidth:         640,
				allow_embedded:   allowEmbedded,
				certificate_id:   certificateId,
				certificate_type: certificateType
			});
		}

		document.addForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var params = {
				command:         "addCertificate",
				usage_value:     document.addForm.usage_value.value.trim(),
				issued_date:     document.addForm.issued_date.parentNode.getAttribute("value"),
				request_date:    issuedDate,
				request_comment: ""
			};

			var userInfo = {};

			if (document.addForm.certificate_type)  params.certificate_type = document.addForm.certificate_type.value;
			else                                    params.certificate_type = "career";

			if (params.certificate_type == "employment") {
				userInfo = dataset.requester_info;
				params.user_id = requesterId;
			} else {
				var strUserInfo = document.addForm.requester.parentNode.getAttribute("value");
				if (strUserInfo) {
					userInfo = JSON.parse(strUserInfo);
					params.user_id = userInfo.user_id;
				} else {
					params.user_id = "";
				}
			}

			if (params.user_id == "") {
				this.parentNode.previousElementSibling.innerHTML = "퇴사자를 선택해주세요.";
			} else if (params.usage_value == "") {
				document.addForm.usage_value.select();
				this.parentNode.previousElementSibling.innerHTML = "용도를 입력해주세요.";
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/work.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						var certificateTbody = document.querySelector("aside.grid > div > table > tbody");

						var certificateId   = response.certificate_id;
						var certificateYear = response.certificate_year;
						var yearSelect      = document.querySelector("body > section > div.section > article > div.article > ul > li:first-child > select");
						var workingYear     = yearSelect.value;
						var yearList        = Array.apply(null, yearSelect.options).map(function(el) { return el.value; });

						// 연도별 발급요청 목록 연도에 해당 연도가 없으면 연도를 새로 만들어준다.
						if (yearList.indexOf(certificateYear) < 0) {
							yearList.push(certificateYear);
							yearList = yearList.sort().reverse();

							yearSelect.innerHTML = "";

							for (var i = 0; i < yearList.length; i++) {
								yearSelect.add(new Option(yearList[i] + "년", yearList[i]));
							}
						}

						// 작업중인 연도랑 같으면 생성된 요청만 리스트에 추가하고, 그렇지 않으면 생성한 연도의 리스트로 이동한다.
						if (workingYear == certificateYear) {
							params.certificate_id = certificateId;
							params.userInfo       = userInfo;

							$content$.work.certificate.manage.appendCertificateRow(certificateTbody, params, true).click();
						} else {
							yearSelect.value = certificateYear;
							$content$.work.certificate.manage.getCertificateList(certificateYear, certificateId);
						}

						openPdf(certificateId, params.certificate_type);
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);
	}
};