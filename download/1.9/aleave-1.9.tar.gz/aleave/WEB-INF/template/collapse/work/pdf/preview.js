$content$.work.pdf.preview = {
	resize: function() {
		var windowWidth      = window.innerWidth;
		var popupContainer   = document.querySelector("aside.popup > ul > li > div");
		var heightCorrection = 116;
		var iframeSpacing    = 82;

		if ($content$.work.pdf.preview.conf.allow_embedded == 1) {
			heightCorrection = 84;
			iframeSpacing    = 51;
		}

		popupContainer.style.maxWidth = "640px";
		popupContainer.style.removeProperty("max-height");

		if (windowWidth > 736) {
			// 297 /  210 = 1.414285714
			var popupWidth  = popupContainer.clientWidth;
			var popupHeight = popupContainer.clientHeight;

			if ((popupHeight - heightCorrection) / (popupWidth - 40) >= 1.4) {
				popupContainer.style.maxHeight = ((popupWidth - 40) * 1.4 + heightCorrection) + "px";
			} else {
				var newWidth = (popupHeight - heightCorrection) / 1.4 + 40;
				if (newWidth < 300)  newWidth = 300;
				popupContainer.style.maxWidth = newWidth + "px";
			}
		}

		popupContainer.querySelector("div > article > div.popup > iframe").style.height = (popupContainer.clientHeight - iframeSpacing) + "px";
	},

	service: function() {
		document.pdfForm.action = $jnode$.contextPath + "/work/pdf/preview/" + this.conf.title + ".pdf";

		if (this.conf.allow_embedded == 1) {
			document.pdfForm.target = "pdfFrame";
			document.pdfForm.submit();
		} else {
			document.pdfForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
				document.pdfForm.submit();
			}, false);
		}

		this.resize();
		window.addEventListener("resize", this.resize, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};