$content$.work.maintenance = {
	appendMaintenanceRow: function(maintenanceTbody, maintenanceData, isFirst) {
		var row = document.createElement("tr");
		row.setAttribute("id", maintenanceData.maintenance_id);

		if (isFirst) {
			maintenanceTbody.insertBefore(row, maintenanceTbody.firstElementChild);
		} else {
			maintenanceTbody.appendChild(row);
		}

		var companyCell = row.insertCell(0);
		companyCell.appendChild(document.createTextNode(maintenanceData.customer_company));

		var userCell = row.insertCell(1);
		userCell.appendChild(document.createTextNode(maintenanceData.user_name));

		var createCell = row.insertCell(2);
		createCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(maintenanceData.create_date), dateFormatter.DateStyle.MEDIUM)));

		var statusCell = row.insertCell(3);

		var statusName  = "승인";
		var statusValue = "결재상태";
		var unchecked   = false;

		if (maintenanceData.approval_step == -1) {
			statusName  = "작성중";
			statusValue = "메일전송";
			unchecked   = true;
		} else if (maintenanceData.sign_step < 0)  {
			if (maintenanceData.approval_step == 0)  statusName = "확인거부";
			else                                     statusName = "반려";

			statusValue = "결재상태";
			companyCell.setAttribute("class", "rejected");
			statusCell.setAttribute("class", "rejected");
		} else if (maintenanceData.approval_step == 0) {
			statusName  = "확인중";
			statusValue = "결재상태";
		} else if (maintenanceData.approval_step == 1)  {
			if (maintenanceData.sign_step == 0) {
				statusName = "서명확인";
				unchecked  = true;
			}

			statusValue = "결재요청";
		} else if (maintenanceData.approval_step > maintenanceData.sign_step) {
			statusName = "결재중";

			if (maintenanceData.approver_sort == maintenanceData.sign_step + 1) {
				statusValue = "결재하기";
				unchecked = true;
			}
		}

		if (unchecked) {
			row.setAttribute("class", "unchecked");
		}

		statusCell.appendChild(document.createTextNode(statusName));
		statusCell.setAttribute("value", statusValue);

		row.addEventListener("click", function(event) {
			var selectedRow = maintenanceTbody.querySelector("tbody > tr.selected");
			if (selectedRow)  $jnode$.node.removeClass(selectedRow, "selected");

			$jnode$.node.addClass(this, "selected");

			var approveButton = document.querySelector("div.section > article > div.article > fieldset > button:last-child");
			approveButton.firstElementChild.innerHTML = this.lastElementChild.getAttribute("value");
			approveButton.disabled = false;
		}, false);

		return row;
	},

	getMaintenanceList: function(year, maintenanceId) {
		$controller$.loading.show();
		var userId = this.dataset.user_id;

		$jnode$.ajax.service({
			"url":      "/ajax/work.json",
			"method":   "POST",
			"datatype": "json",
			"headers": {
				"Content-Type": "application/json",
				"Accept":       "application/json"
			},
			"params":  {
				command: "getMaintenanceList",
				user_id: userId,
				year:    year
			},
			"success": function(response) {
				$controller$.grid.clear("tbody");

				var maintenanceTbody  = document.querySelector("aside.grid > div > table > tbody");

				for (var i = 0; i < response.maintenanceList.length; i++) {
					$content$.work.maintenance.appendMaintenanceRow(maintenanceTbody, response.maintenanceList[i]);
				}

				var approveButton = document.querySelector("div.section > article > div.article > fieldset > button:last-child");

				if (maintenanceId) {
					var selectedRow = maintenanceTbody.querySelector("tbody > tr[id='" + maintenanceId + "']");
					if (selectedRow)  selectedRow.click();
				} else {
					approveButton.disabled = true;
				}

				$controller$.loading.hide();
			},
			"error": function(error) {
				$jnode$.ajax.alertError(error);
				$controller$.loading.hide();
			}
		});
	},

	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if ($content$.work.maintenance.dataset.status == 0) {
			if (windowWidth > 736) {
				windowHeight -= 114;
			} else if (windowWidth > 640) {
				windowHeight -= 219;
			} else {
				windowHeight -= 239;
			}

			document.querySelector("body > section > div.section > article > div.article > ul.not_set").style.height = windowHeight + "px";
		} else {
			if (windowWidth > 736) {
				$controller$.grid.resize(null, windowHeight - 178);
			} else {
				$controller$.grid.removeHeight();
			}

			$controller$.grid.resizeScrollButtons();
		}
	},

	service: function() {
		$jnode$.pushHistory(this.conf);

		if (this.dataset.status == 0) {
			this.resize();
			window.addEventListener("resize", this.resize, false);
		} else {
			$controller$.loading.show();

			var that = this;

			var curYear  = this.dataset.cur_year;
			var yearList = this.dataset.year_list;
			if (yearList.indexOf(curYear) < 0) {
				yearList.push(curYear);
				yearList = yearList.sort().reverse();
			}

			var yearSelect    = document.querySelector("body > section > div.section > article > div.article > ul > li:first-child > select");
			var createButton  = document.querySelector("div.section > article > div.article > fieldset > button:first-child");
			var approveButton = createButton.nextElementSibling;

			for (var i = 0; i < yearList.length; i++) {
				yearSelect.add(new Option(yearList[i] + "년", yearList[i]));
			}

			$jnode$.requireController("grid", {caller:that.conf}).on(function() {
				$controller$.grid.service();

				window.addEventListener("resize", that.resize, false);
				that.resize();

				$content$.work.maintenance.getMaintenanceList(yearSelect.value);

				yearSelect.addEventListener("change", function(event) {
					$content$.work.maintenance.getMaintenanceList(this.value);
				}, false);

				createButton.addEventListener("click", function(event) {
					$jnode$.requireContent("winup", "/work/maintenance/activity", {
						icon:   true,
						title:  "유지보수활동 내역서 작성",
						width:  522,
						height: 447
					});
				}, false);

				// IE는 adobe pdf reader plugin 설치하면 사용 가능하므로 조건문 수정
				// var allowEmbedded = ((window.navigator.userAgent.indexOf("Trident") > 0) && (window.navigator.userAgent.indexOf("Windows NT 10.") > 0)) ? 0 : 1;
				// if (allowEmbedded == 1 && ($jnode$.device.type != "desktop"))  allowEmbedded = -1;
				var allowEmbedded = ($jnode$.device.type == "desktop") ? 1 : -1;
	
				approveButton.addEventListener("click", function(event) {
					var statusValue   = this.firstElementChild.innerHTML;
					var maintenanceId = document.querySelector("aside.grid > div > table > tbody > tr.selected").getAttribute("id");

					if (statusValue == "메일전송") {
						$jnode$.requireContent("popup", "/work/maintenance/mail", {
							widthP:         100,
							heightP:        100,
							maintenance_id: maintenanceId
						});
					} else if (statusValue == "결재요청") {
						$jnode$.requireContent("popup", "/work/maintenance/approval_line", {
							widthP:         100,
							heightP:        100,
							allow_embedded: allowEmbedded,
							maintenance_id: maintenanceId
						});
					} else if (statusValue == "결재하기") {
						$jnode$.requireContent("popup", "/work/maintenance/approve", {
							widthP:         100,
							heightP:        100,
							allow_embedded: allowEmbedded,
							maintenance_id: maintenanceId
						});
					} else if (statusValue == "결재상태") {
						$jnode$.requireContent("popup", "/work/pdf/maintenance", {
							widthP:         100,
							heightP:        100,
							title:          "A-leave (유지보수활동 내역서)",
							maxWidth:       640,
							allow_embedded: allowEmbedded,
							maintenance_id: maintenanceId
						});
					}
				}, false);
			});
		}
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};