$content$.timeoff.approval = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if (windowWidth > 736) {
			$controller$.grid.resize(null, windowHeight - 178);
		} else {
			$controller$.grid.removeHeight();
		}

		$controller$.grid.resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();

		var that         = this;
		var dataset      = this.dataset;
		var worker       = dataset.worker;

		$jnode$.pushHistory(this.conf);
		setWaitingCount(this.dataset.waiting_count);

		var curYear  = this.dataset.cur_year;
		var yearList = this.dataset.year_list;
		if (yearList.indexOf(curYear) < 0) {
			yearList.push(curYear);
			yearList = yearList.sort().reverse();
		}

		var yearSelect     = document.querySelector("body > section > div.section > article > div.article > ul > li:first-child > select");
		var approvalButton = document.querySelector("div.section > article > div.article > fieldset > button");

		approvalButton.disabled = true;

		for (var i = 0; i < yearList.length; i++) {
			yearSelect.add(new Option(yearList[i] + "년", yearList[i]));
		}

		$jnode$.requireController("grid", {caller:that.conf}).on(function() {
			$controller$.grid.service();

			var approvalTbody = document.querySelector("aside.grid > div > table > tbody");

			window.addEventListener("resize", that.resize, false);
			that.resize();

			function appendApprovalRow(approvalData) {
				var row = document.createElement("tr");
				row.setAttribute("id", approvalData.timeoff_id);
				approvalTbody.appendChild(row);

				var myStep = approvalData.approver_sort + 1;
				var stepStatus = approvalData.sign_status;

				if (approvalData.sign_step < 0) {
					stepStatus = "rejected";
				} else if ((approvalData.sign_status == "waiting") && (approvalData.sign_step == myStep - 1)) {
					stepStatus = "unchecked";
				}

				row.setAttribute("class", stepStatus);

				var stepCell = row.insertCell(0);
				stepCell.appendChild(document.createTextNode((approvalData.approver_sort + 1) + " (" + Math.abs(approvalData.sign_step) + "/" + approvalData.approval_step + ")"));

				var typeCell = row.insertCell(1);
				typeCell.appendChild(document.createTextNode(approvalData.user_name + " - " + approvalData.type_name));

				if (approvalData.timeoff_end == null)  approvalData.timeoff_end = "";

				var periodValue   = "";
				var timeoffStarts = approvalData.timeoff_start.split(" ");
				var timeoffEnds   = approvalData.timeoff_end.split(" ");

				if (timeoffEnds.length == 1) {
					// 결근은 timeoffData.timeoff_end가 빈 문자로 넘어옴
					periodValue = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM) + " " + timeoffStarts[1];
				} else if (timeoffStarts[0] == timeoffEnds[0]) {
					periodValue = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM);
					if (timeoffStarts[1] == timeoffEnds[1])  periodValue += " " + (timeoffStarts[1] == "AM" ? "오전" : "오후");
				} else {
					var periodValue1 = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM);
					var periodValue2 = dateFormatter.format($module$.date.Utils.parse(timeoffEnds[0]), dateFormatter.DateStyle.MEDIUM);
					
					if (timeoffStarts[1] == "PM")  periodValue1 += " 오후";
					if (timeoffEnds[1]   == "AM")  periodValue2 += " 오전";

					periodValue = periodValue1 + " ~ " + periodValue2;
				}

				var periodCell = row.insertCell(2);
				periodCell.appendChild(document.createTextNode(periodValue));

				var requestDays = approvalData.request_days;

				if (approvalData.canceled_id > 0) {
					requestDays = requestDays * -1;
				}

				var requestDaysValue = approvalData.applied_days;
				if ((approvalData.sign_step > 0) && (approvalData.approval_step > approvalData.sign_step)) {
					requestDaysValue = requestDays;
				} else if (requestDays != approvalData.applied_days) {
					requestDaysValue = requestDays + "→" + approvalData.applied_days;
				}

				var requestDaysCell = row.insertCell(3);
				requestDaysCell.appendChild(document.createTextNode(requestDaysValue));

				var usedDaysCell = row.insertCell(4);
				usedDaysCell.appendChild(document.createTextNode(approvalData.used_days + "/" + approvalData.available_days));

				var createCell = row.insertCell(5);
				createCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(approvalData.create_date), dateFormatter.DateStyle.MEDIUM)));

				var statusValue = "";
				if (approvalData.sign_step < 0) {
					statusValue = "반려";
					typeCell.setAttribute("class", "rejected");
				} else if (approvalData.approval_step > approvalData.sign_step) {
					statusValue = "대기";
					typeCell.setAttribute("class", "waiting");
				} else {
					statusValue = "승인";
					typeCell.setAttribute("class", "approved");
				}

				if (approvalData.canceled_id > 0) {
					$jnode$.node.addClass(typeCell, "cancel");
					typeCell.appendChild(document.createTextNode(" 취소"));

					periodCell.setAttribute("class", "cancel");
				}

				var statusCell = row.insertCell(6);
				statusCell.appendChild(document.createTextNode(statusValue));

				row.addEventListener("click", function(event) {
					var selectedRow = approvalTbody.querySelector("tbody > tr.selected");
					if (selectedRow)  $jnode$.node.removeClass(selectedRow, "selected");

					$jnode$.node.addClass(this, "selected");

					approvalButton.disabled = false;

					if ($jnode$.node.hasClass(this, "unchecked")) {
						approvalButton.firstElementChild.innerHTML = "결재처리";
					} else {
						approvalButton.firstElementChild.innerHTML = "상세정보";
					}
				}, false);
			}

			function getApprovalList(year, userId) {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/timeoff.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  {
						command:     "getApprovalList",
						approver_id: worker,
						year:        year
					},
					"success": function(response) {
						$controller$.grid.clear("tbody");
						approvalButton.disabled = true;
						approvalButton.firstElementChild.innerHTML = "상세정보";

						for (var i = 0; i < response.approvalList.length; i++) {
							appendApprovalRow(response.approvalList[i]);
						}

						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}

			getApprovalList(yearSelect.value);

			yearSelect.addEventListener("change", function(event) {
				getApprovalList(this.value);
			}, false);

			approvalButton.addEventListener("click", function(event) {
				var selectedRow = approvalTbody.querySelector("tbody > tr.selected");
				var nodeId    = "/timeoff/approval/view";
				var winupName = "휴가 및 결근 상세정보";
				var height    = 386;

				if ($jnode$.node.hasClass(selectedRow, "unchecked")) {
					nodeId    = "/timeoff/approval/check";
					winupName = "휴가 및 결근 결재처리";
					height    = 424;
				}

				$jnode$.requireContent("winup", nodeId, {
					useLoading: true,
					icon:       true,
					title:      winupName,
					width:      480,
					height:     height,
					timeoff_id: selectedRow.getAttribute("id")
				});
			}, false);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};