$content$.timeoff.my.cancel = {
	service: function() {
		var dataset      = this.dataset;
		var approvalInfo = dataset.approvalInfo;
		var approverList = dataset.approverList;
		var isLeave = (["late", "early", "absence"].indexOf(approvalInfo.timeoff_type) < 0);

		if (isLeave) {
			var periodValue   = "";
			var timeoffStarts = approvalInfo.timeoff_start.split(" ");
			var timeoffEnds   = approvalInfo.timeoff_end.split(" ");

			if (timeoffStarts[0] == timeoffEnds[0]) {
				periodValue = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM);
				if (timeoffStarts[1] == timeoffEnds[1])  periodValue += " " + (timeoffStarts[1] == "AM" ? "오전" : "오후");
			} else {
				var periodValue1 = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM);
				var periodValue2 = dateFormatter.format($module$.date.Utils.parse(timeoffEnds[0]), dateFormatter.DateStyle.MEDIUM);

				if (timeoffStarts[1] == "PM")  periodValue1 += " 오후";
				if (timeoffEnds[1]   == "AM")  periodValue2 += " 오전";

				periodValue = periodValue1 + " ~ " + periodValue2;
			}

			var periodTd = document.querySelector("aside.popup article > div.popup > form > table.form > tbody > tr > td.leave");
			periodTd.innerHTML = periodValue;
			periodTd.previousElementSibling.firstElementChild.innerHTML = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr.leave > td").innerHTML;
		} else {
			var absenceTd = document.querySelector("aside.popup article > div.popup > form > table.form > tbody > tr > td.absence");
			absenceTd.previousElementSibling.firstElementChild.innerHTML = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr.absence > td").innerHTML;
		}

		var timeoffComment = document.cancelForm.timeoff_comment;

		timeoffComment.addEventListener("keydown", function(event) {
			var keyCode = event.keyCode || event.which;

			if(keyCode == 13) {
				event.preventDefault();
			}
		}, false);

		timeoffComment.addEventListener("paste", function(event) {
			window.setTimeout(function() {
				timeoffComment.value = timeoffComment.value.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");
			});
		}, false);

		timeoffComment.focus();

		document.cancelForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			$controller$.loading.show();

			var usedDaysSpan      = document.querySelector("body > section > div.section > article > div.article > ul > li:last-child > span:first-child");
			var availableDaysSpan = usedDaysSpan.nextElementSibling;
			var approverIds       = [];

			for (var i = 0; i < approverList.length; i++) {
				approverIds.push(approverList[i].approver_id);
			}

			var requestDays = approvalInfo.applied_days;
			if (requestDays == 0)  requestDays = approvalInfo.request_days

			var params = {
				command:         "cancelTimeoff",
				timeoff_id:      approvalInfo.timeoff_id,
				timeoff_comment: timeoffComment.value.trim(),
				available_days:  availableDaysSpan.innerHTML,
				used_days:       usedDaysSpan.innerHTML,
				request_days:    requestDays.toString(),
				applied_days:    (approvalInfo.applied_days * -1).toString(),
				sign_step:       (approverIds[0] == approvalInfo.user_id ? "1" : "0"),
				approver_ids:    JSON.stringify(approverIds)
			};

			$jnode$.ajax.service({
				"url":      "/ajax/timeoff.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params":  params,
				"success": function(response) {
					params.type_name      = approvalInfo.type_name;
					params.timeoff_start  = approvalInfo.timeoff_start;
					params.timeoff_end    = approvalInfo.timeoff_end;
					params.approval_step  = approvalInfo.approval_step;
					params.timeoff_id     = response.timeoff_id;
					params.create_date    = response.create_date;
					params.canceled_id    = approvalInfo.timeoff_id;

					var timeoffTbody = document.querySelector("aside.grid > div > table > tbody");
					$content$.timeoff.my.appendTimeoffRow(timeoffTbody, params, true).click();

					// 결재자가 본인만 있을 경우는 신청하면서 바로 결재된다.
					if ((approverIds.length == 1) && (params.sign_step == "1") && (params.applied_days != "0")) {
						usedDaysSpan.innerHTML = parseFloat(params.used_days) + parseFloat(params.applied_days);
					}
					
					$controller$.popup.close();
					$controller$.winup.close();
					$controller$.loading.hide();
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}, false);
	}
};