$content$.timeoff.my = {
	appendTimeoffRow: function(timeoffTbody, timeoffData, isFirst) {
		var row = document.createElement("tr");
		row.setAttribute("id", timeoffData.timeoff_id);

		if (isFirst) {
			timeoffTbody.insertBefore(row, timeoffTbody.firstElementChild);
		} else {
			timeoffTbody.appendChild(row);
		}

		var typeCell = row.insertCell(0);
		typeCell.appendChild(document.createTextNode(timeoffData.type_name));

		if (timeoffData.timeoff_end == null)  timeoffData.timeoff_end = "";

		var periodValue   = "";
		var timeoffStarts = timeoffData.timeoff_start.split(" ");
		var timeoffEnds   = timeoffData.timeoff_end.split(" ");

		if (timeoffEnds.length == 1) {
			// 결근은 timeoffData.timeoff_end가 빈 문자로 넘어옴
			periodValue = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM) + " " + timeoffStarts[1];
		} else if (timeoffStarts[0] == timeoffEnds[0]) {
			periodValue = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM);
			if (timeoffStarts[1] == timeoffEnds[1])  periodValue += " " + (timeoffStarts[1] == "AM" ? "오전" : "오후");
		} else {
			var periodValue1 = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM);
			var periodValue2 = dateFormatter.format($module$.date.Utils.parse(timeoffEnds[0]), dateFormatter.DateStyle.MEDIUM);
			
			if (timeoffStarts[1] == "PM")  periodValue1 += " 오후";
			if (timeoffEnds[1]   == "AM")  periodValue2 += " 오전";

			periodValue = periodValue1 + " ~ " + periodValue2;
		}

		var periodCell = row.insertCell(1);
		periodCell.appendChild(document.createTextNode(periodValue));

		var daysValue   = timeoffData.applied_days;
		var requestDays = timeoffData.request_days;

		if (timeoffData.canceled_id > 0) {
			requestDays = requestDays * -1;
		}

		if ((timeoffData.sign_step > 0) && (timeoffData.approval_step > timeoffData.sign_step)) {
			daysValue = requestDays;
		} else if (requestDays != timeoffData.applied_days) {
			daysValue = requestDays + "→" + timeoffData.applied_days;
		}

		var daysCell = row.insertCell(2);
		daysCell.appendChild(document.createTextNode(daysValue));

		var createCell = row.insertCell(3);
		createCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(timeoffData.create_date), dateFormatter.DateStyle.MEDIUM)));

		var statusValue = "";
		if (timeoffData.sign_step < 0) {
			statusValue = "반려 (" + (timeoffData.sign_step * -1) + "/" + timeoffData.approval_step + ")";
			typeCell.setAttribute("class", "rejected");
		} else if (timeoffData.approval_step > timeoffData.sign_step) {
			statusValue = "대기 (" + timeoffData.sign_step + "/" + timeoffData.approval_step + ")";
			typeCell.setAttribute("class", "waiting");
		} else {
			statusValue = "승인";
			typeCell.setAttribute("class", "approved");
		}

		if (timeoffData.canceled_id > 0) {
			$jnode$.node.addClass(typeCell, "cancel");
			typeCell.appendChild(document.createTextNode(" 취소"));

			periodCell.setAttribute("class", "cancel");
		}

		var statusCell = row.insertCell(4);
		statusCell.appendChild(document.createTextNode(statusValue));

		row.addEventListener("click", function(event) {
			var selectedRow = timeoffTbody.querySelector("tbody > tr.selected");
			if (selectedRow)  selectedRow.removeAttribute("class");

			this.setAttribute("class", "selected");
			document.querySelector("div.section > article > div.article > fieldset > button:nth-child(2)").disabled = false;
		}, false);

		return row;
	},

	getTimeoffList: function(year, timeoffId) {
		$controller$.loading.show();
		var dataset = this.dataset;

		// 지난 연도에 대해서는 검색달을 13으로, 현재 연도에 대해서는 현재 달을, 아직 오지 않은 연도에 대해서는 0으로 검색한다.
		var month = "13";
		if      (year == dataset.cur_year)  month = dataset.cur_month;
		else if (year >  dataset.cur_year)  month = "0";

		$jnode$.ajax.service({
			"url":      "/ajax/timeoff.json",
			"method":   "POST",
			"datatype": "json",
			"headers": {
				"Content-Type": "application/json",
				"Accept":       "application/json"
			},
			"params":  {
				command:     "getTimeoffList",
				user_id:     dataset.worker,
				entry_date:  dataset.entry_date,
				leave_basic: dataset.leave_basic,
				leave_count: dataset.leave_count,
				year:        year,
				month:       month
			},
			"success": function(response) {
				$controller$.grid.clear("tbody");

				document.querySelector("div.section > article > div.article > fieldset > button:nth-child(2)").disabled = true;
				var timeoffTbody  = document.querySelector("aside.grid > div > table > tbody");
				var usedDays      = document.querySelector("body > section > div.section > article > div.article > ul > li:last-child > span:first-child");
				var availableDays = usedDays.nextElementSibling;

				usedDays.innerHTML      = response.usedDays;
				availableDays.innerHTML = response.availableDays;

				for (var i = 0; i < response.timeoffList.length; i++) {
					$content$.timeoff.my.appendTimeoffRow(timeoffTbody, response.timeoffList[i]);
				}

				if (timeoffId) {
					var selectedRow = timeoffTbody.querySelector("tbody > tr[id='" + timeoffId + "']");
					if (selectedRow)  selectedRow.click();
				}

				$controller$.loading.hide();
			},
			"error": function(error) {
				$jnode$.ajax.alertError(error);
				$controller$.loading.hide();
			}
		});
	},

	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if (windowWidth > 736) {
			$controller$.grid.resize(null, windowHeight - 178);
		} else {
			$controller$.grid.removeHeight();
		}

		$controller$.grid.resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();

		var that       = this;
		var dataset    = this.dataset;
		var leaveBasic = dataset.leave_basic;

		$jnode$.pushHistory(this.conf);

		var curYear  = this.dataset.cur_year;
		var yearList = this.dataset.year_list;
		if (yearList.indexOf(curYear) < 0) {
			yearList.push(curYear);
			yearList = yearList.sort().reverse();
		}

		var yearSubfix = "";
		if (leaveBasic == "entry_month") {
			yearSubfix = " " + this.dataset.entry_month + "월 " + this.dataset.entry_day + "일 ~";
		}

		var yearSelect    = document.querySelector("body > section > div.section > article > div.article > ul > li:first-child > select");
		var requestButton = document.querySelector("div.section > article > div.article > fieldset > button:first-child");
		var editButton    = requestButton.nextElementSibling;

		editButton.disabled = true;

		for (var i = 0; i < yearList.length; i++) {
			yearSelect.add(new Option(yearList[i] + "년" + yearSubfix, yearList[i]));
		}

		$jnode$.requireController("grid", {caller:that.conf}).on(function() {
			$controller$.grid.service();

			var timeoffTbody = document.querySelector("aside.grid > div > table > tbody");

			window.addEventListener("resize", that.resize, false);
			that.resize();

			$content$.timeoff.my.getTimeoffList(yearSelect.value);

			yearSelect.addEventListener("change", function(event) {
				$content$.timeoff.my.getTimeoffList(this.value);
			}, false);

			requestButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/timeoff/my/request", {
					useLoading: true,
					icon:       true,
					title:      "휴가 및 결근 신청",
					width:      480,
					height:     400
				});
			}, false);

			editButton.addEventListener("click", function(event) {
				var selectedRow = timeoffTbody.querySelector("tbody > tr.selected");

				$jnode$.requireContent("winup", "/timeoff/approval/view", {
					useLoading: true,
					icon:       true,
					title:      "휴가 및 결근 결재처리 진행상황",
					width:      480,
					height:     386,
					timeoff_id: selectedRow.getAttribute("id")
				});
			}, false);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};