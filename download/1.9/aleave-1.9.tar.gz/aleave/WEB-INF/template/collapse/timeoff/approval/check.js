$content$.timeoff.approval.check = {
	service: function() {
		var dataset       = this.dataset;
		var periodLimit   = dataset.timeoff_period_limit;
		var leaveBasic    = dataset.leave_basic;
		var worker        = dataset.worker;
		var approvalInfo  = dataset.approvalInfo;
		var approverList  = dataset.approverList;
		var userId        = approvalInfo.user_id;
		var entryDates    = approvalInfo.entry_date.split("-");
		var isLeave       = (["late", "early", "absence"].indexOf(approvalInfo.timeoff_type) < 0);
		var cancelProcess = approvalInfo.canceled_id > 0;

		var stepContainer   = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr > td > div > ul");
		var detailContainer = stepContainer.nextElementSibling;
		var signStep        = "0";
		var waitingId       = null;
		var waitingStep     = 1;

		for (var i = 0; i < approverList.length; i++) {
			var approverId = approverList[i].approver_id;

			var approverLi = document.createElement("li");
			stepContainer.appendChild(approverLi);

			var approverLabel = document.createElement("label");
			approverLi.appendChild(approverLabel);

			var approverInput = document.createElement("input");
			approverInput.setAttribute("type", "radio");
			approverInput.setAttribute("name", "step_id");
			approverInput.value = approverId;
			approverLabel.appendChild(approverInput);

			if (approverList[i].sign_status == "waiting") {
				if (waitingId == null) {
					waitingId = approverId;
					approverInput.setAttribute("class", "unchecked");
					waitingStep = i + 1;
				} else {
					approverInput.setAttribute("class", "waiting");
				}
			}

			approverLabel.appendChild(document.createElement("span"));
			approverLabel.appendChild(document.createElement("div"));

			var detailTable = document.createElement("table");
			detailTable.setAttribute("id", approverId);
			detailTable.setAttribute("class", "form nogroup");
			detailContainer.appendChild(detailTable);

			var datailTbody = document.createElement("tbody");
			detailTable.appendChild(datailTbody);

			// 결재자
			var detailRow0 = datailTbody.insertRow(0);

			var detailTh0 = document.createElement("th");
			detailTh0.innerHTML = "결재자";
			detailRow0.appendChild(detailTh0);

			var detailTd0 = document.createElement("td");
			detailTd0.appendChild(document.createTextNode(approverList[i].approver_name + " (" + approverList[i].position_name + ") @ " + approverList[i].org_name));
			detailRow0.appendChild(detailTd0);

			if (approverList[i].agent_id)  detailTd0.setAttribute("class", "agent");

			if (approverId == waitingId) {
				signStep = (i + 1).toString();

				// 전달사항
				var detailRow1 = datailTbody.insertRow(1);

				var detailTh1 = document.createElement("th");
				detailTh1.innerHTML = "전달사항";
				detailRow1.appendChild(detailTh1);

				var detailTd1 = document.createElement("td");
				detailTd1.setAttribute("class", "textarea");
				detailRow1.appendChild(detailTd1);

				var detailText = document.createElement("textarea");
				detailText.setAttribute("name", "approver_comment");
				detailTd1.appendChild(detailText);
			} else if (approverList[i].sign_date) {
				// 결재일
				var detailRow1 = datailTbody.insertRow(1);

				var detailTh1 = document.createElement("th");
				detailTh1.innerHTML = "결재일";
				detailRow1.appendChild(detailTh1);

				var detailTd1 = document.createElement("td");
				detailTd1.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(approverList[i].sign_date), "DEFAULT")));
				detailRow1.appendChild(detailTd1);

				if (userId != approverId) {
					// 전달사항
					var detailRow2 = datailTbody.insertRow(2);

					var detailTh2 = document.createElement("th");
					detailTh2.innerHTML = "전달사항";
					detailRow2.appendChild(detailTh2);

					var detailTd2 = document.createElement("td");
					detailTd2.appendChild(document.createTextNode(approverList[i].approver_comment));
					detailRow2.appendChild(detailTd2);
				}
			}

			approverInput.addEventListener("click", function(event) {
				var selectedTable = detailContainer.querySelector("div > table.selected");
				if (selectedTable)  $jnode$.node.removeClass(selectedTable, "selected");

				var approverId = this.value;
				$jnode$.node.addClass(detailContainer.querySelector("div > table[id='" + approverId + "']"), "selected");
			}, false);
		}

		stepContainer.querySelector("ul > li > label > input[value='" + waitingId + "']").click();

		if (waitingId != worker) {
			document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr > th > span.agent").innerHTML = "(" + waitingStep + "단계 대리 결재)";
		}

		var approverComment = document.approvalForm.approver_comment;

		approverComment.addEventListener("keydown", function(event) {
			var keyCode = event.keyCode || event.which;

			if(keyCode == 13) {
				event.preventDefault();
			}
		}, false);

		approverComment.addEventListener("paste", function(event) {
			window.setTimeout(function() {
				approverComment.value = approverComment.value.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");
			});
		}, false);

		if (isLeave) {
			var periodSpan    = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr > td.leave > span");
			var periodValue   = "";
			var timeoffStarts = approvalInfo.timeoff_start.split(" ");
			var timeoffEnds   = approvalInfo.timeoff_end.split(" ");

			if (timeoffStarts[0] == timeoffEnds[0]) {
				periodValue = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM);
				if (timeoffStarts[1] == timeoffEnds[1])  periodValue += " " + (timeoffStarts[1] == "AM" ? "오전" : "오후");
			} else {
				var periodValue1 = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM);
				var periodValue2 = dateFormatter.format($module$.date.Utils.parse(timeoffEnds[0]), dateFormatter.DateStyle.MEDIUM);
				
				if (timeoffStarts[1] == "PM")  periodValue1 += " 오후";
				if (timeoffEnds[1]   == "AM")  periodValue2 += " 오전";

				periodValue = periodValue1 + " ~ " + periodValue2;
			}

			document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr > td.leave > span").innerHTML = periodValue;
		} else {
			var appliedDaysOptions = [
				{ text: "1시간",  value: "0.125" },
				{ text: "2시간",  value: "0.25"  },
				{ text: "3시간",  value: "0.375" },
				{ text: "4시간",  value: "0.5",   alias: "0.5일" },
				{ text: "5시간",  value: "0.625" },
				{ text: "6시간",  value: "0.75"  },
				{ text: "7시간",  value: "0.875" },
				{ text: "8시간",  value: "1",     alias: "1일"},
				{ text: "9시간",  value: "1.125", alias: "+1시간"},
				{ text: "10시간", value: "1.25",  alias: "+2시간"},
				{ text: "11시간", value: "1.375", alias: "+3시간"},
				{ text: "12시간", value: "1.5",   alias: "+0.5일"},
			];

			for (var i = 0; i < appliedDaysOptions.length; i++) {
				var optionText = appliedDaysOptions[i].text;
				if (cancelProcess)  optionText = "-" + optionText;

				if (appliedDaysOptions[i].alias) {
					optionText += " (" + appliedDaysOptions[i].alias + ")";
				}

				document.approvalForm.applied_days.add(new Option(optionText, appliedDaysOptions[i].value));
			}

			document.approvalForm.applied_days.value = Math.abs(approvalInfo.applied_days);
		}

		document.approvalForm.sign_status.addEventListener("change", function(event) {
			var applyDaysSpan = this.nextElementSibling;

			if (this.value == "approved")  applyDaysSpan.removeAttribute("style");
			else                           applyDaysSpan.style.display = "none";
		}, false);

		document.querySelector("aside.winup article > div.winup > form > ul.submit > li > button").addEventListener("click", function(event) {
			var alertMessage = "";
			var appliedDays  = parseFloat(document.approvalForm.applied_days.value.trim());

			var params = {
				command:          "updateApprover",
				timeoff_id:       dataset.timeoff_id,
				approver_id:      waitingId,
				approver_comment: approverComment.value.trim(),
				sign_status:      document.approvalForm.sign_status.value,
				sign_step:        signStep,
				canceled_id:      "0"
			};

			if (waitingId != worker) {
				params.agent_id = worker;
			}

			if (isNaN(appliedDays)) {
				// 결근시간은 select이므로 다른 값이 올 수 없다.
				alertMessage = "승인일수는 숫자만 가능합니다.";
			} else if (appliedDays < 0) {
				alertMessage = "승인일수는 0보다 작을 수 없습니다.";
			} else if (periodLimit && (appliedDays > periodLimit)) {
				alertMessage = "휴가는 연속해서 " + periodLimit + "일을 초과할 수 없습니다.";
			}

			if (alertMessage) {
				this.parentNode.previousElementSibling.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				if (cancelProcess)  params.applied_days = (appliedDays * -1).toString();
				else                params.applied_days = appliedDays.toString();

				var lastApprover = (signStep == approvalInfo.approval_step.toString());

				if (lastApprover) {
					params.canceled_id = approvalInfo.canceled_id.toString();

					// 입사 첫해에는 땡겨쓴 연차를 업데이트해준다.
					// 만1년 근무후 첫번째 회계연도시작일부터 연차가 부여되게 설정되었으면 2년차도 월차로 계산
					var updateLeaveCount = false;
					var timeoffYear  = null;
					var intEntryYear = parseInt(entryDates[0]);
					
					if (approvalInfo.timeoff_year == entryDates[0]) {
						if (leaveBasic == "over_one_year")  timeoffYear = "'" + approvalInfo.timeoff_year + "'";
						else                                timeoffYear = "'" + entryDates[0] + "','" + (intEntryYear + 1).toString() + "'";
					} else if ((leaveBasic == "over_one_year") && (parseInt(approvalInfo.timeoff_year) == parseInt(entryDates[0]) + 1)) {
						timeoffYear = "'" + entryDates[0] + "','" + (intEntryYear + 1).toString() + "'";
					}

					if (timeoffYear) {
						/*
						var availableCount = 12 - parseInt(entryDates[1], 10);
						if (entryDates[2] != "01")  availableCount -= 1;  // 1일 입사자가 아니면 첫달은 만근하지 못하므로...
						if (availableCount > 11)  availableCount = 11;
						params.available_count = availableCount.toString();
						*/

						params.timeoff_year = timeoffYear;
						params.user_id      = userId;
					}
				}

				if (params.sign_status == "rejected") {
					params.sign_step    = "-" + signStep;
					params.applied_days = "0";
					params.canceled_id  = approvalInfo.canceled_id.toString();
				}

				$jnode$.ajax.service({
					"url":      "/ajax/timeoff.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						var selectedRow = document.querySelector("aside.grid > div > table > tbody > tr.selected");
						var stepCell    = selectedRow.firstElementChild;

						if (waitingId == worker) {
							selectedRow.setAttribute("class", params.sign_status + " selected");
							stepCell.innerHTML = signStep + " (" + signStep + "/" + approvalInfo.approval_step + ")";
							document.querySelector("div.section > article > div.article > fieldset > button > div").innerHTML = "상세정보";
						} else {
							if (params.sign_status == "rejected") {
								selectedRow.setAttribute("class", "rejected selected");
								document.querySelector("div.section > article > div.article > fieldset > button > div").innerHTML = "상세정보";
							} else if (lastApprover) {
								selectedRow.setAttribute("class", "approved selected");
								document.querySelector("div.section > article > div.article > fieldset > button > div").innerHTML = "상세정보";
							}

							stepCell.innerHTML = signStep + "/" + approvalInfo.approval_step;
						}

						if (params.sign_status == "rejected") {
							stepCell.nextElementSibling.setAttribute("class", "rejected");
							if (cancelProcess)  stepCell.nextElementSibling.setAttribute("class", "rejected cancel");
							selectedRow.lastElementChild.innerHTML = "반려";

							selectedRow.querySelector("tr > td:nth-child(4)").innerHTML = selectedRow.querySelector("tr > td:nth-child(4)").innerHTML + "→0";
						} else if (lastApprover) {
							stepCell.nextElementSibling.setAttribute("class", "approved");
							if (cancelProcess)  stepCell.nextElementSibling.setAttribute("class", "approved cancel");
							selectedRow.lastElementChild.innerHTML = "승인";

							if (appliedDays != approvalInfo.request_days) {
								selectedRow.querySelector("tr > td:nth-child(4)").innerHTML = selectedRow.querySelector("tr > td:nth-child(4)").innerHTML + "→" + params.applied_days;
							}
						}

						if ($content$.timeoff.dataset.is_admin == false) {
							var timeoffMenu  = document.querySelector("body > nav > ul > li > label > input[value='/timeoff'] + span");
							var checkedCount = document.querySelectorAll("aside.grid > div > table > tbody > tr.unchecked").length;

							if (checkedCount == 0)  timeoffMenu.removeAttribute("class");
							else                    timeoffMenu.setAttribute("class", checkedCount);
						}

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);
	}
};