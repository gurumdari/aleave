$content$.outside.approval = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if (windowWidth > 736) {
			$controller$.grid.resize(null, windowHeight - 178);
		} else {
			$controller$.grid.removeHeight();
		}

		$controller$.grid.resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();

		var that         = this;
		var dataset      = this.dataset;
		var worker       = dataset.worker;

		$jnode$.pushHistory(this.conf);
		setWaitingCount(this.dataset.waiting_count);

		var curYear  = this.dataset.cur_year;
		var yearList = this.dataset.year_list;
		if (yearList.indexOf(curYear) < 0) {
			yearList.push(curYear);
			yearList = yearList.sort().reverse();
		}

		var yearSelect     = document.querySelector("body > section > div.section > article > div.article > ul > li:first-child > select");
		var approvalButton = document.querySelector("div.section > article > div.article > fieldset > button");

		approvalButton.disabled = true;

		for (var i = 0; i < yearList.length; i++) {
			yearSelect.add(new Option(yearList[i] + "년", yearList[i]));
		}

		$jnode$.requireController("grid", {caller:that.conf}).on(function() {
			$controller$.grid.service();

			var approvalTbody = document.querySelector("aside.grid > div > table > tbody");

			window.addEventListener("resize", that.resize, false);
			that.resize();

			function appendApprovalRow(approvalData) {
				var row = document.createElement("tr");
				row.setAttribute("id", approvalData.outside_id);
				approvalTbody.appendChild(row);

				var myStep = approvalData.approver_sort + 1;
				var stepStatus = approvalData.sign_status;

				if (approvalData.sign_step < 0) {
					stepStatus = "rejected";
				} else if ((approvalData.sign_status == "waiting") && (approvalData.sign_step == myStep - 1)) {
					stepStatus = "unchecked";
				}

				row.setAttribute("class", stepStatus);

				var stepCell = row.insertCell(0);
				stepCell.appendChild(document.createTextNode((approvalData.approver_sort + 1) + " (" + Math.abs(approvalData.sign_step) + "/" + approvalData.approval_step + ")"));

				var outsideType = null;
				var cancelValue = (approvalData.canceled_id > 0) ? " 취소 " : " ";

				if (approvalData.outside_starttime == "S") {
					if (approvalData.outside_endtime == "E") {
						outsideType = "외근" + cancelValue + "(종일)";
					} else {
						outsideType = "직출" + cancelValue + "(~ " + approvalData.outside_endtime + "시)";
					}
				} else if (approvalData.outside_endtime == "E") {
					outsideType = "직퇴" + cancelValue + "(" + approvalData.outside_starttime + "시 ~)";
				} else {
					outsideType = "외근" + cancelValue + "(" + approvalData.outside_starttime + "시 ~ " + approvalData.outside_endtime + "시)";
				}

				var nameSpan = document.createElement("span");
				nameSpan.appendChild(document.createTextNode(approvalData.user_name));

				var typeSpan = document.createElement("span");
				typeSpan.appendChild(document.createTextNode(outsideType));

				var typeCell = row.insertCell(1);
				typeCell.appendChild(nameSpan);
				typeCell.appendChild(document.createTextNode(" - "));
				typeCell.appendChild(typeSpan);

				var destinationCell = row.insertCell(2);
				destinationCell.appendChild(document.createTextNode(approvalData.destination));

				var periodValue = dateFormatter.format($module$.date.Utils.parse(approvalData.outside_startdate), dateFormatter.DateStyle.MEDIUM);

				if (approvalData.outside_startdate != approvalData.outside_enddate) {
					periodValue += " ~ " + dateFormatter.format($module$.date.Utils.parse(approvalData.outside_enddate), dateFormatter.DateStyle.MEDIUM);
				}

				var periodCell = row.insertCell(3);
				periodCell.appendChild(document.createTextNode(periodValue));

				var createCell = row.insertCell(4);
				createCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(approvalData.create_date), dateFormatter.DateStyle.MEDIUM)));

				var statusValue = "";
				if (approvalData.sign_step < 0) {
					statusValue = "반려";
					typeCell.setAttribute("class", "rejected");
				} else if (approvalData.approval_step > approvalData.sign_step) {
					statusValue = "대기";
					typeCell.setAttribute("class", "waiting");
				} else {
					statusValue = "승인";
					typeCell.setAttribute("class", "approved");
				}

				if (approvalData.canceled_id > 0) {
					$jnode$.node.addClass(typeCell, "cancel");

					destinationCell.setAttribute("class", "cancel");
					periodCell.setAttribute("class", "cancel");
				}

				var statusCell = row.insertCell(5);
				statusCell.appendChild(document.createTextNode(statusValue));

				row.addEventListener("click", function(event) {
					var selectedRow = approvalTbody.querySelector("tbody > tr.selected");
					if (selectedRow)  $jnode$.node.removeClass(selectedRow, "selected");

					$jnode$.node.addClass(this, "selected");

					approvalButton.disabled = false;

					if ($jnode$.node.hasClass(this, "unchecked")) {
						approvalButton.firstElementChild.innerHTML = "결재처리";
					} else {
						approvalButton.firstElementChild.innerHTML = "상세정보";
					}
				}, false);
			}

			function getApprovalList(year, userId) {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/outside.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  {
						command:     "getApprovalList",
						approver_id: worker,
						year:        year
					},
					"success": function(response) {
						$controller$.grid.clear("tbody");
						approvalButton.disabled = true;
						approvalButton.firstElementChild.innerHTML = "상세보기";

						for (var i = 0; i < response.approvalList.length; i++) {
							appendApprovalRow(response.approvalList[i]);
						}

						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}

			getApprovalList(yearSelect.value);

			yearSelect.addEventListener("change", function(event) {
				getApprovalList(this.value);
			}, false);

			approvalButton.addEventListener("click", function(event) {
				var selectedRow = approvalTbody.querySelector("tbody > tr.selected");
				var nodeId    = "/outside/approval/view";
				var winupName = "외근 상세정보";
				var height    = 417;

				if ($jnode$.node.hasClass(selectedRow, "unchecked")) {
					nodeId    = "/outside/approval/check";
					winupName = "외근 결재처리";
					height    = 482;
				}

				$jnode$.requireContent("winup", nodeId, {
					useLoading: true,
					icon:       true,
					title:      winupName,
					width:      480,
					height:     height,
					outside_id: selectedRow.getAttribute("id")
				});
			}, false);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};