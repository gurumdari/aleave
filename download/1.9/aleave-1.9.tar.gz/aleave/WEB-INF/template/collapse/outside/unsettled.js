$content$.outside.unsettled = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if (windowWidth > 736) {
			$controller$.grid.resize(null, windowHeight - 146);
		} else {
			$controller$.grid.removeHeight();
		}

		$controller$.grid.resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();

		var that          = this;
		var dataset       = this.dataset;
		var worker        = dataset.worker;
		var unsettledList = dataset.unsettledList;

		$jnode$.pushHistory(this.conf);

		var approvalButton = document.querySelector("div.section > article > div.article > fieldset > button");
		approvalButton.disabled = true;

		$jnode$.requireController("grid", {caller:that.conf}).on(function() {
			$controller$.grid.service();

			var unsettledTbody = document.querySelector("aside.grid > div > table > tbody");

			window.addEventListener("resize", that.resize, false);
			that.resize();

			function appendUnsettledRow(unsettledData) {
				var row = document.createElement("tr");
				row.setAttribute("id", unsettledData.outside_id);
				row.setAttribute("class", "waiting");
				unsettledTbody.appendChild(row);

				var stepCell = row.insertCell(0);
				stepCell.appendChild(document.createTextNode(Math.abs(unsettledData.sign_step) + "/" + unsettledData.approval_step));

				var outsideType = null;
				var cancelValue = (unsettledData.canceled_id > 0) ? " 취소 " : " ";

				if (unsettledData.outside_starttime == "S") {
					if (unsettledData.outside_endtime == "E") {
						outsideType = "외근" + cancelValue + "(종일)";
					} else {
						outsideType = "직출" + cancelValue + "(~ " + unsettledData.outside_endtime + "시)";
					}
				} else if (unsettledData.outside_endtime == "E") {
					outsideType = "직퇴" + cancelValue + "(" + unsettledData.outside_starttime + "시 ~)";
				} else {
					outsideType = "외근" + cancelValue + "(" + unsettledData.outside_starttime + "시 ~ " + unsettledData.outside_endtime + ")";
				}

				var nameSpan = document.createElement("span");
				nameSpan.appendChild(document.createTextNode(unsettledData.user_name));

				var typeSpan = document.createElement("span");
				typeSpan.appendChild(document.createTextNode(outsideType));

				var typeCell = row.insertCell(1);
				typeCell.appendChild(nameSpan);
				typeCell.appendChild(document.createTextNode(" - "));
				typeCell.appendChild(typeSpan);

				var destinationCell = row.insertCell(2);
				destinationCell.appendChild(document.createTextNode(unsettledData.destination));

				var periodValue = dateFormatter.format($module$.date.Utils.parse(unsettledData.outside_startdate), dateFormatter.DateStyle.MEDIUM);

				if (unsettledData.outside_startdate != unsettledData.outside_enddate) {
					periodValue += " ~ " + dateFormatter.format($module$.date.Utils.parse(unsettledData.outside_enddate), dateFormatter.DateStyle.MEDIUM);
				}

				var periodCell = row.insertCell(3);
				periodCell.appendChild(document.createTextNode(periodValue));

				var createCell = row.insertCell(4);
				createCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(unsettledData.create_date), dateFormatter.DateStyle.MEDIUM)));

				var statusValue = "";
				if (unsettledData.sign_step < 0) {
					statusValue = "반려";
					typeCell.setAttribute("class", "rejected");
				} else if (unsettledData.approval_step > unsettledData.sign_step) {
					statusValue = "대기";
					typeCell.setAttribute("class", "waiting");
				} else {
					statusValue = "승인";
					typeCell.setAttribute("class", "approved");
				}

				if (unsettledData.canceled_id > 0) {
					$jnode$.node.addClass(typeCell, "cancel");
					typeCell.appendChild(document.createTextNode(" 취소"));

					periodCell.setAttribute("class", "cancel");
				}

				var statusCell = row.insertCell(5);
				statusCell.appendChild(document.createTextNode(statusValue));

				row.addEventListener("click", function(event) {
					var selectedRow = unsettledTbody.querySelector("tbody > tr.selected");
					if (selectedRow)  $jnode$.node.removeClass(selectedRow, "selected");

					$jnode$.node.addClass(this, "selected");

					approvalButton.disabled = false;

					if ($jnode$.node.hasClass(this, "waiting")) {
						approvalButton.firstElementChild.innerHTML = "결재처리";
					} else {
						approvalButton.firstElementChild.innerHTML = "상세정보";
					}
				}, false);
			}

			for (var i = 0; i < unsettledList.length; i++) {
				appendUnsettledRow(unsettledList[i]);
			}

			$controller$.loading.hide();

			approvalButton.addEventListener("click", function(event) {
				var selectedRow = unsettledTbody.querySelector("tbody > tr.selected");
				var nodeId    = "/outside/approval/view";
				var winupName = "외근 상세정보";
				var height    = 417;

				if ($jnode$.node.hasClass(selectedRow, "waiting")) {
					nodeId    = "/outside/approval/check";
					winupName = "외근 결재처리";
					height    = 482;
				}

				$jnode$.requireContent("winup", nodeId, {
					useLoading: true,
					icon:       true,
					title:      winupName,
					width:      480,
					height:     height,
					outside_id: selectedRow.getAttribute("id")
				});
			}, false);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};