$content$.outside.my.request = {
	resize: function() {
		var popupContentDiv = document.querySelector("aside.popup > ul > li > div");

		var windowWidth = window.innerWidth;

		if (popupContentDiv.getAttribute("class") == "calendar_area") {
			if (windowWidth > 736) {
				$controller$.popup.resize(246, 236);
			} else {
				$controller$.popup.resize(280, 325);
			}
		} else {
			if (windowWidth > 400) {
				$controller$.popup.resize(360, 330);
			} else {
				$controller$.popup.widthP(100);
			}
		}
	},

	setApprovalLine: function(approverList, lineId) {
		var worker = $content$.outside.my.request.dataset.worker;
		var lineContainer = document.querySelector("aside.winup article > div.winup > form > div > ul");
		lineContainer.innerHTML = "";

		if (lineId == null) {
			lineId = approverList[0].line_id;
			if (lineId)  lineContainer.setAttribute("id", lineId);
			else         lineContainer.setAttribute("id", "0");

			for (var i = 0; i < approverList.length; i++) {
				var approverId   = approverList[i].approver_id;
				var approverName = (worker == approverId) ? "본인" : approverList[i].approver_name + " (" + approverList[i].position_name + ")";

				var li = document.createElement("li");
				li.setAttribute("id", approverList[i].approver_id);
				li.appendChild(document.createTextNode((i + 1) + "단계: " + approverName + " @ " + approverList[i].org_name));
				lineContainer.appendChild(li);
			}
		} else {
			lineContainer.setAttribute("id", lineId);
			lineContainer.innerHTML = approverList;
		}
	},

	service: function() {
		var worker   = this.dataset.worker;
		var today    = new Date();
		var isoToday = $module$.date.Utils.format(today);

		var periodTd  = document.outsideForm.querySelector("form > table.form > tbody > tr > td.period");
		var startLink = periodTd.firstElementChild;
		var endLink   = periodTd.lastElementChild;

		window.addEventListener("resize", this.resize, false);

		this.setApprovalLine(this.dataset.approvalLineList[0]);

		function dateSelectEvent(dateLink) {
			var windowWidth  = window.innerWidth;
			var popupDomain  = $jnode$.controller.getDomain("popup");
			var popupContent = popupDomain.querySelector($jnode$.selector.controller.popup.content);
			popupContent.innerHTML = "<DIV class=\"calendar\"><DIV></DIV><UL class=\"submit\"><LI></LI><LI><BUTTON class=\"caution\">확인</BUTTON></LI></UL></DIV>";

			popupDomain.querySelector("aside.popup > ul > li > div").setAttribute("class", "calendar_area");

			$controller$.popup.open({
				width:  (windowWidth > 736 ? 246 : 280),
				height: (windowWidth > 736 ? 236 : 325)
			});

			var date     = null;
			var isoValue = dateLink.getAttribute("value");

			if (isoValue) {
				date = $module$.date.Utils.parse(isoValue);
			} else {
				var startValue = startLink.getAttribute("value");
				var endValue   = endLink.getAttribute("value");
				
				if      (startValue)  isoValue = startValue;
				else if (endValue  )  isoValue = endValue;

				if (isoValue) {
					date = $module$.date.Utils.parse(isoValue);
				} else {
					date = new Date();
					isoValue = $module$.date.Utils.format(date);
				}
			}

			var dateCalendar = popupDomain.querySelector("aside.popup article > div.calendar > div");
			var dateLi       = dateCalendar.nextElementSibling.firstElementChild;

			dateLi.innerHTML = $jnode$.escapeXML(dateFormatter.format(date, dateFormatter.DateStyle.LONG));
			dateLi.setAttribute("value", "iso:" + isoValue);

			displayCalendar(date, dateLi, dateCalendar, isoValue);

			dateLi.addEventListener("click", function() {
				var selectedIsoValue = this.getAttribute("value").substring(4);
				displayCalendar(selectedIsoValue, this, dateCalendar, selectedIsoValue);
			}, false);

			dateLi.nextElementSibling.firstElementChild.addEventListener("click", function(event) {
				var selectedIsoValue = dateLi.getAttribute("value").substring(4);
				dateLink.setAttribute("value", selectedIsoValue);
				dateLink.innerHTML = dateFormatter.format($module$.date.Utils.parse(selectedIsoValue), dateFormatter.DateStyle.MEDIUM);

				$controller$.popup.close();
			}, false);
		}

		startLink.addEventListener("click", function(event) {
			dateSelectEvent(this);
		}, false);

		endLink.addEventListener("click", function(event) {
			dateSelectEvent(this);
		}, false);

		var outsideComment = document.outsideForm.outside_comment;

		outsideComment.addEventListener("keydown", function(event) {
			var keyCode = event.keyCode || event.which;

			if(keyCode == 13) {
				event.preventDefault();
			}
		}, false);

		outsideComment.addEventListener("paste", function(event) {
			window.setTimeout(function() {
				outsideComment.value = outsideComment.value.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");
			});
		}, false);

		var lineSelectButton = document.outsideForm.querySelector("form > table.form > tbody > tr > th > button");
		lineSelectButton.addEventListener("click", function(event) {
			document.querySelector("aside.popup > ul > li > div").removeAttribute("class");

			var windowWidth = window.innerWidth;
			var options = {
				useLoading:     true,
				height:          330,
				line_id:         document.outsideForm.querySelector("form > div > ul").getAttribute("id"),
				setApprovalLine: $content$.outside.my.request.setApprovalLine
			};

			if (windowWidth > 400)  options.width = 360;
			else                    options.widthP = 100;

			$jnode$.requireContent("popup", "/approval/line", options);
		}, false);

		document.outsideForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var lineContainer = document.querySelector("aside.winup article > div.winup > form > div > ul");
			var approverIds   = [];
			var alertMessage  = "";

			for (var i = 0; i < lineContainer.children.length; i++) {
				approverIds.push(lineContainer.children[i].getAttribute("id"));
			}

			var params = {
				command:           "addOutside",
				user_id:           worker,
				destination:       document.outsideForm.destination.value.trim(),
				outside_comment:   outsideComment.value.trim(),
				sign_step:         "0",
				approval_step:     approverIds.length.toString(),
				user_contact:      document.outsideForm.user_contact.value.trim(),
				approver_ids:      JSON.stringify(approverIds),
				outside_starttime: document.outsideForm.outside_starttime.value,
				outside_endtime:   document.outsideForm.outside_endtime.value
			};

			var outsideStartdate = startLink.getAttribute("value");
			var outsideEnddate   = endLink.getAttribute("value");

			if (outsideStartdate == null) {
				alertMessage = "";
			} else if (outsideEnddate == null) {
				alertMessage = "외근 끝나는 날짜를 선택해주세요.";
			} else if (outsideStartdate > outsideEnddate) {
				alertMessage = "끝나는 날짜가 시작 날짜보다 빠를 수 없습니다.";
			} else if (params.outside_starttime >= params.outside_endtime) {
				alertMessage = "외근 시작 시간은 종료 시간보다 빨라야 합니다.";
			} else if (params.destination == "") {
				alertMessage = "외근장소를 입력해주세요.";
				document.outsideForm.destination.select();
			} else if (approverIds.length == 0) {
				alertMessage = "결재 라인 단계가 없습니다. 결재 라인을 선택해주세요.";
				lineSelectButton.focus();
			}

			if (alertMessage) {
				this.parentNode.previousElementSibling.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				if (params.outside_starttime == "-") {
					params.outside_starttime = "S"
				}

				params.outside_year = parseInt(outsideStartdate.split("-")[0], 10).toString();

				params.outside_startdate = outsideStartdate;
				params.outside_enddate   = outsideEnddate;

				if (approverIds[0] == worker)  params.sign_step = "1";

				$jnode$.ajax.service({
					"url":      "/ajax/outside.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						var yearSelect  = document.querySelector("body > section > div.section > article > div.article > ul > li:first-child > select");
						var workingYear = yearSelect.value;
						var yearList    = Array.apply(null, yearSelect.options).map(function(el) { return el.value; });

						// 연도별 휴가 처리현황에 해당 연도가 없으면 연도를 새로 만들어준다.
						if (yearList.indexOf(params.outside_year) < 0) {
							yearList.push(params.outside_year);
							yearList = yearList.sort().reverse();

							var yearSubfix = yearSelect.options[0].text.substring(4);
							yearSelect.innerHTML = "";

							for (var i = 0; i < yearList.length; i++) {
								yearSelect.add(new Option(yearList[i] + yearSubfix, yearList[i]));
							}
						}

						// 작업중인 연도랑 같으면 생성된 휴가/결근만 리스트에 추가하고, 그렇지 않으면 생성한 연도의 리스트로 이동한다.
						if (workingYear == params.outside_year) {
							params.outside_id  = response.outside_id;
							params.create_date = response.create_date;

							var outsideTbody = document.querySelector("aside.grid > div > table > tbody");
							$content$.outside.my.appendOutsideRow(outsideTbody, params, true).click();
						} else {
							yearSelect.value = params.outside_year;
							$content$.outside.my.getOutsideList(params.outside_year, response.outside_id);
						}

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
		document.querySelector("aside.popup > ul > li > div").removeAttribute("class");
	}
}