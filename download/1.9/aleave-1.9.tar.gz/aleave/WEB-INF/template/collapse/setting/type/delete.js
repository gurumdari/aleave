$content$.setting.type.delete = {
	service: function() {
		var positionTypeContainer = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div.pos_type");
		var positionContainer     = document.querySelector("div.section > article > div.article > ul > li:last-child > div.pos");
		var selectedInput         = positionTypeContainer.querySelector("div.pos_type > label > input:checked");
		var selectedSpan          = selectedInput.nextElementSibling;
		var replacedTbody         = document.typeForm.querySelector("form > div > table > tbody");
		var posTypeList           = this.dataset.positionTypeList;
		var posTypeMap            = {};
		var typeId                = selectedInput.value;
		var clickedId             = 0;
		var typeCount             = posTypeList.length;

		document.typeForm.querySelector("form > table > tbody > tr:nth-child(2) > td:last-child").innerHTML = selectedSpan.innerHTML;

		for (var i = 0; i < typeCount; i++) {
			posTypeMap[posTypeList[i].type_id.toString()] = posTypeList[i].list;

			if (posTypeList[i].type_id.toString() == typeId) {
				if (i == typeCount - 1)  clickedId = posTypeList[i - 1].type_id;
				else                     clickedId = posTypeList[i + 1].type_id;
			}
		}

		function changePosList(posType, positionSelect) {
			var posList = posTypeMap[posType];

			positionSelect.innerHTML = "";
			for (var i = 0; i < posList.length; i++) {
				positionSelect.add(new Option(posList[i].position_name, posList[i].position_id));
			}
		}

		var deletedPositions = posTypeMap[typeId];
		for (var i = 0; i < deletedPositions.length; i++) {
			var row = replacedTbody.insertRow(i);

			var th = document.createElement("th");
			th.appendChild(document.createTextNode(deletedPositions[i].position_name));
			row.appendChild(th);

			var td = document.createElement("td");
			row.appendChild(td);

			var ul = document.createElement("ul");
			td.appendChild(ul);

			var typeLi = document.createElement("li");
			typeLi.setAttribute("class", "select");
			ul.appendChild(typeLi);
			
			var typeSelect = document.createElement("select");
			typeSelect.setAttribute("name", "type_" + deletedPositions[i].position_id);
			typeLi.appendChild(typeSelect);

			var posLi = document.createElement("li");
			posLi.setAttribute("class", "select");
			ul.appendChild(posLi);
			
			var posSelect = document.createElement("select");
			posSelect.setAttribute("name", "pos_" + deletedPositions[i].position_id);
			posLi.appendChild(posSelect);

			for (var j = 0; j < typeCount; j++) {
				if (typeId != posTypeList[j].type_id) {
					typeSelect.add(new Option(posTypeList[j].type_name, posTypeList[j].type_id));
				}
			}

			typeSelect.value = clickedId;

			typeSelect.addEventListener("change", function(event) {
				changePosList(this.value, this.parentNode.nextElementSibling.firstElementChild);
			}, false);

			changePosList(typeSelect.value, posSelect);
		}

		document.typeForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			$controller$.prompt.confirm("삭제될 직급 타입에 포함된 직급을 가진 해당 사용자는 대체 직급으로 변경됩니다. 정말로 선택한 직급 타입을 삭제하겠습니까?", function(close) {
				$controller$.loading.show();

				var replacedPositions = [];
				var positionSelects = document.typeForm.querySelectorAll("form > div > table > tbody > tr > td > ul > li:last-child > select");
				for (var i = 0; i < positionSelects.length; i++) {
					replacedPositions.push({
						position_id: positionSelects[i].getAttribute("name").substring(4),
						new_id:      positionSelects[i].value
					});
				}
				
				var params = {
					command:            "deletePositionType",
					type_id:            typeId,
					replaced_positions: JSON.stringify(replacedPositions)
				};

				$jnode$.ajax.service({
					"url":      "/ajax/position.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params": params,
					"success": function(response) {
						positionTypeContainer.removeChild(selectedInput.parentNode);
						positionTypeContainer.querySelector("div.pos_type > label > input[value='" + clickedId + "']").click();

						$controller$.loading.hide();
						$controller$.winup.close();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});

				close();
			});
		}, false);
	}
};