$content$.setting.account = {
	service: function() {
		var that      = this;
		var userInfo  = this.dataset.userInfo;

		$jnode$.pushHistory(that.conf);

		if (!this.dataset.readonly) {
			if (userInfo.level_id != "9") {
				var orgNameInput = document.userForm.org_name;

				if (userInfo.level_id == "1") {
					orgNameInput.addEventListener("click", function(event) {
						$jnode$.requireContent("winup", "/setting/org/select", {
							useLoading: true,
							icon:       true,
							title:      "부서 선택",
							width:      420,
							height:     268,
							renderer:   "-j"
						});
					}, false);
				} else {
					orgNameInput.addEventListener("click", function(event) {
						$controller$.prompt.alert("부서장으로 설정된 사용자는 본인이 직접 부서를 변경할 수 없습니다.", null, true);
					}, false);
				}
			}

			var birthday = document.userForm.user_birthday;

			if (birthday) {
				function drawCalendar(buttonTitle, isoValue) {
					var date         = null;
					var windowWidth  = window.innerWidth;
					var popupDomain  = $jnode$.controller.getDomain("popup");
					var popupContent = popupDomain.querySelector($jnode$.selector.controller.popup.content);
					popupContent.innerHTML = "<DIV class=\"calendar\"><DIV></DIV><UL class=\"submit\"><LI></LI><LI><BUTTON class=\"caution\">" + buttonTitle + "</BUTTON></LI></UL></DIV>";

					$controller$.popup.open({
						width:  (windowWidth > 736 ? 246 : 280),
						height: (windowWidth > 736 ? 236 : 325)
					});

					if (isoValue) {
						date = $module$.date.Utils.parse(isoValue);
					} else {
						date = new Date();
						isoValue = $module$.date.Utils.format(date);
					}

					var dateCalendar = popupDomain.querySelector("aside.popup article > div.calendar > div");
					var dateLi       = dateCalendar.nextElementSibling.firstElementChild;

					dateLi.innerHTML = $jnode$.escapeXML(dateFormatter.format(date, dateFormatter.DateStyle.LONG));
					dateLi.setAttribute("value", "iso:" + isoValue);

					displayCalendar(date, dateLi, dateCalendar, isoValue);

					dateLi.addEventListener("click", function() {
						var selectedIsoValue = this.getAttribute("value").substring(4);
						displayCalendar(selectedIsoValue, this, dateCalendar, selectedIsoValue);
					}, false);

					return dateLi;
				}

				function dateSelectEvent(dateInput) {
					var inputContainer = dateInput.parentNode;
					var isoValue       = inputContainer.getAttribute("value");

					if (isoValue == "") {
						isoValue = $module$.date.Utils.format($module$.date.Utils.toYear(-30));
					}

					var dateLi = drawCalendar("확인", isoValue);

					dateLi.nextElementSibling.firstElementChild.addEventListener("click", function(event) {
						var selectedIsoValue = dateLi.getAttribute("value").substring(4);
						inputContainer.setAttribute("value", selectedIsoValue);
						inputContainer.firstElementChild.value = dateFormatter.format($module$.date.Utils.parse(selectedIsoValue), dateFormatter.DateStyle.LONG);
		
						$controller$.popup.close();
					}, false);
				}

				birthday.addEventListener("click", function(event) {
					dateSelectEvent(this);
				}, false);
			}

			var addressText = document.userForm.user_address;

			if (addressText) {
				addressText.addEventListener("keydown", function(event) {
					var keyCode = event.keyCode || event.which;

					if(keyCode == 13) {
						event.preventDefault();
					}
				}, false);

				addressText.addEventListener("paste", function(event) {
					window.setTimeout(function() {
						addressText.value = addressText.value.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");
					});
				}, false);
			}

			document.querySelector("div.section > article > div.article > fieldset > ul.submit > li:last-child > button:first-child").addEventListener("click", function(event) {
				var alertDiv = this.parentNode.previousElementSibling.firstElementChild;

				var params = {
					command:   "updateUser",
					user_name: document.userForm.user_name.value.trim(),
					user_id:   document.userForm.user_id.value,
				};

				if (userInfo.level_id == "9") {
					params.user_note     = document.userForm.user_note.value.trim();
					params.user_birthday = "";
				} else {
					params.user_birthday = document.userForm.user_birthday.parentNode.getAttribute("value");
					params.user_contact  = document.userForm.user_contact.value.trim();
					params.user_address  = document.userForm.user_address.value.trim();

					params.update_org = "true";
					params.org_id   = document.userForm.org_id.value;
					params.org_name = document.userForm.org_name.value;

					var positionSelect = document.userForm.position_id;
					params.position_id   = positionSelect.value,
					params.position_name = positionSelect.options[positionSelect.selectedIndex].text
				}

				var alertMessage = null;

				if (params.user_name == "") {
					alertMessage = "사용자 이름을 입력해주세요.";
					document.userForm.user_name.select();
				} else if (userInfo.level_id != "9") {
					/*
					if (params.user_birthday == "") {
						alertMessage = "생년월일을 선택해주세요.";
					} else if (params.user_address == "") {
						alertMessage = "주소를 입력해주세요.";
						document.userForm.user_address.select();
					}
					*/
				}

				if (alertMessage) {
					document.querySelector("body > section > div.section > article > div.article").setAttribute("class", "article space");
					alertDiv.setAttribute("class", "alert");
					alertDiv.innerHTML = alertMessage;
				} else {
					$controller$.loading.show();
					document.querySelector("body > section > div.section > article > div.article").setAttribute("class", "article");
					alertDiv.removeAttribute("class");
					alertDiv.innerHTML = "";

					$jnode$.ajax.service({
						"url":      "/ajax/user.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":  params,
						"success": function(response) {
							document.querySelector("body > header > ul > li:last-child > ul > li > button.account").firstChild.nodeValue = params.user_name;
							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			}, false);
		}

		document.querySelector("div.section > article > div.article > fieldset > ul.submit > li:last-child > button:last-child").addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/user/password_change", {
				useLoading: true,
				icon:       true,
				title:      "비밀번호 변경",
				width:      420,
				height:     225
			});
		}, false);
	}
};