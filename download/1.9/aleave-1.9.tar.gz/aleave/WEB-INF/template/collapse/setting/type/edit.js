$content$.setting.type.edit = {
	service: function() {
		var positionTypeContainer = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div.pos_type");
		var selectedInput         = positionTypeContainer.querySelector("div.pos_type > label > input:checked");
		var selectedSpan          = selectedInput.nextElementSibling;
		var typeId                = selectedInput.value;

		document.typeForm.type_name.value = selectedSpan.firstChild.nodeValue;

		document.typeForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var params = {
				command:   "updatePositionType",
				type_id:   typeId,
				type_name: document.typeForm.type_name.value.trim()
			}

			if (params.type_name) {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/position.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params": params,
					"success": function(response) {
						selectedSpan.firstChild.nodeValue = params.type_name;

						$controller$.loading.hide();
						$controller$.winup.close();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			} else {
				this.parentNode.previousElementSibling.innerHTML = "직급 타입을 입력해주세요.";
				document.typeForm.type_name.select();
			}
		}, false);
	}
};