$content$.setting.system = {
	service: function() {
		$jnode$.pushHistory(this.conf);

		if (document.settingForm.init_position_type.value != this.dataset.systemInfo.init_position_type) {
			document.settingForm.init_position_type.selectedIndex = document.settingForm.init_position_type.options.length - 1;
		}

		var leaveBasicDateTd       = document.querySelector("body > section > div.section > article > div.article > form > table.form > tbody > tr.leave > td");
		var leaveBasicDateInputs   = leaveBasicDateTd.querySelectorAll("td > ul.group2 > li > label > input");
		var leaveBasicDateSubDiv   = leaveBasicDateTd.lastElementChild;
		var mailNotificationTd     = document.settingForm.querySelector("form > table.form > tbody > tr.mail_notification > td");
		var mailNotificationInputs = mailNotificationTd.querySelectorAll("td > ul.group2 > li > label > input");
		var mailNotificationSubDiv = mailNotificationTd.lastElementChild;
		var passwordRevealButton   = mailNotificationTd.querySelector("td > ul.group2 + div > table > tbody > tr > td > ul > li:last-child > button");

		leaveBasicDateInputs[0].addEventListener("click", function(event) {
			leaveBasicDateSubDiv.setAttribute("class", "entry");
		}, false);

		leaveBasicDateInputs[1].addEventListener("click", function(event) {
			leaveBasicDateSubDiv.setAttribute("class", "fiscal");
		}, false);

		mailNotificationInputs[0].addEventListener("click", function(event) {
			mailNotificationSubDiv.setAttribute("class", "true");
		}, false);

		mailNotificationInputs[1].addEventListener("click", function(event) {
			mailNotificationSubDiv.setAttribute("class", "false");
		}, false);

		passwordRevealButton.addEventListener("click", function(event) {
			if (this.getAttribute("class") == "revealed") {
				this.removeAttribute("class");
				document.settingForm.smtp_password.setAttribute("type", "password");
			} else {
				this.setAttribute("class", "revealed");
				document.settingForm.smtp_password.setAttribute("type", "text");
			}
		}, false);

		document.querySelector("article > div.article > fieldset > ul.submit > li > button").addEventListener("click", function(event) {
			var alertDiv     = this.parentNode.previousElementSibling.firstElementChild;
			var alertMessage = null;
			var params = $jnode$.toJSON(document.settingForm);
			params.command     = "updateSystemSettings"
			params.mail_sender = params.mail_sender.trim();
			params.smtp_host   = params.smtp_host  .trim();
			params.smtp_port   = params.smtp_port  .trim();
			params.smtp_user   = params.smtp_user  .trim();

			if (params.mail_notification == "true") {
				if (params.mail_sender == "") {
					alertMessage = "보내는 메일주소를 입력해주세요.";
					document.settingForm.mail_sender.select();
				} else if (params.mail_sender.search(/^(([^<>()\[\]\\.,;:\s@*"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/) < 0) {
					alertMessage = "보내는 메일주소가 유효하지 않습니다.";
					document.settingForm.mail_sender.select();
				} else if (params.smtp_host == "") {
					alertMessage = "SMTP host를 입력해주세요.";
					document.settingForm.smtp_host.select();
				} else if (params.smtp_port == "") {
					alertMessage = "SMTP port를 입력해주세요.";
					document.settingForm.smtp_port.select();
				} else if (params.smtp_user == "") {
					alertMessage = "SMTP user를 입력해주세요.";
					document.settingForm.smtp_user.select();
				} else if (params.smtp_password == "") {
					alertMessage = "SMTP password를 입력해주세요.";
					document.settingForm.smtp_password.focus();
				}
			}

			if (alertMessage) {
				document.querySelector("body > section > div.section > article > div.article").setAttribute("class", "article space");
				alertDiv.setAttribute("class", "alert");
				alertDiv.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				passwordRevealButton.removeAttribute("class");
				document.settingForm.smtp_password.setAttribute("type", "password");

				document.querySelector("body > section > div.section > article > div.article").setAttribute("class", "article");
				alertDiv.removeAttribute("class");
				alertDiv.innerHTML = "";

				$jnode$.ajax.service({
					"url":      "/ajax/setting.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						if ($jnode$.node.theme != params.theme) {
							$jnode$.node.setTheme(params.theme);
						}

						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);
	}
};