$content$.setting.personal = {
	service: function() {
		$jnode$.pushHistory(this.conf);

		document.querySelector("article > div.article > fieldset > ul.submit > li > button").addEventListener("click", function(event) {
			var alertDiv     = this.parentNode.previousElementSibling.firstElementChild;
			var alertMessage = null;
			var params = $jnode$.toJSON(document.settingForm);

			if (params.enabled) {
				params.email = params.email.trim();

				if (params.enabled != "N") {
					if (params.email == "") {
						alertMessage = "수신받을 메일주소를 입력해주세요.";
						document.settingForm.email.select();
					}
				}
			}

			if (alertMessage) {
				document.querySelector("body > section > div.section > article > div.article").setAttribute("class", "article space");
				alertDiv.setAttribute("class", "alert");
				alertDiv.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				document.querySelector("body > section > div.section > article > div.article").setAttribute("class", "article");
				alertDiv.removeAttribute("class");
				alertDiv.innerHTML = "";

				$jnode$.ajax.service({
					"url":      "/ajax/setting.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						if ($jnode$.node.theme != params.theme) {
							$jnode$.node.setTheme(params.theme);
						}

						document.settingForm.command.value = "updatePersonalSettings";
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);
	}
};