$content$.setting.pdf.template.status = {
	service: function() {
		var pdfType = this.dataset.pdf_type;

		document.statusForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			$controller$.loading.show();

			var params = {
				command:  "updatePdfStatus",
				status:   document.statusForm.status.value,
				pdf_type: pdfType
			};

			$jnode$.ajax.service({
				"url":      "/ajax/pdf/template.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params":  params,
				"success": function(response) {
					$content$.setting.pdf.template.properties.status = params.status;
					$content$.setting.pdf.template.showNotification();

					$controller$.winup.close();
					$controller$.loading.hide();
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}, false);
	}
};