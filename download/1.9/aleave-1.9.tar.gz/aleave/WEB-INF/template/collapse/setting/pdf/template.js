$content$.setting.pdf.template = {
	properties: {
		status:     0,
		manager_id: ""
	},

	showNotification: function() {
		var statusButton  = document.querySelector("div.section > article > div.article > fieldset > ul.submit > li:last-child > button:first-child");
		var managerButton = statusButton.nextElementSibling;
		var statusDiv     = statusButton.parentNode.previousElementSibling.firstElementChild;

		if (this.properties.status == 1) {
			statusButton.setAttribute("class", "popup");

			if (this.properties.manager_id || (managerButton.getAttribute("id") == "hidden")) {
				managerButton.setAttribute("class", "popup");

				statusDiv.setAttribute("class", "notification");
				statusDiv.innerHTML = "미리보기는 저장된 데이터로 보여 줍니다."
			} else {
				managerButton.setAttribute("class", "popup caution");

				statusDiv.setAttribute("class", "notification alert");
				statusDiv.innerHTML = "처리 담당자가 설정되어 있지 않습니다."
			}
		} else {
			statusButton .setAttribute("class", "popup caution");
			managerButton.setAttribute("class", "popup");

			statusDiv.setAttribute("class", "notification alert");
			statusDiv.innerHTML = document.querySelector("div.section > article > div.article > ul > li:first-child > div:first-child").innerHTML + " PDF 템플릿이 " + (this.properties.status == 0 ? "비활성화" : "사용안함으로 ") + "되어 있습니다.";
		}
	},

	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		var pdfEditor = document.querySelector("div.section > article > div.article > ul > li:last-child > div.pdf_template > div.pdftemplate > article > div.selected");

		if (pdfEditor.getAttribute("id") == "xhtml") {
			var notificationDiv = pdfEditor.firstElementChild;
			var xhtmlTextarea   = notificationDiv.nextElementSibling.firstElementChild;
			var textareaHeight  = windowHeight - notificationDiv.offsetHeight;

			if (windowWidth > 736) {
				textareaHeight -= 255;
			} else if (windowWidth > 640) {
				textareaHeight -= 337;
			} else {
				textareaHeight -= 357;
			}

			if (textareaHeight < 135)  textareaHeight = 135;

			xhtmlTextarea.style.height = textareaHeight + "px";
		} else {
			var pageContainer        = pdfEditor.firstElementChild;
			var imageSettingFieldset = pageContainer.nextElementSibling;

			if (pdfEditor.getAttribute("id") == "sign") {
				imageSettingFieldset = pageContainer.nextElementSibling.lastElementChild.firstElementChild;
			}

			var containerHeight = windowHeight - imageSettingFieldset.offsetHeight;

			if (windowWidth > 736) {
				containerHeight -= 247;
			} else if (windowWidth > 640) {
				containerHeight -= 329;
			} else {
				containerHeight -= 349;
			}

			if (containerHeight < 75)  containerHeight = 75;

			pageContainer.firstElementChild.style.height = (containerHeight + 2) + "px";
			pageContainer.firstElementChild.firstElementChild.style.height = (containerHeight > 348 ? 348 : containerHeight) + "px";
		}
	},

	service: function() {
		$jnode$.pushHistory(this.conf);

		window.addEventListener("resize", this.resize, false);
		this.resize();

		var that    = this;
		var pdfType = this.dataset.pdf_type;

		this.properties.status     = this.dataset.status;
		this.properties.manager_id = this.dataset.manager_id;

		var managerButton   = document.querySelector("div.section > article > div.article > fieldset > ul.submit > li:last-child > button:nth-child(2)");
		var pdfTabContainer = document.querySelector("div.section > article > div.article > ul > li:last-child > div.pdf_template > div.pdftemplate > ul");
		var xhtmlTab = pdfTabContainer.querySelector("ul > li > label > input[value='xhtml']");
		var stampTab = pdfTabContainer.querySelector("ul > li > label > input[value='stamp']");
		var signTab  = pdfTabContainer.querySelector("ul > li > label > input[value='sign']");
		var logoTab  = pdfTabContainer.querySelector("ul > li > label > input[value='logo']");

		var pdfEditorContainer = document.querySelector("div.section > article > div.article > ul > li:last-child > div.pdf_template > div.pdftemplate > article");
		var xhtmlEditor = pdfEditorContainer.querySelector("article > div#xhtml");
		var stampEditor = pdfEditorContainer.querySelector("article > div#stamp");
		var signEditor  = pdfEditorContainer.querySelector("article > div#sign");
		var logoEditor  = pdfEditorContainer.querySelector("article > div#logo");

		xhtmlTab.addEventListener("click", function(event) {
			xhtmlEditor.setAttribute("class", "selected");
			stampEditor.removeAttribute("class");
			signEditor.removeAttribute("class");
			logoEditor.removeAttribute("class");
			that.resize();
		}, false);

		if (stampTab) {
			stampTab.addEventListener("click", function(event) {
				xhtmlEditor.removeAttribute("class");
				stampEditor.setAttribute("class", "selected");
				signEditor.removeAttribute("class");
				logoEditor.removeAttribute("class");
				that.resize();
			}, false);

			managerButton.removeAttribute("id");
		} else {
			managerButton.setAttribute("id", "hidden");
		}

		if (signTab) {
			signTab.addEventListener("click", function(event) {
				xhtmlEditor.removeAttribute("class");
				stampEditor.removeAttribute("class");
				signEditor.setAttribute("class", "selected");
				logoEditor.removeAttribute("class");
				that.resize();

				if (this.getAttribute("class") == null) {
					$jnode$.requireControllers(["dataframe", "winup#dataframe"], {caller:that.conf}, function() {
						// 서명
						var signPageDiv     = signEditor.querySelector("div#sign > ul.page > li > div > table > tbody > tr:nth-child(2) > td:last-child > div");
						var signUseInput    = signEditor.querySelector("div#sign input[name='sign_use']");
						var signWidthInput  = signEditor.querySelector("div#sign input[name='sign_width']");
						var signHeightInput = signEditor.querySelector("div#sign input[name='sign_height']");

						function resizeSign() {
							if (signUseInput.checked) {
								signPageDiv.removeAttribute("class");
								var signImgs = signPageDiv.children;

								for (var i = 0; i < signImgs.length; i++) {
									signImgs[i].style.width  = signWidthInput.value + "px";
									signImgs[i].style.height = signHeightInput.value + "px";
								}
							} else {
								signPageDiv.setAttribute("class", "hide");
							}
						}

						function reappendSign() {
							var signVector = $controller$.dataframe.getRowVector();
							signPageDiv.innerHTML = "";

							for (var i = 0; i < signVector.length; i++) {
								var signLeft   = parseFloat(signVector[i][0]);
								var signBottom = parseFloat(signVector[i][1]);

								if (!(isNaN(signLeft) || isNaN(signBottom))) {
									var signImg = document.createElement("img");
									signImg.setAttribute("src", "pdf/sign.png");
									signImg.style.width  = signWidthInput.value + "px";
									signImg.style.height = signHeightInput.value + "px";
									signImg.style.left   = signVector[i][0] + "px";
									signImg.style.bottom = signVector[i][1] + "px";
									signPageDiv.appendChild(signImg);
								}
							}
						}

						signUseInput   .addEventListener("change", resizeSign, false);
						signWidthInput .addEventListener("change", resizeSign, false);
						signHeightInput.addEventListener("change", resizeSign, false);

						$controller$.dataframe.service({
							names: [ "X축", "Y축" ],
							cellWidths: [ 60, 60 ],
							height: 119,
							fixedLayout: true,
							blurCell: reappendSign
						});

						var signList   = that.dataset.sign_list;
						var signVector = [];

						for (var i = 0; i < signList.length; i++) {
							signVector.push([
								signList[i].sign_x,
								signList[i].sign_y
							]);
						}

						$controller$.dataframe.setRowVector(signVector);
						reappendSign();
					});

					this.setAttribute("class", "serviced");
				}
			}, false);
		}

		logoTab.addEventListener("click", function(event) {
			xhtmlEditor.removeAttribute("class");
			stampEditor.removeAttribute("class");
			signEditor.removeAttribute("class");
			logoEditor.setAttribute("class", "selected");
			that.resize();
		}, false);

		// 상태 설명
		that.showNotification();

		// 직인
		var stampImage       = that.dataset.stamp_image;
		var stampPageDiv     = stampEditor.querySelector("div#stamp > ul.page > li > div > table > tbody > tr:nth-child(2) > td:last-child > div");
		var stampUseInput    = stampEditor.querySelector("div#stamp input[name='stamp_use']");
		var stampWidthInput  = stampEditor.querySelector("div#stamp input[name='stamp_width']");
		var stampHeightInput = stampEditor.querySelector("div#stamp input[name='stamp_height']");
		var stampXInput      = stampEditor.querySelector("div#stamp input[name='stamp_x']");
		var stampYInput      = stampEditor.querySelector("div#stamp input[name='stamp_y']");

		stampPageDiv.setAttribute("value", stampImage);

		function reflectStamp() {
			if (stampUseInput.checked) {
				stampPageDiv.style.backgroundImage    = "url('pdf/" + stampPageDiv.getAttribute("value") +  "')";
				stampPageDiv.style.backgroundRepeat   = "no-repeat";
				stampPageDiv.style.backgroundPosition = stampXInput.value + "px " + (297 - stampYInput.value - stampHeightInput.value) + "px";
				stampPageDiv.style.backgroundSize     = stampWidthInput.value + "px " + stampHeightInput.value + "px";
			} else {
				stampPageDiv.removeAttribute("style");
			}
		}

		stampUseInput   .addEventListener("change", reflectStamp, false);
		stampWidthInput .addEventListener("change", reflectStamp, false);
		stampHeightInput.addEventListener("change", reflectStamp, false);
		stampXInput     .addEventListener("change", reflectStamp, false);
		stampYInput     .addEventListener("change", reflectStamp, false);

		reflectStamp();

		// 로고
		var logoImage       = that.dataset.logo_image;
		var logoPageDiv     = logoEditor.querySelector("div#logo > ul.page > li > div > table > tbody > tr:nth-child(2) > td:last-child > div");
		var logoUseInput    = logoEditor.querySelector("div#logo input[name='logo_use']");
		var logoWidthInput  = logoEditor.querySelector("div#logo input[name='logo_width']");
		var logoHeightInput = logoEditor.querySelector("div#logo input[name='logo_height']");
		var logoXInput      = logoEditor.querySelector("div#logo input[name='logo_x']");
		var logoYInput      = logoEditor.querySelector("div#logo input[name='logo_y']");

		logoPageDiv.setAttribute("value", logoImage);

		function reflectLogo() {
			if (logoUseInput.checked) {
				logoPageDiv.style.backgroundImage    = "url('pdf/" + logoPageDiv.getAttribute("value") +  "')";
				logoPageDiv.style.backgroundRepeat   = "no-repeat";
				logoPageDiv.style.backgroundPosition = logoXInput.value + "px " + (297 - logoYInput.value - logoHeightInput.value) + "px";
				logoPageDiv.style.backgroundSize     = logoWidthInput.value + "px " + logoHeightInput.value + "px";
			} else {
				logoPageDiv.removeAttribute("style");
			}
		}

		logoUseInput   .addEventListener("change", reflectLogo, false);
		logoWidthInput .addEventListener("change", reflectLogo, false);
		logoHeightInput.addEventListener("change", reflectLogo, false);
		logoXInput     .addEventListener("change", reflectLogo, false);
		logoYInput     .addEventListener("change", reflectLogo, false);

		reflectLogo();

		xhtmlEditor.querySelector("div#xhtml > ul.submit > li:first-child > button").addEventListener("click", function(event) {
			$controller$.prompt.alert("준비중...", null, true);
		}, false);

		stampEditor.querySelector("div#stamp > ul.submit > li:first-child > button").addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/pdf/template/image", {
				icon:       true,
				title:      "직인 이미지 변경",
				width:      420,
				height:     114,
				pdf_type:   pdfType,
				image_type: "stamp"
			});
		}, false);

		logoEditor.querySelector("div#logo > ul.submit > li:first-child > button").addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/pdf/template/image", {
				icon:       true,
				title:      "로고 이미지 변경",
				width:      420,
				height:     114,
				pdf_type:   pdfType,
				image_type: "logo"
			});
		}, false);

		function saveTemplate() {
			var params = {
				command:      "updatePdfTemplate",
				pdf_type:     pdfType,
				xhtml:        pdfEditorContainer.querySelector("article > div#xhtml > div.textarea > textarea").value.trim(),
				stamp_use:    pdfEditorContainer.querySelector("article > div#stamp input[name='stamp_use']").checked ? "Y" : "N",
				stamp_width:  parseFloat(pdfEditorContainer.querySelector("article > div#stamp input[name='stamp_width']").value),
				stamp_height: parseFloat(pdfEditorContainer.querySelector("article > div#stamp input[name='stamp_height']").value),
				stamp_x:      parseFloat(pdfEditorContainer.querySelector("article > div#stamp input[name='stamp_x']").value),
				stamp_y:      parseFloat(pdfEditorContainer.querySelector("article > div#stamp input[name='stamp_y']").value),
				sign_use:     pdfEditorContainer.querySelector("article > div#sign input[name='sign_use']").checked ? "Y" : "N",
				sign_width:   parseFloat(pdfEditorContainer.querySelector("article > div#sign input[name='sign_width']").value),
				sign_height:  parseFloat(pdfEditorContainer.querySelector("article > div#sign input[name='sign_height']").value),
				logo_use:     pdfEditorContainer.querySelector("article > div#logo input[name='logo_use']").checked ? "Y" : "N",
				logo_width:   parseFloat(pdfEditorContainer.querySelector("article > div#logo input[name='logo_width']").value),
				logo_height:  parseFloat(pdfEditorContainer.querySelector("article > div#logo input[name='logo_height']").value),
				logo_x:       parseFloat(pdfEditorContainer.querySelector("article > div#logo input[name='logo_x']").value),
				logo_y:       parseFloat(pdfEditorContainer.querySelector("article > div#logo input[name='logo_y']").value),
			}

			var validateSignList = true;

			if (signTab && signTab.getAttribute("class") == "serviced") {
				var newVector  = [];
				var signVector = $controller$.dataframe.getRowVector();
				var signList   = [];

				for (var i = 0; i < signVector.length; i++) {
					var signX = parseFloat(signVector[i][0]);
					var signY = parseFloat(signVector[i][1]);

					if (!(isNaN(signX) || isNaN(signY))) {
						signList.push({
							sign_x: signX,
							sign_y: signY
						});

						newVector.push([signX, signY]);
					}
				}

				$controller$.dataframe.clear();
				$controller$.dataframe.setRowVector(newVector);

				params.sign_list = JSON.stringify(signList);

				if (signList.length < 2) {
					validateSignList = false;
				}
			}

			if (validateSignList) {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/pdf/template.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			} else {
				$controller$.prompt.alert("서명 이미지는 최소 2개 이상 지정되어야 합니다.", null, true);
				signTab.click();
			}
		}

		var saveButtons = pdfEditorContainer.querySelectorAll("article > div ul.submit > li:last-child > button:last-child");

		for (var i = 0; i < saveButtons.length; i++) {
			saveButtons[i].addEventListener("click", saveTemplate, false);
		}
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};