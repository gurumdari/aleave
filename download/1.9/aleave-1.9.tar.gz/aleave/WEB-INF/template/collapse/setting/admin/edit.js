$content$.setting.admin.edit = {
	service: function() {
		var worker        = this.dataset.worker;
		var userNameInput = document.userForm.user_name;
		var userNodeInput = document.userForm.user_note;
		var okButton      = document.userForm.querySelector("form > ul.submit > li > button:first-child");
		var deleteButton  = okButton.nextElementSibling;

		var userTbody    = document.querySelector("aside.grid > div > table > tbody");
		var userRow      = userTbody.querySelector("tbody > tr.selected");
		var userNameCell = userRow.firstElementChild;
		var userIdCell   = userNameCell.nextElementSibling;
		var userNoteCell = userIdCell.nextElementSibling.nextElementSibling;

		// user_name
		userNameInput.value = userNameCell.textContent;

		// user_id
		var userId = userIdCell.textContent;
		userNameInput.parentNode.parentNode.nextElementSibling.lastElementChild.innerHTML = $jnode$.escapeXML(userId);

		// user_note
		userNodeInput.value = userNoteCell.textContent;

		if (this.dataset.worker == userId)  deleteButton.disabled = true;

		// 관리자 정보 변경
		okButton.addEventListener("click", function(event) {
			var alertMessage = null;
			var alertNode    = this.parentNode.previousElementSibling;

			var params = {
				command:   "updateUser",
				user_name: userNameInput.value.trim(),
				user_id:   userId,
				user_note: userNodeInput.value.trim()
			};

			if (params.user_name == "") {
				alertMessage = "관리자 이름을 입력해주세요.";
				userNameInput.select();
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						userNameCell.firstChild.nodeValue = params.user_name;
						userNoteCell.firstChild.nodeValue = params.user_note;

						if (params.user_id == worker) {
							document.querySelector("body > header > ul > li:last-child > ul > li > button.account").firstChild.nodeValue = params.user_name;
						}

						$controller$.grid.clear("thead");

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		// 관리자 삭제
		deleteButton.addEventListener("click", function(event) {
			$controller$.prompt.confirm("정말로 관리자 계정을 삭제하겠습니까?", function(close) {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  {
						command: "deleteUser",
						user_id: userId
					},
					"success": function(response) {
						userTbody.removeChild(userRow);
						document.querySelector("div.section > article > div.article > fieldset > button:nth-child(2)").disabled = true;
						document.querySelector("div.section > article > div.article > fieldset > button:last-child").disabled   = true;

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});

				close();
			}, null, 2);
		}, false);
	}
};