$content$.setting.position["delete"] = {
	service: function() {
		var typeInput         = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div.pos_type > label > input:checked");
		var positionContainer = document.querySelector("div.section > article > div.article > ul > li:last-child > div.pos");
		var selectedInput     = positionContainer.querySelector("div.pos > label > input:checked");
		var selectedSpan      = selectedInput.nextElementSibling;
		var positionId        = selectedInput.value;
		var newIdSelect       = document.positionForm.new_id;
		var positionInputs    = positionContainer.querySelectorAll("div.pos > label > input");
		var positionCount     = positionInputs.length;
		var selectedIndex     = 0;

		document.positionForm.querySelector("form > table > tbody > tr:first-child > td:last-child").innerHTML = selectedSpan.innerHTML;

		for (var i = 0; i < positionCount; i++) {
			if (positionId == positionInputs[i].value) {
				selectedIndex = i;
			} else {
				newIdSelect.add(new Option(positionInputs[i].nextElementSibling.firstChild.nodeValue, positionInputs[i].value));
			}
		}

		if (selectedIndex == positionCount - 1)  selectedIndex -= 1;

		newIdSelect.selectedIndex = selectedIndex;

		document.positionForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			$controller$.prompt.confirm("삭제될 직급을 가진 해당 사용자는 대체 직급으로 변경됩니다. 정말로 선택한 직급을 삭제하겠습니까?", function(close) {
				$controller$.loading.show();

				var params = {
					command:       "deletePosition",
					position_type: typeInput.value,
					position_id:   positionId,
					new_id:        newIdSelect.value
				};

				$jnode$.ajax.service({
					"url":      "/ajax/position.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params": params,
					"success": function(response) {
						positionContainer.removeChild(selectedInput.parentNode);
						positionContainer.querySelector("div.pos > label > input[value='" + params.new_id + "']").click();

						$controller$.loading.hide();
						$controller$.winup.close();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});

				close();
			});
		}, false);
	}
};