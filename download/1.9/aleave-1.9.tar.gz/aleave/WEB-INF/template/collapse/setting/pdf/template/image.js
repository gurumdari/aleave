$content$.setting.pdf.template.image = {
	service: function() {
		var imageType = this.dataset.image_type;

		document.imageForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var formData  = new FormData(document.imageForm);
			var fileName  = formData.get("upload_file").name;
			var fileIndex = fileName.lastIndexOf(".");

			if (fileIndex < 0 || [".png", ".gif", ".jpeg", ".jpg", ".jpe"].indexOf(fileName.substring(fileIndex).toLowerCase()) < 0) {
				this.parentNode.previousElementSibling.innerHTML = "이미지 파일을 선택해주세요.";
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/pdf/image_upload.json",
					"method":   "POST",
					"datatype": "json",
					"headers":  {
						"Accept": "application/json"
					},
					"params":  formData,
					"success": function(response) {
						var imagePageDiv  = document.querySelector("div.section > article > div.article > ul > li:last-child > div.pdf_template > div.pdftemplate > article > div[id='" + imageType + "'] > ul.page > li > div > table > tbody > tr:nth-child(2) > td:last-child > div");
						var imageUseInput = document.querySelector("div.section > article > div.article > ul > li:last-child > div.pdf_template > div.pdftemplate > article > div[id='" + imageType + "'] input[name='" + imageType + "_use']");
						var imageFile     = response.image_file + "?t=" + new Date().getTime();

						imagePageDiv.setAttribute("value", imageFile);

						if (imageUseInput.checked) {
							imagePageDiv.style.backgroundImage    = "url('pdf/" + imageFile +  "')";
						}

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);
	}
};