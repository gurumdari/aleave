document.querySelector("body > header > ul > li:last-child > ul > li > form > button.logout").addEventListener("click", function(event) {
	$controller$.loading.show();
	document.logoutForm.submit();
}, false);

var leaveBasicDateTd     = document.querySelector("body > section > div.section > article > div.article > form > div > div > table.form > tbody > tr:last-child > td");
var leaveBasicDateInputs = leaveBasicDateTd.querySelectorAll("td > ul.group2 > li > label > input");
var leaveBasicDateSubDiv = leaveBasicDateTd.lastElementChild;

leaveBasicDateInputs[0].addEventListener("click", function(event) {
	leaveBasicDateSubDiv.setAttribute("class", "entry");
}, false);

leaveBasicDateInputs[1].addEventListener("click", function(event) {
	leaveBasicDateSubDiv.setAttribute("class", "fiscal");
}, false);

document.querySelector("body > section > div.section > article > div.article > form > fieldset > ul.submit > li:last-child > button").addEventListener("click", function(event) {
	var alertDiv     = this.parentNode.previousElementSibling.firstElementChild;
	var alertMessage = "";
	var userName     = document.registForm.user_name.value.trim();
	var userId       = document.registForm.user_id.value.trim();

	if (userName == "") {
		alertMessage = "\uad00\ub9ac\uc790 \uc774\ub984\uc744 \uc785\ub825\ud574 \uc8fc\uc138\uc694.";  // 관리자 이름을 입력해 주세요.
		document.registForm.user_name.select();
	} else if (userId == "") {
		alertMessage = "\uad00\ub9ac\uc790 ID\ub97c \uc785\ub825\ud574 \uc8fc\uc138\uc694.";  // 관리자 ID를 입력해 주세요.
		document.registForm.user_id.select();
	} else if (userId == "-") {
		alertMessage = "\uad00\ub9ac\uc790 ID\ub294 \"-\"\uc77c \uc218 \uc5c6\uc2b5\ub2c8\ub2e4.";  // 관리자 ID는 \"-\"일 수 없습니다.
		document.registForm.user_id.select();
	} else if (!/^[\w|\.|\-]+$/g.test(document.registForm.user_id.value)) {
		alertMessage = "\uad00\ub9ac\uc790 ID\uc758 \ubb38\uc790\uc5f4\uc740 \uc601\ubb38, \uc22b\uc790, \ubc11\uc904(_), \ud558\uc774\ud508(-), \uc810(.)\ub9cc \uac00\ub2a5\ud569\ub2c8\ub2e4.";  // 관리자 ID의 문자열은 영문, 숫자, 밑줄(_), 하이픈(-), 점(.)만 가능합니다.
		document.registForm.user_id.select();
	} else if (userId.length > 30) {
		alertMessage = "\uad00\ub9ac\uc790 ID\ub294 \ucd5c\ub300 30\uc790\uae4c\uc9c0\ub9cc \uac00\ub2a5\ud569\ub2c8\ub2e4.";  // 관리자 ID는 최대 30자까지만 가능합니다.
		document.registForm.user_id.select();
	} else if (document.registForm.user_password.value == "") {
		alertMessage = "\ube44\ubc00\ubc88\ud638\ub97c \uc785\ub825\ud574 \uc8fc\uc138\uc694.";  // 비밀번호를 입력해 주세요.
		document.registForm.user_password.focus();
	} else if (document.registForm.user_password.value != document.registForm.confirm_password.value) {
		alertMessage = "\ube44\ubc00\ubc88\ud638\uc640 \ube44\ubc00\ubc88\ud638 \ud655\uc778\uc758 \uac12\uc774 \ub2e4\ub985\ub2c8\ub2e4.";  // 비밀번호와 비밀번호 확인의 값이 다릅니다.
		document.registForm.confirm_password.select();
	} else if (document.registForm.company_name.value.trim() == "") {
		alertMessage = "\ud68c\uc0ac\uba85\uc744 \uc785\ub825\ud574 \uc8fc\uc138\uc694.";  // 회사명을 입력해 주세요.
		document.registForm.company_name.select();
	}

	if (alertMessage) {
		document.querySelector("body > section > div.section > article > div.article > form").setAttribute("class", "space");
		alertDiv.setAttribute("class", "alert");
		alertDiv.innerHTML = alertMessage;
	} else {
		$controller$.loading.show();

		document.registForm.user_name.value    = userName;
		document.registForm.user_id.value      = userId;
		document.registForm.user_note.value    = document.registForm.user_note.value.trim();
		document.registForm.company_name.value = document.registForm.company_name.value.trim();

		document.registForm.submit();
	}
}, false);

document.registForm.user_name.focus();