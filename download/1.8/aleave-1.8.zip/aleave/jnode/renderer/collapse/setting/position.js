$content$.setting.position = {
	typeShiftableEventHandler: null,
	positionShiftableEventHandler: null,
	appendPosition: function(positionContainer, positionData, selectedLabel) {
		var label = document.createElement("label");

		var input = document.createElement("input");
		input.setAttribute("type", "radio");
		input.setAttribute("name", "position_id");
		input.setAttribute("value", positionData.position_id);

		var span = document.createElement("span");
		span.appendChild(document.createTextNode(positionData.position_name));

		label.appendChild(input);
		label.appendChild(span);

		input.addEventListener("click", function(event) {
			var positionAddButton      = document.querySelector("div.section > article > div.article > fieldset > button:first-child");
			var positionEditButton     = positionAddButton.nextElementSibling;
			var positionDeleteButton   = positionEditButton.nextElementSibling;
			var positionSortButton     = positionDeleteButton.nextElementSibling;

			positionAddButton.disabled  = false;
			positionEditButton.disabled = false;

			// 삭제 버튼과 정렬 버튼은 2개이상의 직급이 있어야 활성화
			if (positionContainer.querySelectorAll("div > label > input").length < 2) {
				positionDeleteButton.disabled = true;
				positionSortButton.disabled   = true;

				if (positionContainer.getAttribute("class") == "pos shiftable") {
					positionContainer.setAttribute("class", "pos");
					positionSortButton.setAttribute("class", "led off");
					$content$.setting.position.positionShiftableEventHandler.removeShiftableEvent();
				}
			} else {
				positionDeleteButton.disabled = false;
				positionSortButton.disabled   = false;
			}
		}, false);

		if (selectedLabel) {
			if (positionData.where_to == "previous") {
				positionContainer.insertBefore(label, selectedLabel);
			} else {
				positionContainer.insertBefore(label, selectedLabel.nextElementSibling);
			}
		} else {
			positionContainer.appendChild(label);
		}
	},

	appendPositionType: function(positionTypeContainer, positionContainer, typeData, selectedLabel) {
		var label = document.createElement("label");

		var input = document.createElement("input");
		input.setAttribute("type", "radio");
		input.setAttribute("name", "position_type");
		input.setAttribute("value", typeData.type_id);

		var span = document.createElement("span");
		span.appendChild(document.createTextNode(typeData.type_name));

		label.appendChild(input);
		label.appendChild(span);

		input.addEventListener("click", function(event) {
			$controller$.loading.show();

			var positionType = this.value;
			document.querySelector("div.section > article > div.article > ul > li:first-child > div:first-child").innerHTML = this.nextElementSibling.innerHTML;

			var typeAddButton        = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div:last-child > ul > li:first-child > button:first-child");
			var typeEditButton       = typeAddButton.nextElementSibling;
			var typeDeleteButton     = typeEditButton.nextElementSibling;
			var typeSortButton       = typeDeleteButton.nextElementSibling;
			var positionAddButton    = document.querySelector("div.section > article > div.article > fieldset > button:first-child");
			var positionEditButton   = positionAddButton.nextElementSibling;
			var positionDeleteButton = positionEditButton.nextElementSibling;
			var positionSortButton   = positionDeleteButton.nextElementSibling;

			typeAddButton.disabled        = false;
			typeEditButton.disabled       = false;
			typeDeleteButton.disabled     = false;
			positionAddButton.disabled    = true;
			positionEditButton.disabled   = true;
			positionDeleteButton.disabled = true;

			// 삭제 버튼과 정렬 버튼은 2개이상의 타입이 있어야 활성화
			if (positionTypeContainer.querySelectorAll("div > label > input").length < 2) {
				typeDeleteButton.disabled = true;
				typeSortButton.disabled   = true;

				if (positionTypeContainer.parentNode.getAttribute("class") == "shiftable") {
					positionTypeContainer.parentNode.removeAttribute("class");
					typeSortButton.setAttribute("class", "led off");
					$content$.setting.position.typeShiftableEventHandler.removeShiftableEvent();
				}
			} else {
				typeDeleteButton.disabled = false;
				typeSortButton.disabled   = false;
			}

			$jnode$.ajax.service({
				"url":      "/ajax/position.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params": {
					command:       "getPositionList",
					position_type: positionType
				},
				"success": function(response) {
					positionContainer.innerHTML = "";

					for (var i = 0; i < response.length; i++) {
						$content$.setting.position.appendPosition(positionContainer, response[i]);
					}

					if (response.length < 2) {
						positionSortButton.disabled = true;
					} else {
						positionSortButton.disabled = false;
					}

					$controller$.loading.hide();
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});

			var tumbtrackButton = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div:last-child > ul > li:last-child > button:first-child");
			if (tumbtrackButton.getAttribute("class") == null)  tumbtrackButton.nextElementSibling.click();
		}, false);

		if (selectedLabel) {
			if (typeData.where_to == "previous") {
				positionTypeContainer.insertBefore(label, selectedLabel);
			} else {
				positionTypeContainer.insertBefore(label, selectedLabel.nextElementSibling);
			}
		} else {
			positionTypeContainer.appendChild(label);
		}
	},

	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;
		var posTypeDiv   = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div.pos_type");
		var posDiv       = document.querySelector("div.section > article > div.article > ul > li:last-child > div.pos");

		if (windowWidth > 736) {
			posDiv.style.height = (windowHeight - 173) + "px";
			posTypeDiv.style.height = (windowHeight - 205) + "px";
		} else {
			posDiv.removeAttribute("style");
			posTypeDiv.style.height = (windowHeight - 56) + "px";
		}
	},

	service: function() {
		$controller$.loading.show();

		var that = this;
		var positionTypeList = this.dataset.positionTypeList;
		$jnode$.pushHistory(this.conf);

		var positionTypeContainer  = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div.pos_type");
		var positionContainer      = document.querySelector("div.section > article > div.article > ul > li:last-child > div.pos");
		var tumbtrackButton        = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div:last-child > ul > li:last-child > button:first-child");
		var posTypeCloseButton     = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div:last-child > ul > li:last-child > button:last-child");
		var typeAddButton          = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div:last-child > ul > li:first-child > button:first-child");
		var typeEditButton         = typeAddButton.nextElementSibling;
		var typeDeleteButton       = typeEditButton.nextElementSibling;
		var typeSortButton         = typeDeleteButton.nextElementSibling;
		var positionAddButton      = document.querySelector("div.section > article > div.article > fieldset > button:first-child");
		var positionEditButton     = positionAddButton.nextElementSibling;
		var positionDeleteButton   = positionEditButton.nextElementSibling;
		var positionSortButton     = positionDeleteButton.nextElementSibling;
		var historyPosTypeCallback = null;
		var isPhone                = ($jnode$.device.type == "phone");

		typeAddButton.disabled        = true;
		typeEditButton.disabled       = true;
		typeDeleteButton.disabled     = true;
		typeSortButton.disabled       = true;
		positionAddButton.disabled    = true;
		positionEditButton.disabled   = true;
		positionDeleteButton.disabled = true;
		positionSortButton.disabled   = true;

		window.addEventListener("resize", that.resize, false);
		that.resize();

		for (var i = 0; i < positionTypeList.length; i++) {
			this.appendPositionType(positionTypeContainer, positionContainer, positionTypeList[i]);
		}

		positionTypeContainer.firstElementChild.firstElementChild.click();

		// 직급 타입 추가
		typeAddButton.addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/type/add", {
				useLoading: true,
				icon:       true,
				title:      "\uc9c1\uae09 \ud0c0\uc785 \ucd94\uac00",  // 직급 타입 추가
				width:      400,
				height:     377,
				renderer:   "-j",
			});
		}, false);

		// 직급 타입 편집
		typeEditButton.addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/type/edit", {
				useLoading: true,
				icon:       true,
				title:      "\uc9c1\uae09 \ud0c0\uc785 \ud3b8\uc9d1",  // 직급 타입 편집
				width:      400,
				height:     118,
				renderer:   "-j",
			});
		}, false);

		// 직급 타입 삭제
		typeDeleteButton.addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/type/delete", {
				useLoading: true,
				icon:       true,
				title:      "\uc9c1\uae09 \ud0c0\uc785 \uc0ad\uc81c",  // 직급 타입 삭제
				width:      400,
				height:     346
			});
		}, false);

		// 직급 추가
		positionAddButton.addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/position/add", {
				useLoading: true,
				icon:       true,
				title:      "\uc9c1\uae09 \ucd94\uac00",  // 직급 추가
				width:      400,
				height:     149,
				renderer:   "-j",
			});
		}, false);

		// 직급 편집
		positionEditButton.addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/position/edit", {
				useLoading: true,
				icon:       true,
				title:      "\uc9c1\uae09 \ud3b8\uc9d1",  // 직급 편집
				width:      400,
				height:     118,
				renderer:   "-j"
			});
		}, false);

		// 직급 삭제
		positionDeleteButton.addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/position/delete", {
				useLoading: true,
				icon:       true,
				title:      "\uc9c1\uae09 \uc0ad\uc81c",  // 직급 삭제
				width:      400,
				height:     149,
				renderer:   "-j"
			});
		}, false);

		// 폰에서 직급유형 선택 팝업창을 띄우는 작업
		document.querySelector("div.section > article > div.article > ul > li:first-child > div:first-child").addEventListener("click", function(event) {
			if (isPhone) {
				document.body.style.overflow = "hidden";

				historyPosTypeCallback = $jnode$.node.pushPseudoHistory(function() {
					posTypeCloseButton.click();
				});
			}

			this.nextElementSibling.setAttribute("class", "popup");
		}, false);

		posTypeCloseButton.addEventListener("click", function(event) {
			if (isPhone) {
				document.body.style.removeProperty("overflow");
				if (historyPosTypeCallback)  historyPosTypeCallback();
			}

			this.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
		}, false);

		tumbtrackButton.addEventListener("click", function(event) {
			if (this.getAttribute("class") == "on")  this.removeAttribute("class");
			else                                     this.setAttribute("class", "on");
		}, false);

		$jnode$.requireModule("tap", that.conf).on(function() {
			var typeCheckedValue    = null;
			var postionCheckedValue = null;

			that.typeShiftableEventHandler = new $module$.tap.ShiftableEventHandler(positionTypeContainer, "div > label", function(prevIndex, currIndex) {
				if (isPhone)  document.body.style.removeProperty("overflow");

				if (typeCheckedValue)  positionTypeContainer.querySelector("div > label > input[value='" + typeCheckedValue + "']").checked = true;

				if (prevIndex > -1 && currIndex > -1 && prevIndex != currIndex) {
					$controller$.loading.show();

					var typeIds = [];
					var typeInputs = positionTypeContainer.querySelectorAll("div > label > input");
					for (var i = 0; i < typeInputs.length; i++) {
						typeIds.push(parseInt(typeInputs[i].value, 10));
					}

					$jnode$.ajax.service({
						"url":      "/ajax/position.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":   {
							"command": "sortPositionType",
							"type_id": JSON.stringify(typeIds)
						},
						"success": function(response) {
							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			}, function() {
				if (isPhone)  document.body.style.overflow = "hidden";

				typeCheckedValue = null;
				var checkedInput = positionTypeContainer.querySelector("div > label > input:checked");
				if (checkedInput)  typeCheckedValue = checkedInput.value;
			}, {
				style: "background-color: #FEEFB9;",
				scrollableNode: positionTypeContainer
			});

			that.positionShiftableEventHandler = new $module$.tap.ShiftableEventHandler(positionContainer, "div > label", function(prevIndex, currIndex) {
				if (isPhone)  document.body.style.removeProperty("overflow");

				if (postionCheckedValue)  positionContainer.querySelector("div > label > input[value='" + postionCheckedValue + "']").checked = true;

				if (prevIndex > -1 && currIndex > -1 && prevIndex != currIndex) {
					$controller$.loading.show();

					var positionIds = [];
					var positionInputs = positionContainer.querySelectorAll("div > label > input");
					for (var i = 0; i < positionInputs.length; i++) {
						positionIds.push(parseInt(positionInputs[i].value, 10));
					}

					$jnode$.ajax.service({
						"url":      "/ajax/position.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":   {
							"command":     "sortPosition",
							"position_id": JSON.stringify(positionIds)
						},
						"success": function(response) {
							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			}, function() {
				if (isPhone)  document.body.style.overflow = "hidden";

				postionCheckedValue = null;
				var checkedInput = positionContainer.querySelector("div > label > input:checked");
				if (checkedInput)  postionCheckedValue = checkedInput.value;
			},
			{
				style: "background-color: #FEEFB9;",
				scrollableNode: positionContainer
			});

			if ($jnode$.device.type == "desktop") {
				typeSortButton.style.display = "none";
				positionSortButton.style.display = "none";
				that.typeShiftableEventHandler.addShiftableEvent();
				that.positionShiftableEventHandler.addShiftableEvent();
			} else {
				typeSortButton.addEventListener("click", function(event) {
					if (positionTypeContainer.parentNode.getAttribute("class") == "shiftable") {
						positionTypeContainer.parentNode.removeAttribute("class");
						this.setAttribute("class", "led off");
						that.typeShiftableEventHandler.removeShiftableEvent();
					} else {
						positionTypeContainer.parentNode.setAttribute("class", "shiftable");
						this.setAttribute("class", "led green");
						that.typeShiftableEventHandler.addShiftableEvent();
					}
				}, false);

				positionSortButton.addEventListener("click", function(event) {
					if (positionContainer.getAttribute("class") == "pos shiftable") {
						positionContainer.setAttribute("class", "pos");
						this.setAttribute("class", "led off");
						that.positionShiftableEventHandler.removeShiftableEvent();
					} else {
						positionContainer.setAttribute("class", "pos shiftable");
						this.setAttribute("class", "led green");
						that.positionShiftableEventHandler.addShiftableEvent();
					}
				}, false);
			}
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};