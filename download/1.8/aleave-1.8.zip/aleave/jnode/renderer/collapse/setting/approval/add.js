$content$.setting.approval.add = {
	resize: function() {
		var windowWidth = window.innerWidth;

		if (windowWidth > 400) {
			$controller$.popup.resize(360, 300);
		} else {
			$controller$.popup.widthP(100);
		}
	},

	service: function() {
		var worker = this.dataset.worker;
		var approverInputs = document.approvalForm.querySelectorAll("form > table > tbody > tr > td > input.popup");
		var lineContainer  = document.querySelector("div.section > article > div.article > div.subtitle + div.content:nth-child(4)");

		document.querySelector("aside.popup > ul > li > div").removeAttribute("class");

		var windowWidth  = window.innerWidth;
		var options = {
			open:       false,
			useLoading: true,
			height:     300
		};
		
		if (windowWidth > 400)  options.width = 360;
		else                    options.widthP = 100;

		$jnode$.requireContent("popup", "/user/select", options);

		function approverClickEvent(approverInput) {
			approverInput.addEventListener("click", function(event) {
				$content$.user.select.dataset.input_name = this.getAttribute("name");

				var userDiv = document.querySelector("aside.popup article > div.popup > ul:last-child > li:first-child > div");
				var selectedUser = document.querySelector("aside.tree.org ul > li:last-child > span.checked");
				if (selectedUser)  selectedUser.removeAttribute("class");

				var userId = this.parentNode.getAttribute("id");
				if (userId) {
					userDiv.setAttribute("id", userId);
					userDiv.innerHTML = $jnode$.escapeXML(this.value);
				} else {
					userDiv.removeAttribute("id");
					userDiv.innerHTML = "";
				}

				$controller$.popup.open();
			}, false);
		}

		for (var i = 0; i < approverInputs.length; i++) {
			approverClickEvent(approverInputs[i]);
		}

		document.querySelector("aside.winup div.winup > form > ul.submit > li > button").addEventListener("click", function(event) {
			var alertMessage = null;
			var alertNode    = this.parentNode.previousElementSibling;
			var approverIds  = [];

			for (var i = 0; i < approverInputs.length; i++) {
				var approverId = approverInputs[i].parentNode.getAttribute("id");
				if (approverId)  approverIds.push(approverId);
			}

			var params = {
				command:      "addApprovalLine",
				line_name:    document.approvalForm.line_name.value.trim(),
				user_id:      worker,
				approver_ids: approverIds.join(",")
			};

			if (params.line_name == "") {
				alertMessage = "\uacb0\uc7ac\ub77c\uc778 \uc774\ub984\uc744 \uc785\ub825\ud574\uc8fc\uc138\uc694.";  // 결재라인 이름을 입력해주세요.
				document.approvalForm.line_name.focus();
			} else if (approverIds.length < 1) {
				alertMessage = "\uacb0\uc7ac\ub77c\uc778 \uad6c\uc131\uc740 \ud558\ub098 \uc774\uc0c1\uc5b4\uc57c \ud569\ub2c8\ub2e4.";  // 결재라인 구성은 하나 이상어야 합니다.
			} else if (approverIds[approverIds.length - 1] == worker) {
				alertMessage = "\ubcf8\uc778\uc740 \uacb0\uc7ac\ub77c\uc778 \uad6c\uc131\uc5d0\uc11c \uc81c\uc77c \ub9c8\uc9c0\ub9c9\ub2e8\uacc4\uc5d0\ub294 \uc62c \uc218 \uc5c6\uc2b5\ub2c8\ub2e4.";  // 본인은 결재라인 구성에서 제일 마지막단계에는 올 수 없습니다.
			} else if (approverIds.indexOf(worker) > 0) {
				alertMessage = "\ubcf8\uc778\uc740 \uacb0\uc7ac\ub77c\uc778 \uad6c\uc131\uc5d0\uc11c \uc81c\uc77c \ucc98\uc74c\ub2e8\uacc4\uc5d0\ub9cc \uc62c \uc218 \uc788\uc2b5\ub2c8\ub2e4.";  // 본인은 결재라인 구성에서 제일 처음단계에만 올 수 있습니다.
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/line.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						$content$.setting.approval.appendApprovalLine(lineContainer, response, worker, true);
						lineContainer.scrollTop = 0;
						window.scrollTo(0, 0);

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}

		}, false);

		document.approvalForm.line_name.focus();
		window.addEventListener("resize", this.resize, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};