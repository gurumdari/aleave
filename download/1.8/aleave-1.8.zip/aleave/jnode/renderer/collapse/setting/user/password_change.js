$content$.setting.user.password_change = {
	service: function() {
		var alertNode = document.passwordForm.querySelector("form > ul.submit > li.alert");

		document.passwordForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var params = {
				command:       "changePassword",
				user_id:       document.userForm.user_id.value,
				user_password: document.passwordForm.user_password.value,
				new_password:  document.passwordForm.new_password.value.trim()
			};

			var confirmPassword = document.passwordForm.confirm_password.value;
			var alertMessage    = null;

			if (params.user_password == "") {
				alertMessage = "\uae30\uc874 \ube44\ubc00\ubc88\ud638\ub97c \uc785\ub825\ud574 \uc8fc\uc138\uc694.";  // 기존 비밀번호를 입력해 주세요.
				document.passwordForm.user_password.focus();
			} else if (params.new_password == "") {
				alertMessage = "\uc0c8 \ube44\ubc00\ubc88\ud638\ub97c \uc785\ub825\ud574 \uc8fc\uc138\uc694.";  // 새 비밀번호를 입력해 주세요.
				document.passwordForm.new_password.select();
			} else if (params.new_password != confirmPassword) {
				alertMessage = "\uc0c8 \ube44\ubc00\ubc88\ud638\uc640 \uc0c8 \ube44\ubc00\ubc88\ud638 \ud655\uc778\uc758 \uac12\uc774 \ub2e4\ub985\ub2c8\ub2e4.";  // 새 비밀번호와 새 비밀번호 확인의 값이 다릅니다.
				document.passwordForm.confirm_password.select();
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error, [
							{"code":"406", "message":"-", "callback":function() {
								alertNode.innerHTML = "\uae30\uc874 \ube44\ubc00\ubc88\ud638\uac00 \ud2c0\ub9bd\ub2c8\ub2e4.";  // 기존 비밀번호가 틀립니다.
								document.passwordForm.user_password.select();
							}}
						]);

						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.passwordForm.user_password.focus();
	}
};