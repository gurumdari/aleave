$content$.setting.approval = {
	appendApprovalLine: function(lineContainer, approverList, worker, isFirst) {
		var approverCount = this.dataset.approver_count;

		var lineFieldset = document.createElement("fieldset");
		lineFieldset.setAttribute("class", "approver" + approverCount);

		var lineLegend = document.createElement("legend");
		lineFieldset.appendChild(lineLegend);

		var lineLabel = document.createElement("label");
		lineLegend.appendChild(lineLabel);

		var lineInput = document.createElement("input");
		lineInput.setAttribute("type", "radio");
		lineInput.setAttribute("name", "line_id");
		lineInput.value = approverList[0].line_id;
		lineLabel.appendChild(lineInput);

		var lineSpan = document.createElement("span");
		lineSpan.appendChild(document.createTextNode(approverList[0].line_name));
		lineLabel.appendChild(lineSpan);

		var firstLineCount = ((approverCount == 2) || (approverCount == 4)) ? 2 : 3;

		var lineGroupUl = document.createElement("ul");
		lineFieldset.appendChild(lineGroupUl);

		var firstLineGroupLi = document.createElement("li");
		lineGroupUl.appendChild(firstLineGroupLi);

		var firstLineTable = document.createElement("table");
		firstLineGroupLi.appendChild(firstLineTable);

		var firstLineTbody = document.createElement("tbody");
		firstLineTable.appendChild(firstLineTbody);

		var firstLineRow = firstLineTbody.insertRow(0);
		
		for (var i = 0; i < firstLineCount; i++) {
			var approverTd = firstLineRow.insertCell(i * 2);

			var userDiv = document.createElement("div");
			approverTd.appendChild(userDiv);

			var orgDiv = document.createElement("div");
			approverTd.appendChild(orgDiv);

			if (approverList[i]) {
				approverTd.setAttribute("id", approverList[i].approver_id);

				if (approverList[i].approver_id == worker)  userDiv.innerHTML = "\ubcf8\uc778";  // 본인
				else                                        userDiv.innerHTML = "<SPAN>" + $jnode$.escapeXML(approverList[i].approver_name) + "</SPAN> <SPAN>" + $jnode$.escapeXML(approverList[i].position_name) + "</SPAN>";

				orgDiv.innerHTML = $jnode$.escapeXML(approverList[i].org_name);
			}

			if (i < firstLineCount - 1) {
				arrowTd = firstLineRow.insertCell(i * 2 + 1);
			}
		}

		if (approverCount > 3) {
			lineGroupUl.appendChild(document.createElement("li"));

			var lastLineGroupLi = document.createElement("li");
			lineGroupUl.appendChild(lastLineGroupLi);

			var lastLineTable = document.createElement("table");
			lastLineGroupLi.appendChild(lastLineTable);

			var lastLineTbody = document.createElement("tbody");
			lastLineTable.appendChild(lastLineTbody);

			var lastLineRow = lastLineTbody.insertRow(0);
			var lastLineCount = (approverCount == 4) ? 2 : 3;

			for (var i = 0; i < lastLineCount; i++) {
				var approverTd = lastLineRow.insertCell(i * 2);

				var userDiv = document.createElement("div");
				approverTd.appendChild(userDiv);

				var orgDiv = document.createElement("div");
				approverTd.appendChild(orgDiv);

				if (approverList[firstLineCount + i]) {
					approverTd.setAttribute("id", approverList[firstLineCount + i].approver_id);

					if (approverList[firstLineCount + i].approver_id == worker)  userDiv.innerHTML = "\ubcf8\uc778";  // 본인
					else                                                         userDiv.innerHTML = "<SPAN>" + $jnode$.escapeXML(approverList[firstLineCount + i].approver_name) + "</SPAN> <SPAN>" + $jnode$.escapeXML(approverList[firstLineCount + i].position_name) + "</SPAN>";

					orgDiv.innerHTML = $jnode$.escapeXML(approverList[firstLineCount + i].org_name);
				}

				if (i < lastLineCount - 1) {
					arrowTd = lastLineRow.insertCell(i * 2 + 1);
				}
			}
		}

		lineInput.addEventListener("click", function(event) {
			document.querySelector("div.section > article > div.article > fieldset > button:last-child").disabled = false;
		}, false);

		if (isFirst) {
			lineContainer.insertBefore(lineFieldset, lineContainer.firstElementChild);
			lineInput.click();
		} else {
			lineContainer.appendChild(lineFieldset);
		}
	},

	resize: function() {
		var windowWidth      = window.innerWidth;
		var windowHeight     = window.innerHeight;
		var defaultContainer = document.querySelector("div.section > article > div.article > div.subtitle + div.content:nth-child(2)");
		var customContainer  = defaultContainer.nextElementSibling.nextElementSibling;

		if (windowWidth > 736) {
			customContainer.style.height = (windowHeight - 253 - defaultContainer.offsetHeight) + "px";  // 54
		} else {
			customContainer.removeAttribute("style");
		}
	},

	service: function() {
		$jnode$.pushHistory(this.conf);

		window.addEventListener("resize", this.resize, false);
		this.resize();

		var worker = "";
		var approverCount = parseInt(this.dataset.approver_count);
		var defaultApproverTds = document.querySelectorAll("div.section > article > div.article > div.subtitle + div.content > fieldset > ul > li > table > tbody > tr > td:nth-child(odd)");
		var approvalLineList = this.dataset.approvalLineList;
		var defaultApproverList = approvalLineList[0];
		for (var j = 0; j < defaultApproverList.length; j++) {
			var lineTd = defaultApproverTds[j];
			lineTd.setAttribute("id", defaultApproverList[j].approver_id);
			if (j == 0)  worker = defaultApproverList[j].approver_id;
			else         lineTd.firstElementChild.innerHTML = "<SPAN>" + $jnode$.escapeXML(defaultApproverList[j].approver_name) + "</SPAN> <SPAN>" + $jnode$.escapeXML(defaultApproverList[j].position_name) + "</SPAN>";
			lineTd.lastElementChild.innerHTML = $jnode$.escapeXML(defaultApproverList[j].org_name);
		}

		var lineContainer = document.querySelector("div.section > article > div.article > div.subtitle + div.content:nth-child(4)");

		for (var i = 1; i < approvalLineList.length; i++) {
			this.appendApprovalLine(lineContainer, approvalLineList[i], worker);
		}

		var addButton  = document.querySelector("div.section > article > div.article > fieldset > button:first-child");
		var editButton = addButton.nextElementSibling;

		editButton.disabled = true;

		addButton.addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/approval/add", {
				useLoading: true,
				icon:       true,
				title:      "\uacb0\uc7ac \ub77c\uc778 \ucd94\uac00",  // 결재 라인 추가
				width:      480,
				height:     185 + (approverCount * 31),
				renderer:   "-j"
			});
		}, false);

		editButton.addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/approval/edit", {
				useLoading: true,
				icon:       true,
				title:      "\uacb0\uc7ac \ub77c\uc778 \ud3b8\uc9d1",  // 결재 라인 편집
				width:      480,
				height:     185 + (approverCount * 31),
				renderer:   "-j"
			});
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};