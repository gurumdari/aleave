$content$.setting.account = {
	service: function() {
		var that      = this;
		var userInfo  = this.dataset.userInfo;

		$jnode$.pushHistory(that.conf);

		if (!this.dataset.readonly) {
			if (userInfo.level_id != "9") {
				var orgNameInput = document.userForm.org_name;

				if (userInfo.level_id == "1") {
					orgNameInput.addEventListener("click", function(event) {
						$jnode$.requireContent("winup", "/setting/org/select", {
							useLoading: true,
							icon:       true,
							title:      "\ubd80\uc11c \uc120\ud0dd",  // 부서 선택
							width:      420,
							height:     268,
							renderer:   "-j"
						});
					}, false);
				} else {
					orgNameInput.addEventListener("click", function(event) {
						$controller$.prompt.alert("\ubd80\uc11c\uc7a5\uc73c\ub85c \uc124\uc815\ub41c \uc0ac\uc6a9\uc790\ub294 \ubcf8\uc778\uc774 \uc9c1\uc811 \ubd80\uc11c\ub97c \ubcc0\uacbd\ud560 \uc218 \uc5c6\uc2b5\ub2c8\ub2e4.", null, true);  // 부서장으로 설정된 사용자는 본인이 직접 부서를 변경할 수 없습니다.
					}, false);
				}
			}

			var addressText = document.userForm.user_address;

			if (addressText) {
				addressText.addEventListener("keydown", function(event) {
					var keyCode = event.keyCode || event.which;
	
					if(keyCode == 13) {
						event.preventDefault();
					}
				}, false);
	
				addressText.addEventListener("paste", function(event) {
					window.setTimeout(function() {
						addressText.value = addressText.value.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");
					});
				}, false);
			}

			document.querySelector("div.section > article > div.article > fieldset > ul.submit > li:last-child > button:first-child").addEventListener("click", function(event) {
				var alertDiv = this.parentNode.previousElementSibling.firstElementChild;

				var params = {
					command:   "updateUser",
					user_name: document.userForm.user_name.value.trim(),
					user_id:   document.userForm.user_id.value,
				};

				if (userInfo.level_id == "9") {
					params.user_note = document.userForm.user_note.value.trim();
				} else {
					params.user_contact = document.userForm.user_contact.value.trim();
					params.user_address = document.userForm.user_address.value.trim();

					params.update_org = "true";
					params.org_id   = document.userForm.org_id.value;
					params.org_name = document.userForm.org_name.value;

					var positionSelect = document.userForm.position_id;
					params.position_id   = positionSelect.value,
					params.position_name = positionSelect.options[positionSelect.selectedIndex].text
				}

				var alertMessage = null;

				if (params.user_name == "") {
					alertMessage = "\uc0ac\uc6a9\uc790 \uc774\ub984\uc744 \uc785\ub825\ud574\uc8fc\uc138\uc694.";  // 사용자 이름을 입력해주세요.
					document.userForm.user_name.select();
				}

				if (alertMessage) {
					document.querySelector("body > section > div.section > article > div.article").setAttribute("class", "article space");
					alertDiv.setAttribute("class", "alert");
					alertDiv.innerHTML = alertMessage;
				} else {
					$controller$.loading.show();
					document.querySelector("body > section > div.section > article > div.article").setAttribute("class", "article");
					alertDiv.removeAttribute("class");
					alertDiv.innerHTML = "";

					$jnode$.ajax.service({
						"url":      "/ajax/user.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":  params,
						"success": function(response) {
							document.querySelector("body > header > ul > li:last-child > ul > li > button.account").firstChild.nodeValue = params.user_name;
							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			}, false);
		}

		document.querySelector("div.section > article > div.article > fieldset > ul.submit > li:last-child > button:last-child").addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/user/password_change", {
				useLoading: true,
				icon:       true,
				title:      "\ube44\ubc00\ubc88\ud638 \ubcc0\uacbd",  // 비밀번호 변경
				width:      420,
				height:     225
			});
		}, false);
	}
};