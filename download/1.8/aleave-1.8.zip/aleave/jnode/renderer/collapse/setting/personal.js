$content$.setting.personal = {
	service: function() {
		$jnode$.pushHistory(this.conf);

		document.querySelector("article > div.article > fieldset > ul.submit > li > button").addEventListener("click", function(event) {
			var alertDiv     = this.parentNode.previousElementSibling.firstElementChild;
			var alertMessage = null;
			var params = $jnode$.toJSON(document.settingForm);

			if (params.enabled) {
				params.email = params.email.trim();

				if (params.enabled != "N") {
					if (params.email == "") {
						alertMessage = "\uc218\uc2e0\ubc1b\uc744 \uba54\uc77c\uc8fc\uc18c\ub97c \uc785\ub825\ud574\uc8fc\uc138\uc694.";  // 수신받을 메일주소를 입력해주세요.
						document.settingForm.email.select();
					}
				}
			}

			if (alertMessage) {
				document.querySelector("body > section > div.section > article > div.article").setAttribute("class", "article space");
				alertDiv.setAttribute("class", "alert");
				alertDiv.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				document.querySelector("body > section > div.section > article > div.article").setAttribute("class", "article");
				alertDiv.removeAttribute("class");
				alertDiv.innerHTML = "";

				$jnode$.ajax.service({
					"url":      "/ajax/setting.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);
	}
};