$content$.outside = {
	service: function() {
		var articleId = this.conf.articleId;
		var fieldsetClassSubfix = "1";

		if (articleId == null)  articleId = this.dataset.start_id;

		if (!this.dataset.is_admin) {
			var fieldsetClassSubfix = "2";

			var waitingCount = this.dataset.waiting_count;
			var timeoffMenu  = document.querySelector("body > nav > ul > li > label > input[value='/timeoff'] + span");
			var outsideMenu  = document.querySelector("body > nav > ul > li > label > input[value='/outside'] + span");

			if (waitingCount.timeoff)  timeoffMenu.setAttribute("class", waitingCount.timeoff);
			else                       timeoffMenu.removeAttribute("class");

			if (waitingCount.outside)  outsideMenu.setAttribute("class", waitingCount.outside);
			else                       outsideMenu.removeAttribute("class");
		}

		setArticleMenus(articleId, fieldsetClassSubfix);
	}
};