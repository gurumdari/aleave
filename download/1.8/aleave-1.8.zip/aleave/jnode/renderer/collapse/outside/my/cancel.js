$content$.outside.my.cancel = {
	service: function() {
		var dataset      = this.dataset;
		var approvalInfo = dataset.approvalInfo;
		var approverList = dataset.approverList;

		var approvalPeriod = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr > td.approval_period").firstChild.nodeValue;
		var typePeriods = approvalPeriod.split(": ");

		var typeTh = document.querySelector("aside.popup article > div.popup > form > table.form > tbody > tr > th.type");
		typeTh.appendChild(document.createTextNode(typePeriods[0]));
		typeTh.nextElementSibling.appendChild(document.createTextNode(typePeriods[1]));

		var outsideComment = document.cancelForm.outside_comment;

		outsideComment.addEventListener("keydown", function(event) {
			var keyCode = event.keyCode || event.which;

			if(keyCode == 13) {
				event.preventDefault();
			}
		}, false);

		outsideComment.addEventListener("paste", function(event) {
			window.setTimeout(function() {
				outsideComment.value = outsideComment.value.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");
			});
		}, false);

		outsideComment.focus();

		document.cancelForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			$controller$.loading.show();

			var approverIds = [];

			for (var i = 0; i < approverList.length; i++) {
				approverIds.push(approverList[i].approver_id);
			}

			var params = {
				command:         "cancelOutside",
				outside_id:      approvalInfo.outside_id,
				outside_comment: outsideComment.value.trim(),
				sign_step:       (approverIds[0] == approvalInfo.user_id ? "1" : "0"),
				approver_ids:    JSON.stringify(approverIds)
			};

			$jnode$.ajax.service({
				"url":      "/ajax/outside.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params":  params,
				"success": function(response) {
					params.outside_startdate  = approvalInfo.outside_startdate;
					params.outside_enddate    = approvalInfo.outside_enddate;
					params.outside_starttime  = approvalInfo.outside_starttime;
					params.outside_endtime    = approvalInfo.outside_endtime;
					params.destination        = approvalInfo.destination;
					params.approval_step      = approvalInfo.approval_step;
					params.outside_id         = response.outside_id;
					params.create_date        = response.create_date;
					params.canceled_id        = approvalInfo.outside_id;

					var outsideTbody = document.querySelector("aside.grid > div > table > tbody");
					$content$.outside.my.appendOutsideRow(outsideTbody, params, true).click();

					$controller$.popup.close();
					$controller$.winup.close();
					$controller$.loading.hide();
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}, false);
	}
};