$content$.outside.unsettled = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if (windowWidth > 736) {
			$controller$.grid.resize(null, windowHeight - 146);
		} else {
			$controller$.grid.removeHeight();
		}

		$controller$.grid.resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();

		var that          = this;
		var dataset       = this.dataset;
		var worker        = dataset.worker;
		var unsettledList = dataset.unsettledList;

		$jnode$.pushHistory(this.conf);

		var approvalButton = document.querySelector("div.section > article > div.article > fieldset > button");
		approvalButton.disabled = true;

		$jnode$.requireController("grid", {caller:that.conf}).on(function() {
			$controller$.grid.service();

			var unsettledTbody = document.querySelector("aside.grid > div > table > tbody");

			window.addEventListener("resize", that.resize, false);
			that.resize();

			function appendUnsettledRow(unsettledData) {
				var row = document.createElement("tr");
				row.setAttribute("id", unsettledData.outside_id);
				row.setAttribute("class", "waiting");
				unsettledTbody.appendChild(row);

				var stepCell = row.insertCell(0);
				stepCell.appendChild(document.createTextNode(Math.abs(unsettledData.sign_step) + "/" + unsettledData.approval_step));

				var outsideType = null;
				var cancelValue = (unsettledData.canceled_id > 0) ? " \ucde8\uc18c " : " ";  // 취소

				if (unsettledData.outside_starttime == "S") {
					if (unsettledData.outside_endtime == "E") {
						outsideType = "\uc678\uadfc" + cancelValue + "(\uc885\uc77c)";  // 외근  // 종일
					} else {
						outsideType = "\uc9c1\ucd9c" + cancelValue + "(~ " + unsettledData.outside_endtime + "\uc2dc)";  // 직출  // 시
					}
				} else if (unsettledData.outside_endtime == "E") {
					outsideType = "\uc9c1\ud1f4" + cancelValue + "(" + unsettledData.outside_starttime + "\uc2dc ~)";  // 직퇴  // 시
				} else {
					outsideType = "\uc678\uadfc" + cancelValue + "(" + unsettledData.outside_starttime + "\uc2dc ~ " + unsettledData.outside_endtime + "\uc2dc)";  // 외근  // 시  // 시
				}

				var nameSpan = document.createElement("span");
				nameSpan.appendChild(document.createTextNode(unsettledData.user_name));

				var typeSpan = document.createElement("span");
				typeSpan.appendChild(document.createTextNode(outsideType));

				var typeCell = row.insertCell(1);
				typeCell.appendChild(nameSpan);
				typeCell.appendChild(document.createTextNode(" - "));
				typeCell.appendChild(typeSpan);

				var destinationCell = row.insertCell(2);
				destinationCell.appendChild(document.createTextNode(unsettledData.destination));

				var periodValue = dateFormatter.format($module$.date.Utils.parse(unsettledData.outside_startdate), dateFormatter.DateStyle.MEDIUM);

				if (unsettledData.outside_startdate != unsettledData.outside_enddate) {
					periodValue += " ~ " + dateFormatter.format($module$.date.Utils.parse(unsettledData.outside_enddate), dateFormatter.DateStyle.MEDIUM);
				}

				var periodCell = row.insertCell(3);
				periodCell.appendChild(document.createTextNode(periodValue));

				var createCell = row.insertCell(4);
				createCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(unsettledData.create_date), dateFormatter.DateStyle.MEDIUM)));

				var statusValue = "";
				if (unsettledData.sign_step < 0) {
					statusValue = "\ubc18\ub824";  // 반려
					typeCell.setAttribute("class", "rejected");
				} else if (unsettledData.approval_step > unsettledData.sign_step) {
					statusValue = "\ub300\uae30";  // 대기
					typeCell.setAttribute("class", "waiting");
				} else {
					statusValue = "\uc2b9\uc778";  // 승인
					typeCell.setAttribute("class", "approved");
				}

				if (unsettledData.canceled_id > 0) {
					$jnode$.node.addClass(typeCell, "cancel");
					typeCell.appendChild(document.createTextNode(" \ucde8\uc18c"));  // 취소

					periodCell.setAttribute("class", "cancel");
				}

				var statusCell = row.insertCell(5);
				statusCell.appendChild(document.createTextNode(statusValue));

				row.addEventListener("click", function(event) {
					var selectedRow = unsettledTbody.querySelector("tbody > tr.selected");
					if (selectedRow)  $jnode$.node.removeClass(selectedRow, "selected");

					$jnode$.node.addClass(this, "selected");

					approvalButton.disabled = false;

					if ($jnode$.node.hasClass(this, "waiting")) {
						approvalButton.firstElementChild.innerHTML = "\uacb0\uc7ac\ucc98\ub9ac";  // 결재처리
					} else {
						approvalButton.firstElementChild.innerHTML = "\uc0c1\uc138\uc815\ubcf4";  // 상세정보
					}
				}, false);
			}

			for (var i = 0; i < unsettledList.length; i++) {
				appendUnsettledRow(unsettledList[i]);
			}

			$controller$.loading.hide();

			approvalButton.addEventListener("click", function(event) {
				var selectedRow = unsettledTbody.querySelector("tbody > tr.selected");
				var nodeId    = "/outside/approval/view";
				var winupName = "\uc678\uadfc \uc0c1\uc138\uc815\ubcf4";  // 외근 상세정보
				var height    = 417;

				if ($jnode$.node.hasClass(selectedRow, "waiting")) {
					nodeId    = "/outside/approval/check";
					winupName = "\uc678\uadfc \uacb0\uc7ac\ucc98\ub9ac";  // 외근 결재처리
					height    = 482;
				}

				$jnode$.requireContent("winup", nodeId, {
					useLoading: true,
					icon:       true,
					title:      winupName,
					width:      480,
					height:     height,
					outside_id: selectedRow.getAttribute("id")
				});
			}, false);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};