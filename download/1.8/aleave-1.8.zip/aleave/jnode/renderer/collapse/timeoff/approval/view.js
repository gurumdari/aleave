$content$.timeoff.approval.view = {
	service: function() {
		var dataset      = this.dataset;
		var worker       = dataset.worker;
		var approvalInfo = dataset.approvalInfo;
		var approverList = dataset.approverList;
		var isLeave = (["late", "early", "absence"].indexOf(approvalInfo.timeoff_type) < 0);

		var stepContainer    = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr > td > div > ul");
		var detailContainer  = stepContainer.nextElementSibling;
		var lastStepApprover = worker;

		for (var i = 0; i < approverList.length; i++) {
			var approverId = approverList[i].approver_id;

			var approverLi = document.createElement("li");
			stepContainer.appendChild(approverLi);

			var approverLabel = document.createElement("label");
			approverLi.appendChild(approverLabel);

			var approverInput = document.createElement("input");
			approverInput.setAttribute("type", "radio");
			approverInput.setAttribute("name", "step_id");
			approverInput.value = approverId;
			approverLabel.appendChild(approverInput);

			if (approverList[i].sign_status == "waiting") {
				approverInput.setAttribute("class", "waiting");
			}

			approverLabel.appendChild(document.createElement("span"));
			approverLabel.appendChild(document.createElement("div"));

			var detailTable = document.createElement("table");
			detailTable.setAttribute("id", approverId);
			detailTable.setAttribute("class", "form nogroup");
			detailContainer.appendChild(detailTable);

			var datailTbody = document.createElement("tbody");
			detailTable.appendChild(datailTbody);

			// 결재자
			var detailRow0 = datailTbody.insertRow(0);

			var detailTh0 = document.createElement("th");
			detailTh0.innerHTML = "\uacb0\uc7ac\uc790";  // 결재자
			detailRow0.appendChild(detailTh0);

			var detailTd0 = document.createElement("td");
			detailTd0.appendChild(document.createTextNode(approverList[i].approver_name + " (" + approverList[i].position_name + ") @ " + approverList[i].org_name));
			detailRow0.appendChild(detailTd0);

			if (approverList[i].agent_id)  detailTd0.setAttribute("class", "agent");

			if (approverList[i].sign_date) {
				lastStepApprover = approverId;

				// 결재일
				var detailRow1 = datailTbody.insertRow(1);

				var detailTh1 = document.createElement("th");
				detailTh1.innerHTML = "\uacb0\uc7ac\uc77c";  // 결재일
				detailRow1.appendChild(detailTh1);

				var detailTd1 = document.createElement("td");
				detailTd1.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(approverList[i].sign_date), "DEFAULT")));
				detailRow1.appendChild(detailTd1);

				if (approvalInfo.user_id != approverId) {
					// 전달사항
					var detailRow2 = datailTbody.insertRow(2);

					var detailTh2 = document.createElement("th");
					detailTh2.innerHTML = "\uc804\ub2ec\uc0ac\ud56d";  // 전달사항
					detailRow2.appendChild(detailTh2);

					var detailTd2 = document.createElement("td");
					detailTd2.appendChild(document.createTextNode(approverList[i].approver_comment));
					detailRow2.appendChild(detailTd2);
				}
			}

			approverInput.addEventListener("click", function(event) {
				var selectedTable = detailContainer.querySelector("div > table.selected");
				if (selectedTable)  $jnode$.node.removeClass(selectedTable, "selected");

				var approverId = this.value;
				$jnode$.node.addClass(detailContainer.querySelector("div > table[id='" + approverId + "']"), "selected");
			}, false);
		}

		stepContainer.querySelector("ul > li > label > input[value='" + lastStepApprover + "']").click();

		if (isLeave) {
			var periodValue   = "";
			var timeoffStarts = approvalInfo.timeoff_start.split(" ");
			var timeoffEnds   = approvalInfo.timeoff_end.split(" ");

			if (timeoffStarts[0] == timeoffEnds[0]) {
				periodValue = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM);
				if (timeoffStarts[1] == timeoffEnds[1])  periodValue += " " + (timeoffStarts[1] == "AM" ? "\uc624\uc804" : "\uc624\ud6c4");  // 오전  // 오후
			} else {
				var periodValue1 = dateFormatter.format($module$.date.Utils.parse(timeoffStarts[0]), dateFormatter.DateStyle.MEDIUM);
				var periodValue2 = dateFormatter.format($module$.date.Utils.parse(timeoffEnds[0]), dateFormatter.DateStyle.MEDIUM);

				if (timeoffStarts[1] == "PM")  periodValue1 += " \uc624\ud6c4";  // 오후
				if (timeoffEnds[1]   == "AM")  periodValue2 += " \uc624\uc804";  // 오전

				periodValue = periodValue1 + " ~ " + periodValue2;
			}

			document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr > td.leave > span").innerHTML = periodValue;
		}

		if (approvalInfo.sign_step > -1) {
			if (isLeave) {
				var leaveDayTd = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr.leave > td");
				var leaveDayValue = approvalInfo.request_days + "\uc77c";  // 일

				if (approvalInfo.canceled_id > 0)  leaveDayValue = "-" + leaveDayValue;

				if (approvalInfo.request_days != Math.abs(approvalInfo.applied_days)) {
					if (approvalInfo.canceled_id < 1 || approvalInfo.applied_days == 0)  leaveDayValue += " → " + approvalInfo.applied_days + "\uc77c";  // 일
					else                                                                 leaveDayValue += " → -" + approvalInfo.applied_days + "\uc77c";  // 일
				}

				leaveDayTd.innerHTML = leaveDayValue;
			} else {
				// 시간: \uc2dc\uac04
				// 일: \uc77c
				var appliedDaysMap = {
					"0.125": "1\uc2dc\uac04",
					"0.25":  "2\uc2dc\uac04",
					"0.375": "3\uc2dc\uac04",
					"0.5":   "4\uc2dc\uac04 (0.5\uc77c)",
					"0.625": "5\uc2dc\uac04",
					"0.75":  "6\uc2dc\uac04",
					"0.875": "7\uc2dc\uac04",
					"1":     "8\uc2dc\uac04 (1\uc77c)",
					"1.125": "9\uc2dc\uac04 (+1\uc2dc\uac04)",
					"1.25":  "10\uc2dc\uac04 (+2\uc2dc\uac04)",
					"1.375": "11\uc2dc\uac04 (+3\uc2dc\uac04)",
					"1.5":   "12\uc2dc\uac04 (+0.5\uc77c)"
				};

				var absenceTimeTd = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr.absence > td");
				var absenceTimeValue = appliedDaysMap[approvalInfo.request_days.toString()];

				if (approvalInfo.canceled_id > 0)  absenceTimeValue = "-" + absenceTimeValue;

				if (approvalInfo.request_days != Math.abs(approvalInfo.applied_days)) {
					if (approvalInfo.canceled_id < 1 || approvalInfo.applied_days == 0)  absenceTimeValue += " → " + appliedDaysMap[approvalInfo.applied_days.toString()];
					else                                                                 absenceTimeValue += " → -" + appliedDaysMap[approvalInfo.applied_days.toString()];
				}

				absenceTimeTd.innerHTML = absenceTimeValue;
			}
		}

		var cancelButton = document.approvalForm.querySelector("form > ul.submit > li > button");
		if (cancelButton) {
			$controller$.winup.resize(null, 424);

			cancelButton.addEventListener("click", function(event) {
				$jnode$.requireContent("popup", "/timeoff/my/cancel", {
					timeoff_id: approvalInfo.timeoff_id,
					width:  280,
					height: 206
				});
			}, false);
		}
	}
};