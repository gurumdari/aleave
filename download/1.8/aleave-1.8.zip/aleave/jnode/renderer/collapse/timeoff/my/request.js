$content$.timeoff.my.request = {
	resize: function() {
		var popupContentDiv = document.querySelector("aside.popup > ul > li > div");

		var windowWidth = window.innerWidth;

		if (popupContentDiv.getAttribute("class") == "calendar_area") {
			if (windowWidth > 736) {
				$controller$.popup.resize(246, 246);
			} else {
				$controller$.popup.resize(280, 335);
			}
		} else {
			if (windowWidth > 400) {
				$controller$.popup.resize(360, 330);
			} else {
				$controller$.popup.widthP(100);
			}
		}
	},

	setApprovalLine: function(approverList, lineId) {
		var worker = $content$.timeoff.my.request.dataset.worker;
		var lineContainer = document.querySelector("aside.winup article > div.winup > form > div > ul");
		lineContainer.innerHTML = "";

		if (lineId == null) {
			lineId = approverList[0].line_id;
			if (lineId)  lineContainer.setAttribute("id", lineId);
			else         lineContainer.setAttribute("id", "0");

			for (var i = 0; i < approverList.length; i++) {
				var approverId   = approverList[i].approver_id;
				var approverName = (worker == approverId) ? "\ubcf8\uc778" : approverList[i].approver_name + " (" + approverList[i].position_name + ")";  // 본인

				var li = document.createElement("li");
				li.setAttribute("id", approverList[i].approver_id);
				li.appendChild(document.createTextNode((i + 1) + "\ub2e8\uacc4: " + approverName + " @ " + approverList[i].org_name));  // 단계
				lineContainer.appendChild(li);
			}
		} else {
			lineContainer.setAttribute("id", lineId);
			lineContainer.innerHTML = approverList;
		}
	},

	service: function() {
		var periodLimit = this.dataset.timeoff_period_limit;

		var worker   = this.dataset.worker;
		var today    = new Date();
		var isoToday = $module$.date.Utils.format(today);

		var leaveLi   = document.timeoffForm.querySelector("form > table.form > tbody > tr > td.type > ul > li#leave");
		var absenceLi = leaveLi.nextElementSibling;

		var leaveTr   = leaveLi.parentNode.parentNode.parentNode.nextElementSibling;
		var absenceTr = leaveTr.nextElementSibling;

		var startLink = leaveTr.lastElementChild.firstElementChild.firstElementChild;
		var endLink   = leaveTr.lastElementChild.lastElementChild.previousElementSibling.firstElementChild;
		
		var abseneceLink = absenceTr.lastElementChild.firstElementChild;
		abseneceLink.innerHTML = dateFormatter.format(today, dateFormatter.DateStyle.MEDIUM);
		abseneceLink.setAttribute("value", isoToday);

		window.addEventListener("resize", this.resize, false);

		this.setApprovalLine(this.dataset.approvalLineList[0]);

		document.timeoffForm.timeoff_class.addEventListener("change", function(event) {
			if (this.value == "leave") {
				leaveLi.setAttribute("class", "select");
				absenceLi.removeAttribute("class");

				leaveTr.setAttribute("class", "selected");
				absenceTr.removeAttribute("class");
			} else {
				leaveLi.removeAttribute("class");
				absenceLi.setAttribute("class", "select");

				leaveTr.removeAttribute("class");
				absenceTr.setAttribute("class", "selected");
			}
		}, false);

		document.timeoffForm.timeoff_type2.addEventListener("change", function(event) {
			var absenceTime1 = abseneceLink.nextElementSibling;
			var absenceTime2 = absenceTime1.nextElementSibling;

			if (this.value == "absence") {
				absenceTime1.removeAttribute("class");
				absenceTime2.setAttribute("class", "selected");
			} else {
				absenceTime1.setAttribute("class", "selected");
				absenceTime2.removeAttribute("class");
			}
		}, false);

		function dateSelectEvent(dateLink) {
			var windowWidth  = window.innerWidth;
			var popupDomain  = $jnode$.controller.getDomain("popup");
			var popupContent = popupDomain.querySelector($jnode$.selector.controller.popup.content);
			popupContent.innerHTML = "<DIV class=\"calendar\"></DIV><UL class=\"submit\"><LI></LI><LI><BUTTON>\ud655\uc778</BUTTON></LI></UL>";  // 확인

			popupDomain.querySelector("aside.popup > ul > li > div").setAttribute("class", "calendar_area");

			$controller$.popup.open({
				width:  (windowWidth > 736 ? 246 : 280),
				height: (windowWidth > 736 ? 246 : 335)
			});

			var date     = null;
			var isoValue = dateLink.getAttribute("value");

			if (isoValue) {
				date = $module$.date.Utils.parse(isoValue);
			} else {
				var startValue = startLink.getAttribute("value");
				var endValue   = endLink.getAttribute("value");
				
				if      (startValue)  isoValue = startValue;
				else if (endValue  )  isoValue = endValue;

				if (isoValue) {
					date = $module$.date.Utils.parse(isoValue);
				} else {
					date = new Date();
					isoValue = $module$.date.Utils.format(date);
				}
			}

			var dateCalendar = popupDomain.querySelector("aside.popup article > div.calendar");
			var dateLi       = dateCalendar.nextElementSibling.firstElementChild;

			dateLi.innerHTML = $jnode$.escapeXML(dateFormatter.format(date, dateFormatter.DateStyle.LONG));
			dateLi.setAttribute("value", "iso:" + isoValue);

			displayCalendar(date, dateLi, dateCalendar, isoValue);

			dateLi.addEventListener("click", function() {
				var selectedIsoValue = this.getAttribute("value").substring(4);
				displayCalendar(selectedIsoValue, this, dateCalendar, selectedIsoValue);
			}, false);

			dateLi.nextElementSibling.firstElementChild.addEventListener("click", function(event) {
				var selectedIsoValue = dateLi.getAttribute("value").substring(4);
				dateLink.setAttribute("value", selectedIsoValue);
				dateLink.innerHTML = dateFormatter.format($module$.date.Utils.parse(selectedIsoValue), dateFormatter.DateStyle.MEDIUM);

				$controller$.popup.close();
			}, false);
		}

		startLink.addEventListener("click", function(event) {
			dateSelectEvent(this);
		}, false);

		endLink.addEventListener("click", function(event) {
			dateSelectEvent(this);
		}, false);

		abseneceLink.addEventListener("click", function(event) {
			dateSelectEvent(this);
		}, false);

		var timeoffComment = document.timeoffForm.timeoff_comment;

		timeoffComment.addEventListener("keydown", function(event) {
			var keyCode = event.keyCode || event.which;

			if(keyCode == 13) {
				event.preventDefault();
			}
		}, false);

		timeoffComment.addEventListener("paste", function(event) {
			window.setTimeout(function() {
				timeoffComment.value = timeoffComment.value.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");
			});
		}, false);

		var lineSelectButton = document.timeoffForm.querySelector("form > table.form > tbody > tr > th > button");
		lineSelectButton.addEventListener("click", function(event) {
			document.querySelector("aside.popup > ul > li > div").removeAttribute("class");

			var windowWidth = window.innerWidth;
			var options = {
				useLoading:      true,
				height:          330,
				line_id:         document.timeoffForm.querySelector("form > div > ul").getAttribute("id"),
				setApprovalLine: $content$.timeoff.my.request.setApprovalLine
			};
			
			if (windowWidth > 400)  options.width = 360;
			else                    options.widthP = 100;

			$jnode$.requireContent("popup", "/approval/line", options);
		}, false);

		document.timeoffForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var lineContainer     = document.querySelector("aside.winup article > div.winup > form > div > ul");
			var usedDaysSpan      = document.querySelector("body > section > div.section > article > div.article > ul > li:last-child > span:first-child");
			var availableDaysSpan = usedDaysSpan.nextElementSibling;
			var approverIds       = [];
			var alertMessage      = "";

			for (var i = 0; i < lineContainer.children.length; i++) {
				approverIds.push(lineContainer.children[i].getAttribute("id"));
			}

			var params = {
				command:         "addTimeoff",
				user_id:         worker,
				timeoff_comment: timeoffComment.value.trim(),
				available_days:  availableDaysSpan.innerHTML,
				used_days:       usedDaysSpan.innerHTML,
				applied_days:    "0",
				sign_step:       "0",
				approval_step:   approverIds.length.toString(),
				user_contact:    document.timeoffForm.user_contact.value.trim(),
				approver_ids:    JSON.stringify(approverIds)
			};

			var timeoffStart = null;
			var timeoffEnd   = null;
			var requestDays  = null;
			
			if (document.timeoffForm.timeoff_class.value == "leave") {
				timeoffStart = startLink.getAttribute("value");
				timeoffEnd   = endLink.getAttribute("value");
				requestDays  = document.timeoffForm.timeoff_day.value.trim();
			} else {
				timeoffStart = abseneceLink.getAttribute("value");
				timeoffEnd   = "";
			}

			if (timeoffStart == null) {
				alertMessage = "\ud734\uac00 \uc2dc\uc791 \ub0a0\uc9dc\ub97c \uc120\ud0dd\ud574\uc8fc\uc138\uc694.";  // 휴가 시작 날짜를 선택해주세요.
			} else if (timeoffEnd == null) {
				alertMessage = "\ud734\uac00 \ub05d\ub098\ub294 \ub0a0\uc9dc\ub97c \uc120\ud0dd\ud574\uc8fc\uc138\uc694.";  // 휴가 끝나는 날짜를 선택해주세요.
			} else if (requestDays == "") {
				alertMessage = "\ud734\uac00 \uae30\uac04\uc744 \uc785\ub825\ud574\uc8fc\uc138\uc694.";  // 휴가 기간을 입력해주세요.
				document.timeoffForm.timeoff_day.select();
			} else if (approverIds.length == 0) {
				alertMessage = "\uacb0\uc7ac \ub77c\uc778 \ub2e8\uacc4\uac00 \uc5c6\uc2b5\ub2c8\ub2e4. \uacb0\uc7ac \ub77c\uc778\uc744 \uc120\ud0dd\ud574\uc8fc\uc138\uc694.";  // 결재 라인 단계가 없습니다. 결재 라인을 선택해주세요.
				lineSelectButton.focus();
			} else if (requestDays) {
				var floatRequestDays = parseFloat(requestDays);

				if (timeoffStart > timeoffEnd) {
					alertMessage = "\ub05d\ub098\ub294 \ub0a0\uc9dc\uac00 \uc2dc\uc791 \ub0a0\uc9dc\ubcf4\ub2e4 \ube60\ub97c \uc218 \uc5c6\uc2b5\ub2c8\ub2e4.";  // 끝나는 날짜가 시작 날짜보다 빠를 수 없습니다.
				} else if (timeoffStart == timeoffEnd && document.timeoffForm.time_marker1.value == "PM" && document.timeoffForm.time_marker2.value == "AM") {
					alertMessage = "\uac19\uc740 \ub0a0 \uc624\ud6c4\uc5d0\uc11c \uc624\uc804\uc73c\ub85c \ud734\uac00\ub97c \uc124\uc815\ud560 \uc218 \uc5c6\uc2b5\ub2c8\ub2e4.";  // 같은 날 오후에서 오전으로 휴가를 설정할 수 없습니다.
					document.timeoffForm.time_marker2.focus();
				} else if (isNaN(floatRequestDays) || !(floatRequestDays % 1 == 0 || floatRequestDays % 1 == 0.5)) {
					alertMessage = "\ud734\uac00 \uae30\uac04\uc740 0.5 \ubc30\uc218\uc758 \uc22b\uc790\ub9cc \uc0ac\uc6a9 \uac00\ub2a5\ud569\ub2c8\ub2e4.";  // 휴가 기간은 0.5 배수의 숫자만 사용 가능합니다.
					document.timeoffForm.timeoff_day.select();
				} else if (floatRequestDays < 0.5) {
					alertMessage = "\ud734\uac00 \uae30\uac04\uc740 0.5\uc77c \uc774\uc0c1\ub9cc \uc0ac\uc6a9\ud560 \uc218 \uc788\uc2b5\ub2c8\ub2e4.";  // 휴가 기간은 0.5일 이상만 사용할 수 있습니다.
					document.timeoffForm.timeoff_day.select();
				} else if (periodLimit && (floatRequestDays > periodLimit)) {
					alertMessage = "\ud734\uac00\ub294 \uc5f0\uc18d\ud574\uc11c " + periodLimit + "\uc77c\uc744 \ucd08\uacfc\ud560 \uc218 \uc5c6\uc2b5\ub2c8\ub2e4.";  // 휴가는 연속해서  // 일을 초과할 수 없습니다.
					document.timeoffForm.timeoff_day.select();
				} else {
					requestDays = floatRequestDays.toString();

					if (timeoffStart == timeoffEnd) {
						if (document.timeoffForm.time_marker1.value == document.timeoffForm.time_marker2.value) {
							requestDays = "0.5";
						} else {
							requestDays = "1";
						}
					}
				}
			}

			if (alertMessage) {
				this.parentNode.previousElementSibling.innerHTML = alertMessage;
			} else {
				if (timeoffEnd == "") {
					params.timeoff_type  = document.timeoffForm.timeoff_type2.value;
					params.type_name     = document.timeoffForm.timeoff_type2.options[ document.timeoffForm.timeoff_type2.selectedIndex].text.split(" (")[0];
					params.timeoff_start = timeoffStart + " ";

					if (params.timeoff_type == "absence") {
						params.timeoff_start += "(" + document.timeoffForm.absence_day.options[document.timeoffForm.absence_day.selectedIndex].text + ")";
						params.request_days  = document.timeoffForm.absence_day.value;
					} else {
						params.timeoff_start += "(" + document.timeoffForm.timeoff_time.options[document.timeoffForm.timeoff_time.selectedIndex].text + ")";
						params.request_days  = document.timeoffForm.timeoff_time.value;
					}
				} else {
					params.timeoff_type  = document.timeoffForm.timeoff_type1.value;
					params.type_name     = document.timeoffForm.timeoff_type1.options[ document.timeoffForm.timeoff_type1.selectedIndex].text.split(" (")[0];
					params.timeoff_start = timeoffStart + " " + startLink.nextElementSibling.value;
					params.timeoff_end   = timeoffEnd + " " + endLink.nextElementSibling.value;
					params.request_days  = requestDays;
				}

				var timeoffStarts = timeoffStart.split("-");
				var timeoffYear   = parseInt(timeoffStarts[0], 10);
				var timeoffMonth  = parseInt(timeoffStarts[1], 10);
				var timeoffDay    = parseInt(timeoffStarts[2], 10);
				var entryMonth    = parseInt($content$.timeoff.my.dataset.entry_month, 10);
				var entryDay      = parseInt($content$.timeoff.my.dataset.entry_day, 10);

				params.timeoff_year = timeoffYear.toString();

				if ((entryMonth * 100 + entryDay) > (timeoffMonth * 100 + timeoffDay)) {
					params.entry_year = (timeoffYear - 1).toString();
				} else {
					params.entry_year = params.timeoff_year;
				}

				if (["public", "special", "sick"].indexOf(params.timeoff_type) < 0) {
					params.applied_days = params.request_days;
				}

				if (approverIds[0] == worker)  params.sign_step = "1";

				function executeAjax() {
					$controller$.loading.show();

					$jnode$.ajax.service({
						"url":      "/ajax/timeoff.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":  params,
						"success": function(response) {
							var createdYear = ($content$.timeoff.my.dataset.leave_basic == "entry_month") ? params.entry_year : params.timeoff_year;
							var yearSelect  = document.querySelector("body > section > div.section > article > div.article > ul > li:first-child > select");
							var workingYear = yearSelect.value;
							var yearList    = Array.apply(null, yearSelect.options).map(function(el) { return el.value; });

							// 연도별 휴가 처리현황에 해당 연도가 없으면 연도를 새로 만들어준다.
							if (yearList.indexOf(createdYear) < 0) {
								yearList.push(createdYear);
								yearList = yearList.sort().reverse();

								var yearSubfix = yearSelect.options[0].text.substring(4);
								yearSelect.innerHTML = "";

								for (var i = 0; i < yearList.length; i++) {
									yearSelect.add(new Option(yearList[i] + yearSubfix, yearList[i]));
								}
							}

							// 작업중인 연도랑 같으면 생성된 휴가/결근만 리스트에 추가하고, 그렇지 않으면 생성한 연도의 리스트로 이동한다.
							if (workingYear == createdYear) {
								params.timeoff_id  = response.timeoff_id;
								params.create_date = response.create_date;

								var timeoffTbody = document.querySelector("aside.grid > div > table > tbody");
								$content$.timeoff.my.appendTimeoffRow(timeoffTbody, params, true).click();

								// 결재자가 본인만 있을 경우는 신청하면서 바로 결재된다.
								if ((approverIds.length == 1) && (params.sign_step == "1") && (params.applied_days != "0")) {
									usedDaysSpan.innerHTML = parseFloat(params.used_days) + parseFloat(params.applied_days);
								}
							} else {
								yearSelect.value = createdYear;
								$content$.timeoff.my.getTimeoffList(createdYear, response.timeoff_id);
							}

							$controller$.winup.close();
							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}

				var confirmRequestDays = false;

				if ((document.timeoffForm.timeoff_class.value == "leave") && (params.request_days == "1") && (timeoffStart != timeoffEnd)) {
					if (document.timeoffForm.time_marker1.value == "PM" && document.timeoffForm.time_marker2.value == "AM") {
						var dateUtils = $module$.date.Utils;
						var nextDate = dateUtils.toDate(dateUtils.parse(params.timeoff_start), 1);
						if (dateUtils.format(nextDate) != timeoffEnd) {
							confirmRequestDays = true;
						}
					} else {
						confirmRequestDays = true;
					}
				}

				if (confirmRequestDays) {
					$controller$.prompt.confirm("\ud734\uac00\uae30\uac04\uc774 1\uc77c\uc774 \ub9de\uc2b5\ub2c8\uae4c?", function(close) {  // 휴가기간이 1일이 맞습니까?
						executeAjax();
						close();
					}, function(close) {
						document.timeoffForm.timeoff_day.select();
						close();
					}, 2);
				} else {
					executeAjax();
				}
			}
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
		document.querySelector("aside.popup > ul > li > div").removeAttribute("class");
	}
}