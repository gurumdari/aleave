$content$.setting = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;
		var articleNode = document.querySelector("section > div.section > article");

		if (windowWidth > 736) {
			articleNode.style.height = (windowHeight - 139) + "px";  // 63 + 30 + 20 + 25
		} else {
			articleNode.removeAttribute("style");
		}
	},

	service: function() {
		window.addEventListener("resize", this.resize, false);
		this.resize();

		var articleId = this.conf.articleId;
		var isAdmin   = this.dataset.is_admin;
		var fieldsetClassSubfix = (isAdmin ? "7" : "4");

		if (articleId == null)  articleId = (isAdmin ? "/setting/system" : "/setting/personal");

		setArticleMenus(articleId, fieldsetClassSubfix);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};