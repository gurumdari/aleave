$content$.approval.line = {
	service: function() {
		var setApprovalLine = this.conf.setApprovalLine;

		document.querySelector("aside.popup article > div.popup > ul.submit > li > button").addEventListener("click", function(event) {
			var selectedLine = document.querySelector("aside.popup article > div.popup > form > fieldset > legend > label > input:checked");
			var selectedLineContainer = selectedLine.parentNode.parentNode.nextElementSibling;

			setApprovalLine(selectedLineContainer.innerHTML, selectedLine.value);
			$controller$.popup.close();
		}, false);
	}
}