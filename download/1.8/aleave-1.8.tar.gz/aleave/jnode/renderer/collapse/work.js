$content$.work = {
	service: function() {
		var articleId = this.conf.articleId;
		var isAdmin   = this.dataset.is_admin;

		if (articleId == null)  articleId = "/work/month";

		if (!isAdmin) {
			var waitingCount = this.dataset.waiting_count;
			var timeoffMenu  = document.querySelector("body > nav > ul > li > label > input[value='/timeoff'] + span");
			var outsideMenu  = document.querySelector("body > nav > ul > li > label > input[value='/outside'] + span");

			if (waitingCount.timeoff)  timeoffMenu.setAttribute("class", waitingCount.timeoff);
			else                       timeoffMenu.removeAttribute("class");

			if (waitingCount.outside)  outsideMenu.setAttribute("class", waitingCount.outside);
			else                       outsideMenu.removeAttribute("class");
		}

		setArticleMenus(articleId, "1");
	}
};