$content$.timeoff.year = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if (windowWidth > 736) {
			$controller$.grid.resize(null, windowHeight - 146);
		} else {
			$controller$.grid.removeHeight();
		}

		$controller$.grid.resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();

		var that        = this;
		var dataset     = this.dataset;
		var leaveBasic  = dataset.leave_basic;
		var posTypeList = dataset.positionTypeList;
		var posSortMap  = {};

		$jnode$.pushHistory(this.conf);

		var curYear  = this.dataset.cur_year.toString();
		var curMonth = this.dataset.cur_month.toString();
		var yearList = this.dataset.year_list;

		if (yearList.indexOf(curYear) < 0) {
			yearList.push(curYear);
			yearList = yearList.sort().reverse();
		}

		var yearSelect = document.querySelector("body > section > div.section > article > div.article > ul > li:first-child > select");

		for (var i = 0; i < yearList.length; i++) {
			yearSelect.add(new Option(yearList[i] + "\ub144", yearList[i]));  // 년
		}

		function lpad(sortIndex) {
			if (sortIndex < 10) {
				return "0" + sortIndex.toString();
			} else {
				return sortIndex.toString();
			}
		}

		for (var i = 0; i < posTypeList.length; i++) {
			var posList = posTypeList[i].list;

			for (var j = 0; j < posList.length; j++) {
				posSortMap[posList[j].position_id.toString()] = lpad(i) + lpad(j);
			}
		}

		$jnode$.requireController("grid", {caller:that.conf}).on(function() {
			$controller$.grid.service({
				sortable: true
			});

			var userTbody = document.querySelector("aside.grid > div > table > tbody");

			window.addEventListener("resize", that.resize, false);
			that.resize();

			function appendUserRow(userData) {
				var userId      = userData.user_id;
				var isRetiree   = (userId.indexOf("${") == 0);
				var retireeInfo = {};

				if (isRetiree)  retireeInfo = JSON.parse(userData.user_note);

				var row = document.createElement("tr");
				row.setAttribute("id", userId);
				userTbody.appendChild(row);

				var nameCell = row.insertCell(0);
				nameCell.appendChild(document.createTextNode(userData.user_name));
				nameCell.setAttribute("class", (userData.level_name ? userData.level_name : "member") + (isRetiree ? " retiree" : ""));

				var positionCell = row.insertCell(1);
				positionCell.appendChild(document.createTextNode(isRetiree ? retireeInfo.position_name : userData.position_name));
				// positionCell.setAttribute("id", userData.position_id);
				positionCell.setAttribute("sid", posSortMap[userData.position_id.toString()]);

				var orgCell = row.insertCell(2);
				orgCell.appendChild(document.createTextNode(isRetiree ? retireeInfo.org_name : userData.org_name));

				var entryCell = row.insertCell(3);
				entryCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(userData.entry_date), dateFormatter.DateStyle.MEDIUM)));
				entryCell.setAttribute("id", userData.entry_date);

				var quittingCell = row.insertCell(4);
				if (userData.quitting_date) {
					quittingCell.appendChild(document.createTextNode(dateFormatter.format($module$.date.Utils.parse(userData.quitting_date), dateFormatter.DateStyle.MEDIUM)));
					quittingCell.setAttribute("id", userData.quitting_date);
				}

				var cellIndex = 5;

				var fiscalLeaveCell = row.insertCell(cellIndex++);
				fiscalLeaveCell.setAttribute("id", userData.fiscal_used);
				fiscalLeaveCell.appendChild(document.createTextNode((userData.fiscal_used ? userData.fiscal_used : 0) + "/" + userData.fiscal_available));

				var entryLeave1 = "-";
				var entryLeave1Value = "-1";
				if (userData.entry_annual1 > 0) {
					entryLeave1Value = userData.entry_used1.toString();
					entryLeave1 = userData.entry_used1 + "/" + userData.entry_available1;
					entryLeave1 += (userData.entry_annual1 == 1 ? " (\uc785\uc0ac\ud574)" : (" (" + userData.entry_annual1 + "\ub144\ucc28)"));  // 입사해  // 년차
				}

				var entryLeaveCell1 = row.insertCell(cellIndex++);
				entryLeaveCell1.setAttribute("id", entryLeave1Value);
				entryLeaveCell1.appendChild(document.createTextNode(entryLeave1));

				var entries = userData.entry_date.split("-");
				var entryMonthDay = entries[1] + "-" + entries[2];
				var entryMonthDayCell = row.insertCell(cellIndex++);
				entryMonthDayCell.setAttribute("id", entryMonthDay);
				entryMonthDayCell.appendChild(document.createTextNode(parseInt(entries[1], 10) + "\uc6d4 " + parseInt(entries[2], 10) + "\uc77c"));  // 월  // 일

				var entryLeave2 = "-";
				var entryLeave2Value = "-1";
				if (userData.entry_annual2 == 1 || userData.entry_available2 != 0) {
					var entryLeave2Value = userData.entry_used2.toString();
					entryLeave2 = userData.entry_used2 + "/" + userData.entry_available2;
					entryLeave2 += (userData.entry_annual2 == 1 ? " (\uc785\uc0ac\ud574)" : (" (" + userData.entry_annual2 + "\ub144\ucc28)"));  // 입사해  // 년차
				}

				var entryLeaveCell2 = row.insertCell(cellIndex++);
				entryLeaveCell2.setAttribute("id", entryLeave2Value);
				entryLeaveCell2.appendChild(document.createTextNode(entryLeave2));

				row.addEventListener("click", function(event) {
					var selectedRow = userTbody.querySelector("tbody > tr.selected");
					if (selectedRow)  $jnode$.node.removeClass(selectedRow, "selected");

					$jnode$.node.addClass(this, "selected");
				}, false);
			}

			function getUserList(year) {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/timeoff.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  {
						command:     "getUserList",
						year:        year,
						month:       curMonth,
						leave_basic: leaveBasic
					},
					"success": function(response) {
						document.querySelector("aside.grid > ul > li > div > table > thead > tr:last-child > th:last-child").innerHTML = (curYear == year ? "~ \ud604\uc7ac\uae4c\uc9c0" : "~ \ub2e4\uc74c\ud574\uae4c\uc9c0");  // 현재까지  // 다음해까지
						$controller$.grid.clear("tbody");

						for (var i = 0; i < response.userList.length; i++) {
							appendUserRow(response.userList[i]);
						}

						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
			
			
			getUserList(yearSelect.value);

			yearSelect.addEventListener("change", function(event) {
				getUserList(this.value);
			}, false);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};