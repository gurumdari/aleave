$content$.setting.admin.add = {
	service: function() {
		var userTbody = document.querySelector("aside.grid > div > table > tbody");

		document.querySelector("aside.winup div.winup > form > ul.submit > li > button").addEventListener("click", function(event) {
			var alertMessage = null;
			var alertNode    = this.parentNode.previousElementSibling;

			var params = {
				command:       "addUser",
				user_name:     document.userForm.user_name.value.trim(),
				user_id:       document.userForm.user_id.value.trim(),
				user_password: document.userForm.user_password.value.trim(),
				user_note:     document.userForm.user_note.value.trim()
			};

			if (params.user_name == "") {
				alertMessage = "\uad00\ub9ac\uc790 \uc774\ub984\uc744 \uc785\ub825\ud574\uc8fc\uc138\uc694.";  // 관리자 이름을 입력해주세요.
				document.userForm.user_name.select();
			} else if (params.user_id == "") {
				alertMessage = "\uad00\ub9ac\uc790 ID\ub97c \uc785\ub825\ud574 \uc8fc\uc138\uc694.";  // 관리자 ID를 입력해 주세요.
				document.userForm.user_id.select();
			} else if (params.user_id == "-") {
				alertMessage = "\uad00\ub9ac\uc790 ID\ub294 \"-\"\uc77c \uc218 \uc5c6\uc2b5\ub2c8\ub2e4.";  // 관리자 ID는 \"-\"일 수 없습니다.
				document.userForm.user_id.select();
			} else if (!/^[\w|\.|\-]+$/g.test(params.user_id)) {
				alertMessage = "\uad00\ub9ac\uc790 ID\uc758 \ubb38\uc790\uc5f4\uc740 \uc601\ubb38, \uc22b\uc790, \ubc11\uc904(_), \ud558\uc774\ud508(-), \uc810(.)\ub9cc \uac00\ub2a5\ud569\ub2c8\ub2e4.";  // 관리자 ID의 문자열은 영문, 숫자, 밑줄(_), 하이픈(-), 점(.)만 가능합니다.
				document.userForm.user_id.select();
			} else if (params.user_id.length > 30) {
				alertMessage = "\uad38\ub9ac\uc790 ID\ub294 \ucd5c\ub300 30\uc790\uae4c\uc9c0\ub9cc \uac00\ub2a5\ud569\ub2c8\ub2e4.";  // 괸리자 ID는 최대 30자까지만 가능합니다.
				document.userForm.user_id.select();
			} else if (params.user_password == "") {
				alertMessage = "\ube44\ubc00\ubc88\ud638\ub97c \uc785\ub825\ud574 \uc8fc\uc138\uc694.";
				document.userForm.user_password.select();
			} else if (document.userForm.user_password.value != document.userForm.confirm_password.value) {
				alertMessage = "\ube44\ubc00\ubc88\ud638\uc640 \ube44\ubc00\ubc88\ud638 \ud655\uc778\uc758 \uac12\uc774 \ub2e4\ub985\ub2c8\ub2e4.";  // 비밀번호와 비밀번호 확인의 값이 다릅니다.
				document.userForm.confirm_password.select();
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						$content$.setting.admin.appendUserRow(userTbody, params);
						$controller$.grid.clear("thead");
						$controller$.grid.moveBottom();
						userTbody.lastElementChild.click();

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error, [
							{"code":"409", "message":"-" , "callback":function() { alertNode.innerHTML = "\uc774\ubbf8 \uc0ac\uc6a9\uc911\uc778 ID\uc785\ub2c8\ub2e4. \ub2e4\ub978 \uac12\uc744 \uc785\ub825\ud574\uc8fc\uc138\uc694."; document.userForm.user_id.select(); }}  // 이미 사용중인 ID입니다. 다른 값을 입력해주세요.
						]);

						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.userForm.user_name.focus();
	}
};