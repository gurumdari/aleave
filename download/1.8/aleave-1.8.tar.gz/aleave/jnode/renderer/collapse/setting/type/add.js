$content$.setting.type.add = {
	service: function() {
		var that = this;

		$jnode$.requireControllers(["dataframe", "winup#dataframe"], {caller:that.conf}, function() {
			$controller$.dataframe.service({
				fixedLayout: true,
				names: [ "\uc9c1\uae09 \uc774\ub984" ],  // 직급 이름
				height: 157
			});

			var positionTypeContainer = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div.pos_type");
			var positionContainer     = document.querySelector("div.section > article > div.article > ul > li:last-child > div.pos");
			var selectedInput         = positionTypeContainer.querySelector("div.pos_type > label > input:checked");
			var siblingId             = selectedInput.value;

			document.typeForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
				var params = {
					command:       "addPositionType",
					position_type: selectedInput.value,
					sibling_id:    siblingId,
					type_name:     document.typeForm.type_name.value.trim(),
					where_to:      document.typeForm.where_to.value
				}

				var positionNames = [];
				var positionValues = $controller$.dataframe.getColumnVector();
				if (positionValues != null) {
					positionNames = positionValues[0].filter(function(entry) { return entry != "" });
				}

				var alertMessage = null;

				if (params.type_name == "") {
					alertMessage = "\uc9c1\uae09 \ud0c0\uc785\uc744 \uc785\ub825\ud574\uc8fc\uc138\uc694.";  // 직급 타입을 입력해주세요.
					document.typeForm.type_name.select();
				} else if (positionNames.length == 0) {
					alertMessage = "\uc9c1\uae09\uc744 \ucd5c\uc18c \ud558\ub098 \uc774\uc0c1 \ud3ec\ud568\ud574\uc57c \ud569\ub2c8\ub2e4.";  // 직급을 최소 하나 이상 포함해야 합니다.
				} else {
					params.position_names = JSON.stringify(positionNames);
				}

				if (alertMessage) {
					this.parentNode.previousElementSibling.innerHTML = alertMessage;
				} else {
					$controller$.loading.show();

					$jnode$.ajax.service({
						"url":      "/ajax/position.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params": params,
						"success": function(response) {
							params.type_id = response.type_id;
							$content$.setting.position.appendPositionType(positionTypeContainer, positionContainer, params, selectedInput.parentNode);

							positionTypeContainer.querySelector("div.pos_type > label > input[value='" + params.type_id + "']").click();

							$controller$.loading.hide();
							$controller$.winup.close();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			}, false);
		});

		document.typeForm.type_name.focus();
	}
};