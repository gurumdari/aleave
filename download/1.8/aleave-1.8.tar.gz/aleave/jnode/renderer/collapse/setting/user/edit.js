$content$.setting.user.edit = {
	resize: function() {
		var windowWidth = window.innerWidth;

		if (windowWidth > 736) {
			$controller$.popup.resize(246, 246);
		} else {
			$controller$.popup.resize(280, 335);
		}
	},

	service: function() {
		var posTypeList      = $content$.setting.user.dataset.positionTypeList;
		var posTypeMap       = $content$.setting.user.posTypeMap;
		var userNameInput    = document.userForm.user_name;
		var userContactInput = document.userForm.user_contact;
		var userAddressText  = document.userForm.user_address;
		var posTypeSelect    = document.userForm.pos_type;
		var positionSelect   = document.userForm.user_position;
		var entryDateInput   = document.userForm.entry_date;
		var okButton         = document.userForm.querySelector("form > ul.submit > li > button:first-child");
		var retireButton     = okButton.nextElementSibling;

		var userTbody    = document.querySelector("aside.grid > div > table > tbody");
		var userRow      = userTbody.querySelector("tbody > tr.selected");
		var userNameCell = userRow.firstElementChild;
		var userIdCell   = userNameCell.nextElementSibling;
		var contactCell  = userIdCell.nextElementSibling;
		var positionCell = contactCell.nextElementSibling;
		var entryCell    = positionCell.nextElementSibling;

		// user_name
		userNameInput.value = userNameCell.textContent;

		// user_id
		var userId = userIdCell.textContent;
		userNameInput.parentNode.parentNode.nextElementSibling.lastElementChild.innerHTML = $jnode$.escapeXML(userId);

		// user_contact
		userContactInput.value = contactCell.textContent;

		// user_address
		userAddressText.value = userRow.getAttribute("title").replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");

		userAddressText.addEventListener("keydown", function(event) {
			var keyCode = event.keyCode || event.which;

			if(keyCode == 13) {
				event.preventDefault();
			}
		}, false);

		userAddressText.addEventListener("paste", function(event) {
			window.setTimeout(function() {
				userAddressText.value = userAddressText.value.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");
			});
		}, false);

		// user_position
		var oldPositionTypeIndex = parseInt(positionCell.getAttribute("sid").substring(0, 2), 10);
		var oldPositionTypeId    = "";
		var oldPositionId        = positionCell.getAttribute("id");

		for (var i = 0; i < posTypeList.length; i++) {
			posTypeSelect.add(new Option(posTypeList[i].type_name, posTypeList[i].type_id));

			if (i == oldPositionTypeIndex)  oldPositionTypeId = posTypeList[i].type_id;
		}

		function changePosList(posType) {
			var posList = posTypeMap[posType];

			positionSelect.innerHTML = "";
			for (var i = 0; i < posList.length; i++) {
				positionSelect.add(new Option(posList[i].position_name, posList[i].position_id));
			}

			positionSelect.value = posList[posList.length - 1].position_id;
		}

		posTypeSelect.value = oldPositionTypeId;
		changePosList(oldPositionTypeId);

		positionSelect.value = oldPositionId;

		// entry_date
		var oldEntryDate = entryCell.getAttribute("id");
		entryDateInput.value = dateFormatter.format($module$.date.Utils.parse(oldEntryDate), dateFormatter.DateStyle.LONG);
		entryDateInput.parentNode.setAttribute("value", oldEntryDate);

		window.addEventListener("resize", this.resize, false);

		posTypeSelect.addEventListener("change", function(event) {
			changePosList(this.value);
		}, false);

		function drawCalendar(buttonTitle, isoValue) {
			var date         = null;
			var windowWidth  = window.innerWidth;
			var popupDomain  = $jnode$.controller.getDomain("popup");
			var popupContent = popupDomain.querySelector($jnode$.selector.controller.popup.content);
			popupContent.innerHTML = "<DIV class=\"calendar\"></DIV><UL class=\"submit\"><LI></LI><LI><BUTTON>" + buttonTitle + "</BUTTON></LI></UL>";

			$controller$.popup.open({
				width:  (windowWidth > 736 ? 246 : 280),
				height: (windowWidth > 736 ? 246 : 335)
			});

			if (isoValue) {
				date = $module$.date.Utils.parse(isoValue);
			} else {
				date = new Date();
				isoValue = $module$.date.Utils.format(date);
			}

			var dateCalendar = popupDomain.querySelector("aside.popup article > div.calendar");
			var dateLi       = dateCalendar.nextElementSibling.firstElementChild;

			dateLi.innerHTML = $jnode$.escapeXML(dateFormatter.format(date, dateFormatter.DateStyle.LONG));
			dateLi.setAttribute("value", "iso:" + isoValue);

			displayCalendar(date, dateLi, dateCalendar, isoValue);

			dateLi.addEventListener("click", function() {
				var selectedIsoValue = this.getAttribute("value").substring(4);
				displayCalendar(selectedIsoValue, this, dateCalendar, selectedIsoValue);
			}, false);

			return dateLi;
		}

		function dateSelectEvent(dateInput) {
			var inputContainer = dateInput.parentNode;
			var isoValue       = inputContainer.getAttribute("value");
			var dateLi         = drawCalendar("\ud655\uc778", isoValue);  // 확인

			dateLi.nextElementSibling.firstElementChild.addEventListener("click", function(event) {
				var selectedIsoValue = dateLi.getAttribute("value").substring(4);
				inputContainer.setAttribute("value", selectedIsoValue);
				inputContainer.firstElementChild.value = dateFormatter.format($module$.date.Utils.parse(selectedIsoValue), dateFormatter.DateStyle.LONG);

				$controller$.popup.close();
			}, false);
		}

		entryDateInput.addEventListener("click", function(event) {
			dateSelectEvent(this);
		}, false);

		// 사용자 정보 변경
		okButton.addEventListener("click", function(event) {
			var alertMessage = null;
			var alertNode    = this.parentNode.previousElementSibling;

			var params = {
				command:       "updateUser",
				user_name:     userNameInput.value.trim(),
				user_id:       userId,
				user_contact:  userContactInput.value.trim(),
				user_address:  userAddressText.value.trim(),
				position_id:   positionSelect.value,
				position_name: positionSelect.options[positionSelect.selectedIndex].text,
				entry_date:    entryDateInput.parentNode.getAttribute("value")
			};

			if (params.user_name == "") {
				alertMessage = "\uc0ac\uc6a9\uc790 \uc774\ub984\uc744 \uc785\ub825\ud574\uc8fc\uc138\uc694.";  // 사용자 이름을 입력해주세요.
				userNameInput.select();
			} else if (params.entry_date == null) {
				alertMessage = "\uc785\uc0ac\uc77c\uc744 \uc120\ud0dd\ud574\uc8fc\uc138\uc694.";  // 입사일을 선택해주세요.
				entryDateInput.focus();
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						userNameCell.firstChild.nodeValue = params.user_name;
						contactCell.firstChild.nodeValue  = params.user_contact;

						positionCell.firstChild.nodeValue = params.position_name;
						positionCell.setAttribute("id", params.position_id);
						positionCell.setAttribute("sid", $content$.setting.user.posSortMap[params.position_id]);

						entryCell.firstChild.nodeValue = dateFormatter.format($module$.date.Utils.parse(params.entry_date), dateFormatter.DateStyle.MEDIUM);
						entryCell.setAttribute("id", params.entry_date);

						if (params.user_address)  userRow.setAttribute("title", params.user_address);
						else                      userRow.removeAttribute("title");

						$controller$.grid.clear("thead");

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		// 퇴사처리
		retireButton.addEventListener("click", function(event) {
			var dateLi = drawCalendar("\ud1f4\uc0ac\uc77c \uc9c0\uc815");  // 퇴사일 지정

			dateLi.nextElementSibling.firstElementChild.addEventListener("click", function(event) {
				$controller$.prompt.confirm(dateLi.innerHTML + "\ubd80\ub85c \ud1f4\uc0ac \ucc98\ub9ac\ud558\uaca0\uc2b5\ub2c8\uae4c?", function(close) {  // 부로 퇴사 처리하겠습니까?
					$controller$.loading.show();

					var quittingDate = dateLi.getAttribute("value").substring(4);

					$jnode$.ajax.service({
						"url":      "/ajax/user.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":  {
							command:       "retireUser",
							user_id:       userId,
							quitting_year: quittingDate.split("-")[0],
							quitting_date: quittingDate,
							ckeck_count:   (userTbody.children.length > 1) ? "false" : "true"
						},
						"success": function(response) {
							userTbody.removeChild(userRow);

							var managerSelectButton = document.querySelector("div.section > article > div.article > fieldset > button:first-child");
							managerSelectButton.disabled = true;
							managerSelectButton.firstElementChild.innerHTML = "\ubd80\uc11c\uc7a5\uc73c\ub85c";  // 부서장으로

							var userEditButton = document.querySelector("div.section > article > div.article > fieldset > button:nth-child(3)");
							userEditButton.disabled = true;
							userEditButton.nextElementSibling.disabled = true;

							if (response.start_id) {
								startId = response.start_id;
								$controller$.grid.clear("thead");
							}

							$controller$.winup.close();
							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});

					$controller$.popup.close();
					close();
				}, null, 2);
			}, false);
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};