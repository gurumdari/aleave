$content$.setting.org.add = {
	service: function() {
		var that = this;

		document.orgForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var params = {
				command:    "addOrg",
				org_name:   document.orgForm.org_name.value,
				org_parent: that.conf.org_parent
			};

			var alertMessage    = null;

			if (params.org_name == "") {
				alertMessage = "\ubd80\uc11c \uc774\ub984\uc744 \uc785\ub825\ud574 \uc8fc\uc138\uc694.";  // 부서 이름을 입력해 주세요.
				document.orgForm.org_name.focus();
			}
			
			if (alertMessage) {
				document.orgForm.querySelector("form > ul.submit > li.alert").innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/org.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						params.org_id = response.org_id
						$controller$.tree.append(params, params.org_parent);

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.orgForm.org_name.focus();
	}
};