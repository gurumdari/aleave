$content$.setting.upgrade = {
	service: function() {
		document.querySelector("aside.winup article > div.winup > form > ul > li:last-child > button").addEventListener("click", function(event) {
			var formData = new FormData(document.upgradeForm);

			if (formData.get("auz").name.search(/\.auz$/i) < 0) {
				this.parentNode.previousElementSibling.innerHTML = "AUZ \ud30c\uc77c\uc744 \uc120\ud0dd\ud574\uc8fc\uc138\uc694.";  // AUZ 파일을 선택해주세요.
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/upgrade.json",
					"method":   "POST",
					"datatype": "json",
					"headers":  {
						"Accept": "application/json"
					},
					"params":  formData,
					"success": function(response) {
						handleHash("#article:/setting/about");
						$controller$.winup.close();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);
	}
};