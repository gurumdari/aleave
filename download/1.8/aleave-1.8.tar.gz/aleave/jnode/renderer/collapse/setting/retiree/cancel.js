$content$.setting.retiree.cancel = {
	service: function() {
		var posTypeList      = this.dataset.positionTypeList;
		var posTypeMap       = {};
		var typeCount        = posTypeList.length;
		var userNameInput    = document.userForm.user_name;
		var userIdInput      = document.userForm.user_id;
		var userContactInput = document.userForm.user_contact;
		var userAddressInput = document.userForm.user_address;
		var orgIdInput       = document.userForm.org_id;
		var orgNameInput     = document.userForm.org_name;
		var posTypeSelect    = document.userForm.pos_type;
		var positionSelect   = document.userForm.user_position;
		var okButton         = document.userForm.querySelector("form > ul.submit > li > button");

		var userTbody    = document.querySelector("aside.grid > div > table > tbody");
		var userRow      = userTbody.querySelector("tbody > tr.selected");
		var userNameCell = userRow.firstElementChild;
		var userIdCell   = userNameCell.nextElementSibling;
		var contactCell  = userIdCell.nextElementSibling;
		var orgCell      = contactCell.nextElementSibling;
		var positionCell = orgCell.nextElementSibling;

		// retiree_id
		var retireeId = userRow.getAttribute("id");
		var history   = userRow.getAttribute("history");
		if (history == "[]")  history = null;

		// user_name
		userNameInput.value = userNameCell.textContent;

		// user_id
		userIdInput.value = userIdCell.textContent;

		// user_contact
		userContactInput.value = contactCell.textContent;

		// user_address
		var userAddress = userRow.getAttribute("title");
		if (userAddress)  userAddressInput.value = userAddress;

		// org_id
		orgIdInput.value   = orgCell.getAttribute("id");
		orgNameInput.value = orgCell.getAttribute("value");

		// position
		function changePosList(posType) {
			var posList = posTypeMap[posType];

			positionSelect.innerHTML = "";
			for (var i = 0; i < posList.length; i++) {
				positionSelect.add(new Option(posList[i].position_name, posList[i].position_id));
			}
		}

		for (var i = 0; i < typeCount; i++) {
			posTypeMap[posTypeList[i].type_id.toString()] = posTypeList[i].list;
			posTypeSelect.add(new Option(posTypeList[i].type_name, posTypeList[i].type_id));
		}

		posTypeSelect.addEventListener("change", function(event) {
			changePosList(this.value);
		}, false);

		var typeId = positionCell.getAttribute("tid");
		posTypeSelect.value = typeId;
		changePosList(typeId);
		positionSelect.value = positionCell.getAttribute("id");

		orgNameInput.addEventListener("click", function(event) {
			document.querySelector("aside.popup > ul > li > div").removeAttribute("class");

			var windowWidth = window.innerWidth;
			var options = {
				useLoading: true,
				height:     229,
				renderer:   "-j"
			};
			
			if (windowWidth > 400)  options.width = 360;
			else                    options.widthP = 100;

			$jnode$.requireContent("popup", "/setting/org/select", options);
		}, false);

		okButton.addEventListener("click", function(event) {
			var alertMessage = null;
			var alertNode    = this.parentNode.previousElementSibling;

			var params = {
				command:      "cancelRetiree",
				user_name:    userNameInput.value.trim(),
				user_id:      userIdInput.value.trim(),
				user_contact: userContactInput.value.trim(),
				user_address: userAddressInput.value.trim(),
				org_id:       orgIdInput.value,
				position_id:  positionSelect.value,
				user_note:    history,
				retiree_id:   retireeId,
			};

			if (params.user_name == "") {
				alertMessage = "\uc0ac\uc6a9\uc790 \uc774\ub984\uc744 \uc785\ub825\ud574\uc8fc\uc138\uc694.";  // 사용자 이름을 입력해주세요.
				document.userForm.user_name.select();
			} else if (params.user_id == "") {
				alertMessage = "\uc0ac\uc6a9\uc790 ID\ub97c \uc785\ub825\ud574 \uc8fc\uc138\uc694.";  // 사용자 ID를 입력해 주세요.
				document.userForm.user_id.select();
			} else if (params.userId == "-") {
				alertMessage = "\uc0ac\uc6a9\uc790 ID\ub294 \"-\"\uc77c \uc218 \uc5c6\uc2b5\ub2c8\ub2e4.";  // 사용자 ID는 \"-\"일 수 없습니다.
				document.userForm.user_id.select();
			} else if (!/^[\w|\.|\-]+$/g.test(params.user_id)) {
				alertMessage = "\uc0ac\uc6a9\uc790 ID\uc758 \ubb38\uc790\uc5f4\uc740 \uc601\ubb38, \uc22b\uc790, \ubc11\uc904(_), \ud558\uc774\ud508(-), \uc810(.)\ub9cc \uac00\ub2a5\ud569\ub2c8\ub2e4.";  // 사용자 ID의 문자열은 영문, 숫자, 밑줄(_), 하이픈(-), 점(.)만 가능합니다.
				document.userForm.user_id.select();
			} else if (params.user_id.length > 30) {
				alertMessage = "\uc0ac\uc6a9\uc790 ID\ub294 \ucd5c\ub300 30\uc790\uae4c\uc9c0\ub9cc \uac00\ub2a5\ud569\ub2c8\ub2e4.";  // 사용자 ID는 최대 30자까지만 가능합니다.
				document.userForm.user_id.select();
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						userTbody.removeChild(userRow);
						var reenteringButton = document.querySelector("div.section > article > div.article > fieldset > button:first-child");
						var cancelButton     = reenteringButton.nextElementSibling;
						var deleteButton     = cancelButton.nextElementSibling;

						reenteringButton.disabled = true;
						cancelButton.disabled     = true;
						deleteButton.disabled     = true;

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error, [
							{"code":"409", "message":"-" , "callback":function() { alertNode.innerHTML = "\ud1f4\uc0ac \ucc98\ub9ac\ub41c \uae30\uac04\uc911\uc5d0 \ud574\ub2f9 ID\uac00 \uc774\ubbf8 \ub4f1\ub85d\ub418\uc5c8\uc2b5\ub2c8\ub2e4."; document.userForm.user_id.select(); }}  // 퇴사 처리된 기간중에 해당 ID가 이미 등록되었습니다.
						]);

						$controller$.loading.hide();
					}
				});
			}
		}, false);
	}
};