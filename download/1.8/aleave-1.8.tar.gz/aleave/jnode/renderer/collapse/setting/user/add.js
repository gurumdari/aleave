$content$.setting.user.add = {
	resize: function() {
		var windowWidth = window.innerWidth;

		if (windowWidth > 736) {
			$controller$.popup.resize(246, 246);
		} else {
			$controller$.popup.resize(280, 335);
		}
	},

	service: function() {
		var orgId            = this.conf.org_id;
		var initPositionType = this.dataset.init_position_type;
		var addressText      = document.userForm.user_address;
		var posTypeList      = $content$.setting.user.dataset.positionTypeList;
		var posTypeMap       = $content$.setting.user.posTypeMap;
		var posTypeSelect    = document.userForm.pos_type;
		var positionSelect   = document.userForm.user_position;
		var entryDateInput   = document.userForm.entry_date;
		var userTbody        = document.querySelector("aside.grid > div > table > tbody");

		addressText.addEventListener("keydown", function(event) {
			var keyCode = event.keyCode || event.which;

			if(keyCode == 13) {
				event.preventDefault();
			}
		}, false);

		addressText.addEventListener("paste", function(event) {
			window.setTimeout(function() {
				addressText.value = addressText.value.replace(/\r\n/g, "\n").replace(/\r/g, "\n").replace(/\n/g, " ");
			});
		}, false);

		for (var i = 0; i < posTypeList.length; i++) {
			posTypeSelect.add(new Option(posTypeList[i].type_name, posTypeList[i].type_id));
		}

		function changePosList(posType) {
			var posList = posTypeMap[posType];

			positionSelect.innerHTML = "";
			for (var i = 0; i < posList.length; i++) {
				positionSelect.add(new Option(posList[i].position_name, posList[i].position_id));
			}

			positionSelect.value = posList[posList.length - 1].position_id;
		}

		if (posTypeMap[initPositionType] == null) {
			initPositionType = posTypeList[posTypeList.length - 1].type_id;
		}

		posTypeSelect.value = initPositionType;
		changePosList(initPositionType);

		document.userForm.user_name.focus();

		window.addEventListener("resize", this.resize, false);

		posTypeSelect.addEventListener("change", function(event) {
			changePosList(this.value);
		}, false);

		function dateSelectEvent(dateInput) {
			var windowWidth  = window.innerWidth;
			var popupDomain  = $jnode$.controller.getDomain("popup");
			var popupContent = popupDomain.querySelector($jnode$.selector.controller.popup.content);
			popupContent.innerHTML = "<DIV class=\"calendar\"></DIV><UL class=\"submit\"><LI></LI><LI><BUTTON>확인</BUTTON></LI></UL>";

			$controller$.popup.open({
				width:  (windowWidth > 736 ? 246 : 280),
				height: (windowWidth > 736 ? 246 : 335)
			});

			var inputContainer = dateInput.parentNode;
			var date           = null;
			var isoValue       = inputContainer.getAttribute("value");

			if (isoValue) {
				date = $module$.date.Utils.parse(isoValue);
			} else {
				date = new Date();
				isoValue = $module$.date.Utils.format(date);
			}

			var dateCalendar = popupDomain.querySelector("aside.popup article > div.calendar");
			var dateLi       = dateCalendar.nextElementSibling.firstElementChild;

			dateLi.innerHTML = $jnode$.escapeXML(dateFormatter.format(date, dateFormatter.DateStyle.LONG));
			dateLi.setAttribute("value", "iso:" + isoValue);

			displayCalendar(date, dateLi, dateCalendar, isoValue);

			dateLi.addEventListener("click", function() {
				var selectedIsoValue = this.getAttribute("value").substring(4);
				displayCalendar(selectedIsoValue, this, dateCalendar, selectedIsoValue);
			}, false);

			dateLi.nextElementSibling.firstElementChild.addEventListener("click", function(event) {
				var selectedIsoValue = dateLi.getAttribute("value").substring(4);
				inputContainer.setAttribute("value", selectedIsoValue);
				inputContainer.firstElementChild.value = dateFormatter.format($module$.date.Utils.parse(selectedIsoValue), dateFormatter.DateStyle.LONG);

				$controller$.popup.close();
			}, false);
		}

		entryDateInput.addEventListener("click", function(event) {
			dateSelectEvent(this);
		}, false);

		document.querySelector("aside.winup div.winup > form > ul.submit > li > button").addEventListener("click", function(event) {
			var alertMessage = null;
			var alertNode    = this.parentNode.previousElementSibling;

			var params = {
				command:       "addUser",
				user_name:     document.userForm.user_name.value.trim(),
				user_id:       document.userForm.user_id.value.trim(),
				user_password: document.userForm.user_password.value.trim(),
				user_contact:  document.userForm.user_contact.value.trim(),
				user_address:  addressText.value.trim(),
				org_id:        orgId,
				position_id:   positionSelect.value,
				position_name: positionSelect.options[positionSelect.selectedIndex].text,
				entry_date:    entryDateInput.parentNode.getAttribute("value")
			};

			if (params.user_name == "") {
				alertMessage = "\uc0ac\uc6a9\uc790 \uc774\ub984\uc744 \uc785\ub825\ud574\uc8fc\uc138\uc694.";  // 사용자 이름을 입력해주세요.
				document.userForm.user_name.select();
			} else if (params.user_id == "") {
				alertMessage = "\uc0ac\uc6a9\uc790 ID\ub97c \uc785\ub825\ud574 \uc8fc\uc138\uc694.";  // 사용자 ID를 입력해 주세요.
				document.userForm.user_id.select();
			} else if (params.user_id == "-") {
				alertMessage = "\uc0ac\uc6a9\uc790 ID\ub294 \"-\"\uc77c \uc218 \uc5c6\uc2b5\ub2c8\ub2e4.";  // 사용자 ID는 \"-\"일 수 없습니다.
				document.userForm.user_id.select();
			} else if (!/^[\w|\.|\-]+$/g.test(params.user_id)) {
				alertMessage = "\uc0ac\uc6a9\uc790 ID\uc758 \ubb38\uc790\uc5f4\uc740 \uc601\ubb38, \uc22b\uc790, \ubc11\uc904(_), \ud558\uc774\ud508(-), \uc810(.)\ub9cc \uac00\ub2a5\ud569\ub2c8\ub2e4.";  // 사용자 ID의 문자열은 영문, 숫자, 밑줄(_), 하이픈(-), 점(.)만 가능합니다.
				document.userForm.user_id.select();
			} else if (params.user_id.length > 30) {
				alertMessage = "\uc0ac\uc6a9\uc790 ID\ub294 \ucd5c\ub300 30\uc790\uae4c\uc9c0\ub9cc \uac00\ub2a5\ud569\ub2c8\ub2e4.";  // 사용자 ID는 최대 30자까지만 가능합니다.
				document.userForm.user_id.select();
			} else if (params.user_password == "") {
				alertMessage = "\ube44\ubc00\ubc88\ud638\ub97c \uc785\ub825\ud574 \uc8fc\uc138\uc694.";  // 비밀번호를 입력해 주세요.
				document.userForm.user_password.select();
			} else if (document.userForm.user_password.value != document.userForm.confirm_password.value) {
				alertMessage = "\ube44\ubc00\ubc88\ud638\uc640 \ube44\ubc00\ubc88\ud638 \ud655\uc778\uc758 \uac12\uc774 \ub2e4\ub985\ub2c8\ub2e4.";  // 비밀번호와 비밀번호 확인의 값이 다릅니다.
				document.userForm.confirm_password.select();
			} else if (params.entry_date == null) {
				alertMessage = "\uc785\uc0ac\uc77c\uc744 \uc120\ud0dd\ud574\uc8fc\uc138\uc694.";  // 입사일을 선택해주세요.
				entryDateInput.focus();
			}

			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						$content$.setting.user.appendUserRow(userTbody, params);
						$controller$.grid.clear("thead");
						$controller$.grid.moveBottom();
						userTbody.lastElementChild.click();

						startId = "/timeoff";

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error, [
							{"code":"409", "message":"-" , "callback":function() { alertNode.innerHTML = "\uc774\ubbf8 \uc0ac\uc6a9\uc911\uc778 \uc0ac\uc6a9\uc790 ID\uc785\ub2c8\ub2e4. \ub2e4\ub978 \uac12\uc744 \uc785\ub825\ud574\uc8fc\uc138\uc694."; document.userForm.user_id.select(); }}  // 이미 사용중인 사용자 ID입니다. 다른 값을 입력해주세요.
						]);

						$controller$.loading.hide();
					}
				});
			}
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};