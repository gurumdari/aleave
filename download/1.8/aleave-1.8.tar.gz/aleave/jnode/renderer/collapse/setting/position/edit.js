$content$.setting.position.edit = {
	service: function() {
		var positionContainer = document.querySelector("div.section > article > div.article > ul > li:last-child > div.pos");
		var selectedInput     = positionContainer.querySelector("div.pos > label > input:checked");
		var selectedSpan      = selectedInput.nextElementSibling;
		var positionId        = selectedInput.value;

		document.positionForm.position_name.value = selectedSpan.firstChild.nodeValue;

		document.positionForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var params = {
				command:       "updatePosition",
				position_id:   positionId,
				position_name: document.positionForm.position_name.value.trim()
			}

			if (params.position_name) {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/position.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params": params,
					"success": function(response) {
						selectedSpan.firstChild.nodeValue = params.position_name;

						$controller$.loading.hide();
						$controller$.winup.close();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			} else {
				this.parentNode.previousElementSibling.innerHTML = "\uc9c1\uae09 \uc774\ub984\uc744 \uc785\ub825\ud574\uc8fc\uc138\uc694.";  // 직급 이름을 입력해주세요.
				document.positionForm.position_name.select();
			}
		}, false);
	}
};