$content$.setting.org.select = {
	service: function() {
		var that = this;

		$jnode$.requireController("tree", {caller:that.conf}).on(function() {
			var orgDatas      = that.dataset.orgDatas;
			var orgLi         = document.querySelector("aside.winup article > div.winup > ul:last-child > li:first-child");
			var cotrollerName = "winup";

			if (orgLi == null) {
				orgLi = document.querySelector("aside.popup article > div.popup > ul:last-child > li:first-child");
				cotrollerName = "popup";
			}

			$jnode$.node.addClass(orgLi.parentNode.parentNode, $jnode$.device.type);

			function setTreeText(entrySet) {
				var textDiv = document.createElement("div");
				textDiv.setAttribute("class", (entrySet.org_parent ? "org" : "company"));
				textDiv.appendChild(document.createTextNode(entrySet.org_name));

				return textDiv;
			}

			function setTreeList(entrySet) {
				var list = entrySet.sub_org;
				return ((list && list.length) ? list : null);
			}

			function addTreeClickListener(textNode, entrySet) {
				var selectedNode = document.querySelector("aside.tree.org ul > li > span.selected");
				if (selectedNode) {
					selectedNode.removeAttribute("class");
				}

				textNode.setAttribute("class", "selected");
				orgLi.innerHTML = $jnode$.escapeXML(entrySet.org_name);
			}

			$controller$.tree.service({
				datas:     orgDatas,
				id:        function(entrySet) { return entrySet.org_id; },
				text:      setTreeText,
				list:      setTreeList,
				click:     addTreeClickListener,
				unfoldAll: true,
				height:    187
			});

			orgLi.nextElementSibling.firstElementChild.addEventListener("click", function(event) {
				document.userForm.org_id.value   = document.querySelector("aside.tree.org ul > li > span.selected").parentNode.parentNode.getAttribute("id");
				document.userForm.org_name.value = $jnode$.escapeXML(orgLi.innerHTML);
				$controller$[cotrollerName].close();
			}, false);

			$controller$.tree.click(document.userForm.org_id.value);
		});
	}
};