$content$.user.select = {
	service: function() {
		var that = this;
		var controllerDiv = document.querySelector("aside.winup article > div[id='/user/select']");
		var cotrollerName = "winup";

		if (controllerDiv == null) {
			controllerDiv = document.querySelector("aside.popup article > div[id='/user/select']");
			cotrollerName = "popup";
		}

		var userDiv = controllerDiv.querySelector("div[class='" + cotrollerName + "'] > ul:last-child > li:first-child > div");

		$jnode$.node.addClass(controllerDiv, $jnode$.device.type);

		$jnode$.requireController("tree", {caller:that.conf}).on(function() {
			function setTreeText(entrySet) {
				var textDiv = document.createElement("div");
				textDiv.setAttribute("class", entrySet.type);
				textDiv.appendChild(document.createTextNode(entrySet.name));

				if (entrySet.type == "user") {
					if (entrySet.level == "5")  $jnode$.node.addClass(textDiv, "manager");

					textDiv.appendChild(document.createTextNode(" (" + entrySet.position_name + ")"));
				} else {
					textDiv.appendChild(document.createTextNode(" "));

					var orgSpan = document.createElement("span");
					orgSpan.setAttribute("class", "count");
					orgSpan.appendChild(document.createTextNode("(" + entrySet.org_count + ", " + entrySet.user_count + ")"));
					textDiv.appendChild(orgSpan);
				}

				return textDiv;
			}

			function setTreeList(entrySet) {
				if (entrySet.org_count + entrySet.user_count == 0)  return null;
				else                                                return [];
			}

			function addTreeClickListener(textNode, entrySet) {
				if (entrySet.type == "user") {
					var selectedUser = document.querySelector("aside.tree.org ul > li:last-child > span.checked");
					if (selectedUser)  selectedUser.removeAttribute("class");

					textNode.setAttribute("class", "checked");
					userDiv.innerHTML = entrySet.name + " (" + entrySet.position_name + ") @ " + entrySet.org_name;
					userDiv.setAttribute("id", entrySet.id);
				} else {
					$controller$.tree.toggle(entrySet.id);
				}
			}

			$controller$.tree.service({
				datas: that.dataset.orgDatas,
				text:  setTreeText,
				list:  setTreeList,
				click: addTreeClickListener,
				retrieve: {
					url: "/ajax/org.json",
					method: "POST",
					params: {
						command: "getOrgUserList"
					},
					loading: {
						show: $controller$.loading.show,
						hide: $controller$.loading.hide
					}
				},
				height: 258
			});

			var okButton    = userDiv.parentNode.nextElementSibling.firstElementChild;
			var clearButton = okButton.nextElementSibling;

			okButton.addEventListener("click", function(event) {
				var userId = userDiv.getAttribute("id");

				if (userId) {
					var userInput = document.querySelector("input.popup[type='text'][name='" + that.dataset.input_name + "']");

					userInput.parentNode.setAttribute("id", userId);
					userInput.value = $jnode$.escapeXML(userDiv.innerHTML);
					$controller$[cotrollerName].close();
				}
			}, false);

			clearButton.addEventListener("click", function(event) {
				var userInput = document.querySelector("input.popup[type='text'][name='" + that.dataset.input_name + "']");

				userInput.parentNode.removeAttribute("id");
				userInput.value = "";
				$controller$[cotrollerName].close();
			}, false);
		});
	}
};