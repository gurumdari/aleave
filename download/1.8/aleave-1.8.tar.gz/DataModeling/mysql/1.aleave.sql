/*
DROP TABLE setting;
DROP TABLE code;
DROP TABLE usr;
DROP TABLE pos_type;
DROP TABLE pos;
DROP TABLE org;
DROP TABLE history;
DROP TABLE version;
DROP TABLE approval_line;
DROP TABLE line_approver;
DROP TABLE timeoff;
DROP TABLE timeoff_approver;
DROP TABLE outside;
DROP TABLE outside_approver;
DROP TABLE mail;
*/

-- -----------------------------------------------------
-- Table: setting
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS setting (
  user_id        VARCHAR(30) NOT NULL DEFAULT '-',
  setting_key    VARCHAR(30) NOT NULL,
  setting_value  VARCHAR(30) NOT NULL,
  CONSTRAINT pk_setting PRIMARY KEY (user_id, setting_key)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: code
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS code (
  code_group  VARCHAR(30) NOT NULL DEFAULT '-',
  code_id     VARCHAR(30) NOT NULL,
  code_name   VARCHAR(50) NOT NULL,
  code_sort   INT         NOT NULL DEFAULT 0,
  CONSTRAINT pk_code PRIMARY KEY (code_group, code_id),
  INDEX idx_code (code_sort ASC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: usr
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS usr (
  user_id        VARCHAR(   45) NOT NULL,
  user_name      VARCHAR(   50) NOT NULL,
  user_password  VARCHAR(   50) NOT NULL,
  user_level     VARCHAR(    3) NOT NULL,
  position_id    INT                NULL,
  org_id         INT                NULL,
  entry_date     VARCHAR(   10) NOT NULL,  /* YYYY-MM-dd */
  quitting_year  VARCHAR(    5)     NULL,  /* YYYY */
  quitting_date  VARCHAR(   10)     NULL,  /* YYYY-MM-dd */
  user_changed   VARCHAR(   20) NOT NULL,  /* YYYY-MM-ddTHH:mm:ss */
  user_note      VARCHAR(10000)     NULL,
  user_address   VARCHAR(10000)     NULL,
  user_contact   VARCHAR(  100)     NULL,
  leave_count    DECIMAL(5, 3)  NOT NULL DEFAULT 0,  /* 첫해 초과사용한 연차 (입사 첫해만 연차를 댕겨 사용할 수 있다.) */
  CONSTRAINT pk_usr PRIMARY KEY (user_id),
  INDEX idx_usr_name     (user_name ASC),
  INDEX idx_usr_level    (user_level ASC),
  INDEX idx_usr_org      (org_id ASC),
  INDEX idx_usr_quitting (quitting_year DESC, quitting_date DESC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: pos_type
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS pos_type (
  type_id    INT         NOT NULL AUTO_INCREMENT,
  type_name  VARCHAR(50) NOT NULL,
  type_sort  INT         NOT NULL DEFAULT 0,
  CONSTRAINT pk_pos_type PRIMARY KEY (type_id),
  INDEX idx_pos_type (type_sort ASC)
)
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: pos
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS pos (
  position_id    INT         NOT NULL AUTO_INCREMENT,
  position_type  INT         NOT NULL,
  position_name  VARCHAR(50) NOT NULL,
  position_sort  INT         NOT NULL DEFAULT 0,
  CONSTRAINT pk_pos PRIMARY KEY (position_id),
  INDEX idx_pos (position_sort ASC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: org
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS org (
  org_id      INT         NOT NULL AUTO_INCREMENT,
  org_name    VARCHAR(50) NOT NULL,
  org_parent  INT         NOT NULL DEFAULT 0,
  org_sort    INT         NOT NULL DEFAULT 0,
  CONSTRAINT pk_org PRIMARY KEY (org_id),
  INDEX idx_org (org_sort DESC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: history
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS history (
  history_id    INT         NOT NULL AUTO_INCREMENT,
  project_id    INT         NOT NULL,
  user_id       VARCHAR(45) NOT NULL,
  history_date  TIMESTAMP   NOT NULL DEFAULT NOW(),
  history_type  VARCHAR(30) NOT NULL,
  target_id     VARCHAR(30) NOT NULL,
  target_name   VARCHAR(50) NOT NULL,
  target_crud   VARCHAR(1)  NOT NULL,
  CONSTRAINT pk_history PRIMARY KEY (history_id),
  INDEX idx_history (project_id ASC, history_type ASC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: version
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS version (
  version_id    INT         NOT NULL AUTO_INCREMENT,
  version_name  VARCHAR(20) NOT NULL,
  user_id       VARCHAR(45) NOT NULL,
  released      VARCHAR(20) NOT NULL,
  updated       VARCHAR(20) NOT NULL DEFAULT '0',  /* 0: start upgrade, 1: continue after rebooting, YYYY-MM-ddTHH:mm:ss: upgraded date */
  CONSTRAINT pk_version PRIMARY KEY (version_id)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: approval_line
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS approval_line (
  line_id     INT         NOT NULL AUTO_INCREMENT,
  line_name   VARCHAR(50) NOT NULL,
  user_id     VARCHAR(45) NOT NULL,
  update_date VARCHAR(20) NOT NULL,  /* YYYY-MM-dd'T'HH:mm:ss */
  CONSTRAINT pk_approval_line PRIMARY KEY (line_id),
  INDEX idx_approval_line (user_id ASC, update_date DESC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: line_approver
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS line_approver (
  line_id       INT         NOT NULL,
  approver_id   VARCHAR(45) NOT NULL,
  approver_sort INT         NOT NULL DEFAULT 0,
  CONSTRAINT pk_line_approver PRIMARY KEY (line_id, approver_id)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: timeoff
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS timeoff (
  user_id         VARCHAR( 30) NOT NULL,
  timeoff_id      INT          NOT NULL AUTO_INCREMENT,
  timeoff_type    VARCHAR( 30) NOT NULL,
  timeoff_comment TEXT             NULL,  /* 휴가신청자의 사유 */
  timeoff_start   VARCHAR( 20) NOT NULL,  /* YYYY-MM-dd AM/PM or YYYY-MM-dd #시간  */
  timeoff_end     VARCHAR( 20)     NULL,  /* YYYY-MM-dd AM/PM */
  timeoff_year    VARCHAR(  4) NOT NULL,  /* YYYY 회계년도 기준 */
  entry_year      VARCHAR(  4) NOT NULL,  /* YYYY 입사년도 기준 */
  available_days  DECIMAL(5,3) NOT NULL,
  used_days       DECIMAL(5,3) NOT NULL,
  request_days    DECIMAL(5,3) NOT NULL,
  applied_days    DECIMAL(5,3) NOT NULL,
  create_year     VARCHAR(  4) NOT NULL,  /* YYYY 작성년도 기준 */
  create_date     VARCHAR( 20) NOT NULL,  /* YYYY-MM-ddTHH:mm:ss */
  sign_step       INT          NOT NULL DEFAULT 0,  /* 음수면 해당 단계에서 반려 */
  approval_step   INT          NOT NULL DEFAULT 0,
  user_contact    VARCHAR(100)     NULL,
  canceled_id     INT          NOT NULL DEFAULT 0,  /* 양수이면 취소처리를 위한 새로운 휴가, 0이면 일반 휴가, -1이면 취소신청된 휴가, -2이면 취소신청처리된 휴가 */
  CONSTRAINT pk_timeoff PRIMARY KEY (timeoff_id),
  INDEX idx_timeoff_year (user_id ASC, timeoff_year DESC, create_date DESC),
  INDEX idx_entry_year (user_id ASC, entry_year DESC, create_date DESC),
  INDEX idx_timeoff_create_year (create_year DESC, create_date DESC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: timeoff_approver
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS timeoff_approver (
  timeoff_id        INT         NOT NULL,
  approver_id       VARCHAR(30) NOT NULL,
  approver_sort     INT         NOT NULL DEFAULT 0,
  approver_comment  TEXT            NULL,  /* 결재자의 의견 */
  sign_date         VARCHAR(20)     NULL,  /* YYYY-MM-dd'T'HH:mm:ss */
  sign_status       VARCHAR(10) NOT NULL DEFAULT 'waiting',  /* waiting | approved | rejected */
  agent_id          VARCHAR(30)     NULL,
  CONSTRAINT pk_timeoff_approver PRIMARY KEY (timeoff_id, approver_id),
  INDEX idx_timeoff_approver_sort (timeoff_id ASC, approver_sort ASC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: outside
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS outside (
  user_id           VARCHAR( 30) NOT NULL,
  outside_id        INT          NOT NULL AUTO_INCREMENT,
  outside_comment   TEXT             NULL,  /* 외근 신청자의 사유 */
  outside_startdate VARCHAR( 10) NOT NULL,  /* YYYY-MM-dd */
  outside_enddate   VARCHAR( 10) NOT NULL,  /* YYYY-MM-dd */
  outside_starttime VARCHAR(  2) NOT NULL,  /* HH or S */
  outside_endtime   VARCHAR(  2) NOT NULL,  /* HH or E */
  outside_year      VARCHAR(  4) NOT NULL,  /* YYYY 회계년도 기준 */
  destination       VARCHAR(256)     NULL,
  request_startdate VARCHAR( 10) NOT NULL,  /* YYYY-MM-dd */
  request_enddate   VARCHAR( 10)     NULL,  /* YYYY-MM-dd */
  request_starttime VARCHAR(  2) NOT NULL,  /* HH or S */
  request_endtime   VARCHAR(  2) NOT NULL,  /* HH or E */
  create_year       VARCHAR(  4) NOT NULL,  /* YYYY 작성년도 기준 */
  create_date       VARCHAR( 20) NOT NULL,  /* YYYY-MM-ddTHH:mm:ss */
  sign_step         INT          NOT NULL DEFAULT 0,  /* 음수면 해당 단계에서 반려 */
  approval_step     INT          NOT NULL DEFAULT 0,
  user_contact      VARCHAR(100)     NULL,
  canceled_id       INT          NOT NULL DEFAULT 0,  /* 양수이면 취소처리를 위한 새로운 외근, 0이면 일반 외근, -1이면 취소신청된 외근, -2이면 취소신청처리된 외근 */
  CONSTRAINT pk_outside PRIMARY KEY (outside_id),
  INDEX idx_outside_year (user_id ASC, outside_year DESC, create_date DESC),
  INDEX idx_outsice_create_year (create_year DESC, create_date DESC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: outside_approver
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS outside_approver (
  outside_id        INT         NOT NULL,
  approver_id       VARCHAR(30) NOT NULL,
  approver_sort     INT         NOT NULL DEFAULT 0,
  approver_comment  TEXT            NULL,  /* 결재자의 의견 */
  sign_date         VARCHAR(20)     NULL,  /* YYYY-MM-dd'T'HH:mm:ss */
  sign_status       VARCHAR(10) NOT NULL DEFAULT 'waiting',  /* waiting | approved | rejected */
  agent_id          VARCHAR(30)     NULL,
  CONSTRAINT pk_outside_approver PRIMARY KEY (outside_id, approver_id),
  INDEX idx_outside_approver_sort (outside_id ASC, approver_sort ASC)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

-- -----------------------------------------------------
-- Table: mail
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS mail (
  user_id  VARCHAR( 30) NOT NULL,
  email    VARCHAR(100) NOT NULL,
  enabled  VARCHAR(  1) NOT NULL DEFAULT 'Y',
  CONSTRAINT pk_mail PRIMARY KEY (user_id)
)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_general_ci;

/**********************************/
/* auth_level                     */
/**********************************/
INSERT INTO code
       (code_group  , code_id     , code_name  , code_sort)
VALUES ('-'         , 'auth_level', 'Auth level', 0)
     , ('auth_level', 'high'      , 'High'      , 0)  /* 인증 실패시 ID와 비밀번호 중 틀린 부분을 알려 주지 않음. */
     , ('auth_level', 'low'       , 'Low'       , 1); /* 인증 실패시 ID와 비밀번호 중 틀린 부분을 알려줌. */

/**********************************/
/* user_level                     */
/**********************************/
INSERT INTO code
       (code_group  , code_id     , code_name      , code_sort)
VALUES ('-'         , 'user_level', 'User level'   , 0)
     , ('user_level', '9'         , 'Aleave Admin' , 0)  /* admin */
     , ('user_level', '5'         , 'Manager'      , 2)  /* 팀장 */
     , ('user_level', '1'         , 'Member'       , 3)  /* 팀원 */
     , ('user_level', '0'         , 'Admin Creator', 4); /* admin_creator */

/**********************************/
/* history_type                   */
/**********************************/
INSERT INTO code
       (code_group    , code_id       , code_name     , code_sort)
VALUES ('-'           , 'history_type', 'History type', 0)
     , ('history_type', 'user'        , 'User'        , 0);

/**********************************/
/* timeoff_type                   */
/**********************************/
INSERT INTO code
       (code_group    , code_id  , code_name, code_sort)
VALUES ('timeoff_type', 'regular', '정기휴가' , 0)
     , ('timeoff_type', 'public' , '공가'    , 1)
     , ('timeoff_type', 'special', '특별휴가' , 2)
     , ('timeoff_type', 'sick'   , '병가'    , 3)
     , ('timeoff_type', 'late'   , '지각'    , 4)
     , ('timeoff_type', 'early'  , '조퇴'    , 5)
     , ('timeoff_type', 'absence', '결근'    , 6);

/**********************************/
/* outside_type                   */
/**********************************/
INSERT INTO code
       (code_group    , code_id   , code_name, code_sort)
VALUES ('outside_type', 'outday'  , '외근'    , 0)
     , ('outside_type', 'outstart', '직출'    , 1)
     , ('outside_type', 'outend'  , '직퇴'    , 2);



/**********************************/
/* 초기 직원 유형 값              */
/**********************************/
INSERT INTO pos_type
       (type_id, type_name, type_sort)
VALUES (1      , '임원'    , 0)
     , (2      , '사무직'  , 1)
     , (3      , '연구직'  , 2)
     , (4      , '생산직'  , 3);

/**********************************/
/* 초기 직급 값                   */
/**********************************/
INSERT INTO pos
       (position_type, position_name, position_sort)
VALUES (1            , '대표이사'    , 0)
     , (1            , '부사장'      , 1)
     , (1            , '전무'        , 2)
     , (1            , '상무'        , 3)
     , (1            , '이사'        , 4)
     , (2            , '부장'        , 0)
     , (2            , '차장'        , 1)
     , (2            , '과장'        , 2)
     , (2            , '대리'        , 3)
     , (2            , '사원'        , 4)
     , (3            , '연구위원'     , 0)
     , (3            , '수석연구원'   , 1)
     , (3            , '책임연구원'   , 2)
     , (3            , '선임연구원'   , 3)
     , (3            , '연구원'      , 4)
     , (4            , '공장'        , 0)
     , (4            , '직장'        , 1)
     , (4            , '반장'        , 2)
     , (4            , '조장'        , 3)
     , (4            , '반원'        , 4);

/**********************************/
/* 초기 설정 값                   */
/**********************************/
INSERT INTO setting
       (user_id, setting_key           , setting_value)
VALUES ('-'    , 'use_init_admin'      , 'true'       )
     , ('-'    , 'update_account'      , 'true'       )
     , ('-'    , 'auth_level'          , 'high'       )
     , ('-'    , 'leave_basic_date'    , 'entry_date' )  /* 연차계산기준일: 입사일, 회계연도 / entry_date | fiscal_date */
     , ('-'    , 'annual_payment_date' , 'entry_month')  /* 연차수당지급일(입사일기준일때): 입사일, 회계연도시작일 / entry_month | fiscal_month */
     , ('-'    , 'leave_grant_date'    , 'next_year'  )  /* 연차부여일(회계연도기준일때): 입사후 첫번째 회계연도시작일, 만1년 근무후 첫번째 회계연도시작일 / next_year | over_one_year */
     , ('-'    , 'fiscal_date'         , '0'          )  /* 회계연도시작일: 월의 index */
     , ('-'    , 'support_sick_timeoff', 'false'      )
     , ('-'    , 'timeoff_period_limit', '0'          )
     , ('-'    , 'approver_count'      , '3'          )  /* 결재라인 단계 (2 ~ 6) */
     , ('-'    , 'init_position_type'  , '2'          )  /* 사용자 등록 초기 직급 유형 */
     , ('-'    , 'mail_notification'   , 'false'      )  /* 메일 알림 */
     , ('-'    , 'mail_sender'         , ''           )
     , ('-'    , 'smtp_secure'         , 'tls'        )  /* none | ssl | tls */
     , ('-'    , 'smtp_host'           , ''           )
     , ('-'    , 'smtp_port'           , '587'        )
     , ('-'    , 'smtp_user'           , ''           )
     , ('-'    , 'smtp_password'       , ''           );

/***************************************/
/* 초기 설정된 관리자                     */
/* -- 중요: 아래의 계정을 편집하면 안됨 --   */
/***************************************/
INSERT INTO usr
       (user_id   , user_name         , user_password, user_level, entry_date                   , user_changed)
values ('${admin}', 'A-leave Customer', '${admin}'   , '0'       , DATE_FORMAT(NOW(),'%Y-%m-%d'), DATE_FORMAT(NOW(),'%Y-%m-%dT%T'));